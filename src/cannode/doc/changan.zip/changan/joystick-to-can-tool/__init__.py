#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
CAN游戏手柄控制器
基于WebSocket的CAN总线游戏手柄控制系统
"""

__version__ = "1.0.0"
__author__ = "CAZG Team"
__description__ = "基于WebSocket的CAN总线游戏手柄控制器系统"

from .main import main
from .config import config
from .can_communication import CANCommunicationThread
from .can_message_parser.can_parser import CANMessageParser, JSONMessage, MessageDirection

__all__ = [
    'main',
    'config',
    'CANCommunicationThread',
    'CANMessageParser',
    'JSONMessage',
    'MessageDirection'
]
