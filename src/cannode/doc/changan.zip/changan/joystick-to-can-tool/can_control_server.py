#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
CAN总线挖掘机遥控系统 - 核心服务器
=======================================

这是系统的核心服务器模块，采用双线程架构设计：

线程架构：
1. 主线程：运行WebSocket服务器，处理前端连接和消息分发
2. CAN线程：专门处理CAN设备通信，包括消息发送和接收

数据流向：
游戏手柄 → Web前端 → WebSocket → 消息队列 → CAN线程 → CAN总线
CAN总线 → CAN线程 → 消息队列 → WebSocket → Web前端 → 界面显示

主要功能模块：
- WebSocketServer: 处理前端通信和客户端管理
- CANCommunicationThread: 处理CAN设备的所有操作
- 消息队列系统: 实现线程间安全的数据传递
- 错误处理和日志记录: 保证系统稳定运行

设计特点：
- 异步非阻塞设计，支持多客户端并发连接
- 线程安全的消息队列，确保数据完整性
- 完整的错误处理和恢复机制
- 实时状态监控和反馈

"""

import asyncio
import websockets
import json
import threading
import time
import queue
import logging
from typing import Dict, List, Any, Optional
from ctypes import *
import struct

# 导入项目自定义模块
from can_message_parser.can_parser import CANMessageParser, JSONMessage, MessageDirection
from can_message_parser.data_assignment import CANMessage

# ====== 日志系统配置 ======
# 设置统一的日志格式，便于调试和问题追踪
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s:%(lineno)d - %(levelname)s - %(message)s',
    handlers=[
        logging.StreamHandler()  # 输出到控制台
        # 如需输出到文件，可以添加：FileHandler('can_server.log')
    ]
)
logger = logging.getLogger(__name__)
logger.info("启动脚本初始化完成")

# ====== CAN设备相关常量和数据结构 ======
# 这些定义来自CAN设备厂商的SDK，用于与底层DLL库通信

# CAN设备类型定义（基于ControlCAN.h）
VCI_USBCAN2 = 4               # USBCAN2设备类型标识
# 函数调用返回状态码
STATUS_OK = 1                 # 操作成功
STATUS_ERR = 0                # 操作失败

# ====== CAN设备相关数据结构定义 ======
# 这些结构体与CAN设备DLL库的C语言接口保持一致，用于数据交互

class VCI_INIT_CONFIG(Structure):  
    """
    CAN初始化配置结构体（基于ControlCAN.h）
    用于配置CAN通道的基本参数
    """
    _fields_ = [
        ("AccCode", c_uint),     # 验收代码（用于消息过滤）
        ("AccMask", c_uint),     # 验收掩码（用于消息过滤）
        ("Reserved", c_uint),    # 保留字段
        ("Filter", c_ubyte),     # 过滤器模式
        ("Timing0", c_ubyte),    # CAN总线时序参数0
        ("Timing1", c_ubyte),    # CAN总线时序参数1
        ("Mode", c_ubyte)        # 工作模式（正常模式、只听模式等）
    ]

class VCI_CAN_OBJ(Structure):  
    """
    CAN消息对象结构体（基于ControlCAN.h）
    定义了一个完整CAN消息的所有字段
    """
    _fields_ = [
        ("ID", c_uint),          # CAN消息ID
        ("TimeStamp", c_uint),   # 时间戳
        ("TimeFlag", c_ubyte),   # 时间标志
        ("SendType", c_ubyte),   # 发送类型
        ("RemoteFlag", c_ubyte), # 远程帧标志位（0=数据帧，1=远程帧）
        ("ExternFlag", c_ubyte), # 帧格式标志位（0=标准帧，1=扩展帧）
        ("DataLen", c_ubyte),    # 数据长度代码（0-8字节）
        ("Data", c_ubyte*8),     # CAN数据字段（最多8字节）
        ("Reserved", c_ubyte*3)  # 保留字段
    ]

class CANCommunicationThread(threading.Thread):
    """
    CAN通信专用线程类
    ====================
    
    这是系统中负责所有CAN设备操作的专用线程，与主WebSocket线程分离运行，
    确保CAN通信的实时性不受Web界面操作的影响。
    
    主要职责：
    1. CAN设备的初始化和管理
    2. 处理来自WebSocket的控制命令
    3. 实时发送CAN消息到设备
    4. 接收和解析来自CAN设备的反馈消息
    5. 维护CAN通信状态和错误处理
    
    工作流程：
    - 初始化CAN设备和通道
    - 循环处理消息队列中的命令
    - 定时发送待发送的CAN消息
    - 检查并接收CAN设备的反馈
    - 将状态信息回传给WebSocket线程
    
    线程安全：
    使用消息队列机制与其他线程通信，确保数据安全
    """
    
    def __init__(self, message_queue_in: queue.Queue, message_queue_out: queue.Queue):
        """
        初始化CAN通信线程
        
        Args:
            message_queue_in: 输入消息队列，接收来自WebSocket的控制命令
            message_queue_out: 输出消息队列，发送状态和数据到WebSocket
        """
        # 设置为守护线程，主程序退出时自动结束
        super().__init__(daemon=True)
        
        # ====== 线程间通信队列 ======
        self.message_queue_in = message_queue_in    # 来自WebSocket的消息队列
        self.message_queue_out = message_queue_out  # 发送到WebSocket的消息队列
        
        # ====== CAN设备相关句柄 ======
        self.can_dll = None          # CAN设备DLL库引用
        # VCI API不需要保存句柄，每次调用时直接使用设备类型和索引
        
        # ====== 线程状态控制 ======
        self.is_running = False      # 线程运行状态标志
        self.is_can_connected = False # CAN设备连接状态标志
        self.is_web_emergency_stop_active = False # 网页急停状态标志
        # ====== 消息处理组件 ======
        self.parser = CANMessageParser()  # CAN消息解析器实例
        self._send_debug_counter = 0
        # ====== 消息发送管理 ======
        # 固定结构的CAN消息缓存，以100Hz固定频率发送
        self.can_message_cache = {
            0x18000001: None,  # 控制命令消息
            0x18000002: None,  # 液压电机控制消息  
            0x18000003: None,  # 行走电机控制消息
            0x18000004: None   # 机构电磁阀控制消息
        }
        
        # 初始化默认的CAN消息（全零数据）
        self._initialize_default_messages()
        
        logger.info("CAN通信线程初始化完成")

    def _initialize_default_messages(self):
        """初始化默认的CAN消息（全零或安全状态）"""
        # 创建默认的全零数据消息
        default_data = bytes([0x00] * 8)
        
        for msg_id in self.can_message_cache.keys():
            self.can_message_cache[msg_id] = CANMessage(msg_id, default_data)
        
        logger.info("已初始化默认CAN消息缓存")
        
    def update_message_cache(self, messages: List[CANMessage]):
        """更新CAN消息缓存（由WebSocket输入触发）
        
        Args:
            messages: 新的CAN消息列表
        """
        for msg in messages:
            if msg.id in self.can_message_cache:
                self.can_message_cache[msg.id] = msg
                logger.debug(f"更新缓存消息 ID=0x{msg.id:08X}")
        
    def run(self):
        """
        线程主函数 - CAN通信线程的核心执行循环
        
        执行流程：
        1. 初始化CAN设备和通道
        2. 进入主循环，执行以下操作：
           - 处理来自WebSocket的输入消息
           - 更新心跳状态（独立于输入频率）
           - 发送待发送的CAN消息
           - 接收CAN设备的反馈消息
           - 短暂休眠以控制循环频率
        3. 异常处理和资源清理
        
        循环频率：100Hz（10ms间隔），确保实时响应
        """
        logger.info("CAN通信线程正式启动")
        self.is_running = True
        
        try:
            # 第一步：初始化CAN设备
            logger.info("开始初始化CAN设备...")
            self.initialize_can()
            
            # 第二步：进入主要工作循环
            logger.info("进入CAN通信主循环（100Hz频率）")

            while self.is_running:
                # 处理来自WebSocket的控制命令（更新消息缓存）
                self.process_incoming_messages()
                
                # 独立更新心跳状态（每200ms翻转一次，即20次循环）
                self.update_heartbeat_state()
                
                # 以固定100Hz频率发送缓存中的CAN消息
                self.send_cached_messages()
                
                # 接收来自CAN设备的反馈消息
                self.receive_can_messages()
                
                # 控制循环频率：100Hz = 10ms间隔
                time.sleep(0.01)
                
                
        except Exception as e:
            logger.error(f"CAN通信线程发生异常: {e}")
            logger.error(f"异常类型: {type(e).__name__}")
            # 将错误信息发送给WebSocket线程
            self.message_queue_out.put({
                'type': 'error',
                'message': f'CAN通信异常: {e}'
            })
        finally:
            # 第三步：清理资源并安全退出
            logger.info("CAN通信线程准备退出，开始清理资源")
            self.cleanup_can()
            logger.info("CAN通信线程已安全退出")
    
    def initialize_can(self):
        """初始化CAN设备（基于VCI API）"""
        try:
            # 加载CAN库
            self.can_dll = windll.LoadLibrary('./ControlCAN.dll')
            
            # 打开设备
            ret = self.can_dll.VCI_OpenDevice(VCI_USBCAN2, 0, 0)
            if ret != STATUS_OK:
                raise Exception("无法打开CAN设备")
            
            logger.info("CAN设备打开成功")
            
            # 初始化CAN通道0
            vci_init_config = VCI_INIT_CONFIG(
                0x80000008,  # AccCode - 验收代码
                0xFFFFFFFF,  # AccMask - 验收掩码  
                0,           # Reserved
                0,           # Filter - 过滤器模式
                0x00,        # Timing0 - 时序参数0 (1000k波特率)
                0x14,        # Timing1 - 时序参数1
                0            # Mode - 正常模式
            )
            
            ret = self.can_dll.VCI_InitCAN(VCI_USBCAN2, 0, 0, byref(vci_init_config))
            if ret != STATUS_OK:
                raise Exception("初始化CAN通道0失败")
            
            # 启动CAN通道0
            ret = self.can_dll.VCI_StartCAN(VCI_USBCAN2, 0, 0)
            if ret != STATUS_OK:
                raise Exception("启动CAN通道0失败")
            
            logger.info("CAN通道0初始化成功")
            
            # 如果需要第二个通道，也可以初始化
            # 初始化CAN通道1
            ret = self.can_dll.VCI_InitCAN(VCI_USBCAN2, 0, 1, byref(vci_init_config))
            if ret != STATUS_OK:
                logger.warning("初始化CAN通道1失败")
            else:
                ret = self.can_dll.VCI_StartCAN(VCI_USBCAN2, 0, 1)
                if ret != STATUS_OK:
                    logger.warning("启动CAN通道1失败")
                else:
                    logger.info("CAN通道1初始化成功")
            
            self.is_can_connected = True
            logger.info("CAN通信初始化成功")
            
            # 通知WebSocket连接状态
            self.message_queue_out.put({
                'type': 'status',
                'can_connected': True,
                'can-status': 'CAN已连接'
            })
            
        except Exception as e:
            logger.error(f"初始化CAN失败: {e}")
            self.is_can_connected = False
            self.message_queue_out.put({
                'type': 'status',
                'can_connected': False,
                'can-status': f'CAN连接失败: {e}'
            })
    
    
    def process_incoming_messages(self):
        """处理来自WebSocket的消息（只更新缓存，不控制发送频率）"""
        try:
            if not self.message_queue_in.empty():
                message = self.message_queue_in.get_nowait()
                
                
                if message['type'] == 'gamepad_data':
                    # 解析游戏手柄数据为CAN消息并更新缓存
                    can_messages = self.parser.parse_gamepad_data(message)
                    self.update_message_cache(can_messages)
                    
                elif message['type'] == 'emergency_stop':
                    # 处理急停命令
                    if message['active']:
                        self.is_web_emergency_stop_active = True
                        self.parser.data_assignment_handler.control_states['emergency_stop_active'] = True
                        logger.warning("收到网页急停命令（最高优先级），停止底层数据发送")
                    else:
                        self.is_web_emergency_stop_active = False
                        self.parser.data_assignment_handler.control_states['emergency_stop_active'] = False
                        logger.info("网页急停命令解除（最高优先级），恢复底层数据发送")
                    

        except Exception as e:
            logger.error(f"处理传入消息失败: {e}")
    
    def update_heartbeat_state(self):
        """
        独立更新心跳状态（每200ms翻转一次）
        
        心跳计算独立于输入数据频率，确保按照固定频率工作：
        - 每10ms调用一次（100Hz循环）
        - 每20次调用（200ms）翻转一次心跳状态
        - 心跳状态存储在parser的control_states中
        """
        try:
            # 获取心跳计数器
            heartbeat_counter = self.parser.control_states.get('heartbeat_counter', 0)
            heartbeat_counter += 1
            
            # 每20次循环（200ms）翻转一次心跳状态
            if heartbeat_counter >= 1:
                heartbeat_counter = 0
                self.parser.control_states['heartbeat_state'] = not self.parser.control_states.get('heartbeat_state', False)
                logger.debug(f"心跳状态翻转: {self.parser.control_states['heartbeat_state']}")
            
            # 更新心跳计数器
            self.parser.control_states['heartbeat_counter'] = heartbeat_counter

        except Exception as e:
            logger.error(f"更新心跳状态失败: {e}")

    def update_heartbeat_in_control_message(self):
        """
        更新控制命令消息中的心跳状态
        
        在发送消息前，将当前的心跳状态更新到控制命令消息(0x18000001)中。
        这确保了心跳状态能够独立于输入数据频率正确更新。
        """
        try:
            # 获取控制命令消息
            control_msg = self.can_message_cache.get(0x18000001)
            if control_msg is None:
                return
            
            # 创建新的数据副本
            data = bytearray(control_msg.data)
            
            # 清除心跳位（bit 9 = byte 1, bit 1）
            data[1] &= ~(1 << 1)
            
            # 根据当前心跳状态设置心跳位
            if self.parser.control_states.get('heartbeat_state', False):
                data[1] |= (1 << 1)  # bit 9 = byte 1, bit 1
            
            # 更新消息数据
            control_msg.data = bytes(data)
            
        except Exception as e:
            logger.error(f"更新控制命令消息中的心跳状态失败: {e}")

    def send_cached_messages(self):
        """以100Hz固定频率发送缓存中的CAN消息"""
        
        # if not self.is_can_connected or self.is_web_emergency_stop_active:
        #     return

        try:
            # 在发送前更新控制命令消息中的心跳状态
            self.update_heartbeat_in_control_message()
            
            # 获取所有缓存的消息（固定4个消息）
            cached_msgs = [msg for msg in self.can_message_cache.values() if msg is not None]
            if not cached_msgs:
                return
            
            # 准备发送数据结构（使用VCI_CAN_OBJ）
            send_count = len(cached_msgs)
            can_msgs = (VCI_CAN_OBJ * send_count)()
            
            for i, msg in enumerate(cached_msgs):
                can_msgs[i].SendType = 1  # 单次发送
                can_msgs[i].RemoteFlag = 0  # 数据帧
                can_msgs[i].ExternFlag = 1 if msg.id > 0x7FF else 0  # 扩展帧或标准帧
                can_msgs[i].ID = msg.id
                can_msgs[i].DataLen = len(msg.data)
                can_msgs[i].TimeFlag = 0
                can_msgs[i].TimeStamp = 0
                
                # 复制数据
                for j in range(len(msg.data)):
                    can_msgs[i].Data[j] = msg.data[j]
                
                # 清零剩余的数据字节
                for j in range(len(msg.data), 8):
                    can_msgs[i].Data[j] = 0
            
            # 发送消息到通道0（使用VCI_Transmit）
            sent_count = self.can_dll.VCI_Transmit(VCI_USBCAN2, 0, 0, byref(can_msgs), send_count)
            
            if sent_count > 0:
                # 转发到WebSocket用于显示，使用信号解析功能
                for i in range(sent_count):
                    msg = cached_msgs[i]
                    # 使用新的信号解析方法

                    json_msg, signal_data = self.parser.parse_message_with_signals(
                        msg.id, msg.data, MessageDirection.SEND)

                    # 使用新的数据格式
                    msg_out = json_msg.to_json_with_signals(signal_data)
                    self.message_queue_out.put(msg_out)
                    
                    # 每100次（1秒）打印一次调试信息
                    if self._send_debug_counter % 1 == 0:
                        logger.info(f"发送CAN消息: ID=0x{msg.id:08X}"+str(msg_out['hex_data']))
                self._send_debug_counter += 1
                        
            else:
                logger.warning("发送CAN消息失败，没有消息被发送")
            
        except Exception as e:
            logger.error(f"发送CAN消息失败: {e}")
    
    def receive_can_messages(self):
        """接收CAN消息（使用VCI API）"""
        if not self.is_can_connected:
            return
        
        try:
            # 检查通道0的接收缓冲区
            msg_count = self.can_dll.VCI_GetReceiveNum(VCI_USBCAN2, 0, 0)
            
            if msg_count > 0:
                # 接收消息（使用VCI_CAN_OBJ数组）
                rcv_msgs = (VCI_CAN_OBJ * msg_count)()
                actual_count = self.can_dll.VCI_Receive(
                    VCI_USBCAN2, 0, 0, byref(rcv_msgs), msg_count, 0)  # 非阻塞接收
                
                for i in range(actual_count):
                    msg_obj = rcv_msgs[i]
                    msg_id = msg_obj.ID
                    data = bytes([msg_obj.Data[j] for j in range(msg_obj.DataLen)])
                    
                    # 使用新的信号解析方法
                    json_msg, signal_data = self.parser.parse_message_with_signals(
                        msg_id, data, MessageDirection.RECV)
                    json_msg.timestamp = msg_obj.TimeStamp
                    
                    # 发送到WebSocket，使用新的数据格式
                    msg_out = json_msg.to_json_with_signals(signal_data)
                    self.message_queue_out.put(msg_out)
                    logger.debug(f"接收CAN消息（通道0）: ID=0x{msg_id:08X}"+str(msg_out['hex_data']))


            # 同时检查通道1的接收缓冲区（如果有的话）
            msg_count_ch1 = self.can_dll.VCI_GetReceiveNum(VCI_USBCAN2, 0, 1)
            
            if msg_count_ch1 > 0:
                # 接收通道1的消息
                rcv_msgs_ch1 = (VCI_CAN_OBJ * msg_count_ch1)()
                actual_count_ch1 = self.can_dll.VCI_Receive(
                    VCI_USBCAN2, 0, 1, byref(rcv_msgs_ch1), msg_count_ch1, 0)
                
                for i in range(actual_count_ch1):
                    msg_obj = rcv_msgs_ch1[i]
                    msg_id = msg_obj.ID
                    data = bytes([msg_obj.Data[j] for j in range(msg_obj.DataLen)])
                    
                    # 使用新的信号解析方法
                    json_msg, signal_data = self.parser.parse_message_with_signals(
                        msg_id, data, MessageDirection.RECV)
                    json_msg.timestamp = msg_obj.TimeStamp
                    
                    # 发送到WebSocket，使用新的数据格式
                    msg_out = json_msg.to_json_with_signals(signal_data)
                    self.message_queue_out.put(msg_out)
                    logger.debug(f"接收CAN消息（通道1）: ID=0x{msg_id:08X}"+str(msg_out['hex_data']))
                
        except Exception as e:
            logger.error(f"接收CAN消息失败: {e}")
    
    def cleanup_can(self):
        """清理CAN资源（使用VCI API）"""
        try:
            # 重置CAN通道
            ret = self.can_dll.VCI_ResetCAN(VCI_USBCAN2, 0, 0)
            if ret == STATUS_OK:
                logger.info("CAN通道0已重置")
            
            # 尝试重置通道1（如果存在）
            ret = self.can_dll.VCI_ResetCAN(VCI_USBCAN2, 0, 1)
            if ret == STATUS_OK:
                logger.info("CAN通道1已重置")
            
            # 关闭CAN设备
            ret = self.can_dll.VCI_CloseDevice(VCI_USBCAN2, 0)
            if ret == STATUS_OK:
                logger.info("CAN设备已关闭")
            else:
                logger.warning("关闭CAN设备失败")
                
        except Exception as e:
            logger.error(f"清理CAN资源失败: {e}")
        
        self.is_can_connected = False
        self.message_queue_out.put({
            'type': 'status',
            'can_connected': False,
            'status': 'CAN已断开'
        })
    
    def stop(self):
        """停止线程"""
        self.is_running = False

class WebSocketServer:
    """
    WebSocket服务器类
    =================
    
    负责处理前端Web界面的WebSocket连接和消息路由。
    采用异步架构，支持多客户端并发连接。
    
    主要功能：
    - 管理WebSocket客户端连接
    - 路由前端消息到CAN线程
    - 转发CAN状态信息到前端
    - 处理连接异常和重连机制
    """
    
    def __init__(self, host='localhost', port=8765):
        """
        初始化WebSocket服务器
        
        Args:
            host: 监听主机地址，默认localhost
            port: 监听端口，默认8765
        """
        self.host = host
        self.port = port
        self.clients = set()  # 存储活跃的WebSocket连接
        
        # ====== 与CAN线程的通信队列 ======
        self.can_message_queue_in = queue.Queue()   # 发送命令到CAN线程
        self.can_message_queue_out = queue.Queue()  # 从CAN线程接收状态

        # ====== 启动CAN通信线程 ======
        logger.info("正在启动CAN通信线程...")
        self.can_thread = CANCommunicationThread(
            self.can_message_queue_in, 
            self.can_message_queue_out
        )
        self.can_thread.start()
        
        # ====== 消息分发任务 ======
        self.message_dispatcher_task = None  # 异步消息分发任务引用
        
    async def register_client(self, websocket):
        """
        注册新的WebSocket客户端连接
        
        为新连接的客户端进行初始化设置，包括：
        - 将连接添加到客户端列表
        - 发送当前系统状态信息
        - 记录连接日志
        
        Args:
            websocket: WebSocket连接对象
        """
        self.clients.add(websocket)
        client_addr = websocket.remote_address
        logger.info(f"新客户端已连接: {client_addr[0]}:{client_addr[1]}")
        
        # 发送系统初始状态给新客户端
        initial_status = {
            'type': 'status',
            'can_connected': self.can_thread.is_can_connected,
            'system-status': f'已连接'
        }
        await websocket.send(json.dumps(initial_status, ensure_ascii=False))
    
    async def unregister_client(self, websocket):
        """注销客户端"""
        self.clients.discard(websocket)
        logger.info(f"客户端已断开: {websocket.remote_address}")
    
    async def handle_client_message(self, websocket, message):
        """
        处理来自Web客户端的消息
        
        支持的消息类型：
        - gamepad_data: 游戏手柄控制数据
        - emergency_stop: 急停命令
        
        Args:
            websocket: 客户端WebSocket连接
            message: 接收到的JSON消息字符串
        """
        try:
            # 解析JSON消息
            data = json.loads(message)
            msg_type = data.get('type', 'unknown')
            logger.debug(f"处理客户端消息类型: {msg_type}")
            
            # 转发消息到CAN通信线程进行处理
            self.can_message_queue_in.put(data)
            
        except json.JSONDecodeError as e:
            logger.error(f"客户端消息JSON解析失败: {e}")
            error_response = {
                'type': 'error',
                'message': '消息格式错误，请检查JSON格式'
            }
            await websocket.send(json.dumps(error_response, ensure_ascii=False))
        except Exception as e:
            logger.error(f"处理客户端消息时发生异常: {e}")
            error_response = {
                'type': 'error', 
                'message': f'服务器处理消息失败: {str(e)}'
            }
            await websocket.send(json.dumps(error_response, ensure_ascii=False))
    
    async def broadcast_message(self, message):
        """广播消息到所有客户端"""
        if self.clients:
            disconnected_clients = set()
            message_json = json.dumps(message, ensure_ascii=False)
            
            for client in self.clients.copy():
                try:
                    await client.send(message_json)
                except websockets.exceptions.ConnectionClosed:
                    disconnected_clients.add(client)
                except Exception as e:
                    logger.error(f"发送消息到客户端失败: {e}")
                    disconnected_clients.add(client)
            
            # 清理断开的客户端
            for client in disconnected_clients:
                self.clients.discard(client)
    
    async def message_dispatcher(self):
        """消息分发器，处理来自CAN线程的消息"""
        while True:
            try:
                if not self.can_message_queue_out.empty():
                    message = self.can_message_queue_out.get_nowait()
                    await self.broadcast_message(message)
                else:
                    await asyncio.sleep(0.01)  # 10ms检查间隔
                    
            except Exception as e:
                logger.error(f"消息分发失败: {e}")
                await asyncio.sleep(0.1)
    
    async def handle_client(self, websocket):
        """处理客户端连接（适配新版websockets库，移除path参数）"""
        await self.register_client(websocket)
        
        try:
            async for message in websocket:
                await self.handle_client_message(websocket, message)
                
        except websockets.exceptions.ConnectionClosed:
            pass
        except Exception as e:
            logger.error(f"客户端连接处理异常: {e}")
        finally:
            await self.unregister_client(websocket)
    
    async def start_server(self):
        """启动WebSocket服务器"""
        # 启动消息分发器
        self.message_dispatcher_task = asyncio.create_task(self.message_dispatcher())
        
        logger.info(f"启动WebSocket服务器: {self.host}:{self.port}")
        
        # 使用functools.partial绑定self参数
        from functools import partial
        
        # 创建WebSocket处理器（移除path参数，适配新版websockets库）
        def create_handler(server_instance):
            async def handler(websocket):
                try:
                    await server_instance.register_client(websocket)
                    
                    async for message in websocket:
                        await server_instance.handle_client_message(websocket, message)
                        
                except websockets.exceptions.ConnectionClosed:
                    pass
                except Exception as e:
                    logger.error(f"WebSocket连接处理异常: {e}")
                finally:
                    await server_instance.unregister_client(websocket)
            
            return handler
        
        # 创建WebSocket服务器
        start_server = websockets.serve(
            create_handler(self),
            self.host, 
            self.port,
            ping_interval=20,  # 20秒ping间隔
            ping_timeout=10    # 10秒ping超时
        )
        
        await start_server
        logger.info("WebSocket服务器已启动")
    
    def stop(self):
        """停止服务器"""
        if self.can_thread:
            self.can_thread.stop()
        
        if self.message_dispatcher_task:
            self.message_dispatcher_task.cancel()

class CANControlServer:
    """
    CAN控制服务器主类
    ==================
    
    系统的顶层控制类，整合WebSocket服务器和CAN通信功能。
    负责系统的整体启动、运行和关闭流程。
    """
    
    def __init__(self, host='localhost', port=8765):
        """
        初始化CAN控制服务器
        
        Args:
            host: WebSocket服务器监听地址
            port: WebSocket服务器监听端口
        """
        logger.info(f"初始化CAN控制服务器 {host}:{port}")
        self.websocket_server = WebSocketServer(host, port)
        
    async def run(self):
        """
        运行服务器主循环
        
        启动WebSocket服务器并保持运行状态，直到：
        - 收到键盘中断信号(Ctrl+C)
        - 发生严重异常
        - 外部调用stop()方法
        """
        try:
            logger.info("启动WebSocket服务器...")
            await self.websocket_server.start_server()
            
            logger.info("服务器启动完成，等待客户端连接...")
            logger.info("按 Ctrl+C 可以安全停止服务器")
            
            # 保持服务器运行，直到收到停止信号
            await asyncio.Future()  # 无限等待
            
        except KeyboardInterrupt:
            logger.info("收到用户停止信号 (Ctrl+C)")
        except Exception as e:
            logger.error(f"服务器运行过程中发生异常: {e}")
            logger.error(f"异常类型: {type(e).__name__}")
        finally:
            logger.info("开始停止服务器...")
            self.stop()
    
    def stop(self):
        """
        停止服务器及其所有组件
        
        执行优雅关闭流程：
        - 关闭WebSocket服务器
        - 停止CAN通信线程
        - 清理所有资源
        """
        logger.info("正在停止CAN控制服务器...")
        try:
            self.websocket_server.stop()
            logger.info("服务器已成功停止")
        except Exception as e:
            logger.error(f"停止服务器时发生异常: {e}")

async def main():
    """
    主函数 - 程序入口点
    
    负责：
    - 打印启动信息
    - 创建和启动服务器实例
    - 处理全局异常
    - 确保程序正确退出
    """
    # 打印启动横幅
    logger.info("=" * 60)
    logger.info("CAN总线挖掘机遥控系统服务器")
    logger.info("版本: v2.0")
    logger.info("作者: CAZG项目组")
    logger.info("=" * 60)
    
    # 创建服务器实例
    server = CANControlServer()
    
    try:
        # 启动服务器主循环
        await server.run()
    except Exception as e:
        logger.error(f"主程序发生未捕获的异常: {e}")
        logger.error(f"异常类型: {type(e).__name__}")
    finally:
        logger.info("CAN总线遥控系统服务器已退出")
        logger.info("感谢使用！")

if __name__ == '__main__':
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        logger.info("\n程序被用户中断")
    except Exception as e:
        logger.error(f"程序异常退出: {e}")
