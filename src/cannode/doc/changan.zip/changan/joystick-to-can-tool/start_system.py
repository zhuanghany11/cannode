#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
CAN总线挖掘机遥控系统 - 启动检查脚本
========================================

本脚本是系统的入口点，负责以下功能：
1. 系统环境检查（Python版本、依赖包、项目文件完整性）
2. 硬件设备检测（CAN设备DLL库文件）
3. 自动依赖安装（如果缺少必要的Python包）
4. 系统启动和异常处理

设计理念：
- 一键启动：用户只需要运行此脚本即可自动完成所有检查和启动
- 友好提示：每个步骤都有清晰的中文提示和状态显示
- 容错处理：能够自动检测和解决常见的配置问题
- 安全退出：任何异常情况都会安全退出并给出解决建议

作者：CAZG项目组
创建时间：2024年
"""

import os
import sys
import subprocess
import importlib.util
import webbrowser
import time
import threading
import logging
from pathlib import Path

# ====== 日志系统配置 ======
# 为启动脚本配置基础日志，主要用于错误记录
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s:%(lineno)d - %(levelname)s - %(message)s',
    handlers=[
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)
logger.info("启动脚本初始化完成")

def check_python_version():
    """
    检查Python版本是否符合系统要求
    
    系统要求Python 3.8或更高版本，主要原因：
    - asyncio的一些高级特性需要Python 3.8+
    - websockets库的某些功能在较新版本中更稳定
    - 类型提示支持更完整
    
    Returns:
        bool: True表示版本符合要求，False表示版本过低
    """
    # 检查最低版本要求：Python 3.8
    if sys.version_info < (3, 8):
        print("❌ 错误：需要Python 3.8或更高版本")
        print(f"当前版本：Python {sys.version}")
        print("建议：")
        print("  1. 下载并安装最新版本的Python：https://www.python.org/downloads/")
        print("  2. 或使用conda环境：conda create -n cancontrol python=3.8")
        return False
    
    print(f"✅ Python版本检查通过：{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}")
    return True

def check_dependencies():
    """
    检查系统所需的Python依赖包是否已安装
    
    检查的核心包：
    - websockets: 用于前后端WebSocket通信，版本11.0.3+
    - cantools: 用于DBC文件解析和CAN消息处理，版本37.0.0+
    
    检查方法：
    使用importlib.util.find_spec()来检测包是否存在，
    这比直接import更安全，不会因为包的import错误而崩溃
    
    Returns:
        list: 缺少的包名列表，空列表表示所有依赖都已满足
    """
    # 定义必需的包及其最低版本要求
    required_packages = {
        'websockets': '11.0.3',  # WebSocket服务器库
        'cantools': '37.0.0'     # CAN协议和DBC文件处理库
    }
    
    missing_packages = []
    
    print("正在检查Python依赖包...")
    
    for package, min_version in required_packages.items():
        try:
            # 使用find_spec检查包是否存在，比直接import更安全
            spec = importlib.util.find_spec(package)
            if spec is None:
                missing_packages.append(package)
                print(f"❌ 缺少包：{package} (需要版本 >= {min_version})")
            else:
                print(f"✅ 已安装：{package}")
        except ImportError as e:
            missing_packages.append(package)
            print(f"❌ 检查包 {package} 时出错：{e}")
    
    if missing_packages:
        print(f"\n发现 {len(missing_packages)} 个缺失的依赖包", missing_packages)
    else:
        print("所有必需的依赖包都已安装")
    
    return missing_packages


def check_can_dll():
    """
    检查CAN设备驱动DLL库文件是否存在
    
    支持的CAN设备库文件：
    - ControlCANFD.dll: 新版本的CANFD设备库，支持CAN2.0和CAN-FD
    - ControlCAN.dll: 经典版本的CAN设备库，主要支持CAN2.0
    
    检查策略：
    - 优先使用ControlCANFD.dll（功能更全面）
    - 如果没有找到CANFD版本，使用经典版本
    - 如果都没有找到，给出详细的获取指导
    
    Returns:
        bool: True表示找到至少一个可用的DLL文件，False表示都没找到
    """
    # 按优先级排序：CANFD版本优先
    dll_files = ['ControlCANFD.dll', 'ControlCAN.dll']
    
    print("正在检查CAN设备驱动库...")
    
    for dll_file in dll_files:
        if os.path.exists(dll_file):
            file_size = os.path.getsize(dll_file)
            print(f"✅ 找到CAN库：{dll_file} ({file_size:,} 字节)")
            
            # 如果是CANFD版本，给出额外提示
            if 'CANFD' in dll_file:
                print("   - 支持CAN 2.0B和CAN-FD协议")
            else:
                print("   - 支持CAN 2.0B协议")
            return True
    
    print("⚠️  警告：未找到CAN设备库文件")
    print("   系统可以启动，但无法与CAN设备通信")
    print("   请从以下途径获取DLL文件：")
    print("   1. CAN设备厂商提供的驱动安装包")
    print("   2. 从设备厂商官网下载最新驱动")
    print("   3. 联系设备供应商获取技术支持")
    print("   需要的文件之一：")
    for dll_file in dll_files:
        print(f"     - {dll_file}")
    print("   将DLL文件放置在项目根目录即可")
    
    return False

def check_project_files():
    """
    检查项目核心文件的完整性
    
    检查的关键文件：
    - can_control_server.py: 后端服务器主程序
    - web_interface.html: 前端控制界面
    - can_message_parser/can_parser.py: CAN消息解析器
    - can_protocol.dbc: CAN协议定义文件
    
    这些文件是系统正常运行的必需文件，任何一个缺失都会导致系统无法启动
    
    Returns:
        bool: True表示所有必需文件都存在，False表示有文件缺失
    """
    # 定义系统运行必需的核心文件
    required_files = [
        'can_control_server.py',         # 后端WebSocket服务器和CAN通信
        'web_interface.html',            # 前端用户界面
        'can_message_parser/can_parser.py',  # CAN消息解析逻辑
        'can_protocol.dbc'               # CAN协议和信号定义
    ]
    
    print("正在检查项目文件完整性...")
    
    missing_files = []
    for file_path in required_files:
        if not os.path.exists(file_path):
            missing_files.append(file_path)
            print(f"❌ 缺少关键文件：{file_path}")
        else:
            # 检查文件大小，确保不是空文件
            file_size = os.path.getsize(file_path)
            if file_size == 0:
                print(f"⚠️  警告：文件 {file_path} 为空")
            else:
                print(f"✅ 文件检查通过：{file_path} ({file_size:,} 字节)")
    
    if missing_files:
        print(f"\n❌ 发现 {len(missing_files)} 个缺失文件，系统无法正常运行")
        print("解决方案：")
        print("  1. 检查项目文件是否完整下载")
        print("  2. 重新下载或克隆项目")
        print("  3. 确认当前工作目录是项目根目录")
        return False
    else:
        print("✅ 所有必需文件检查通过")
        return True

def main():
    """
    主函数 - 系统启动的完整流程控制
    
    启动流程：
    1. Python环境检查 - 确保版本符合要求
    2. 项目文件完整性检查 - 确保所有必需文件存在
    3. 依赖包检查和自动安装 - 确保Python库完整
    4. 硬件设备库检查 - 检测CAN设备DLL
    5. 启动WebSocket服务器 - 开始提供服务
    
    异常处理：
    - 任何检查失败都会终止启动并给出解决建议
    - 用户中断(Ctrl+C)会安全关闭系统
    - 导入错误和运行时错误都有专门的处理逻辑
    
    Returns:
        bool: True表示系统正常启动和关闭，False表示启动失败
    """
    print("🚀 CAN总线挖掘机遥控系统启动检查")
    print("=" * 50)
    print("正在进行系统环境检查，请稍候...")
    print()
    
    # 第一步：检查Python运行环境
    print("🔍 第一步：检查Python环境")
    if not check_python_version():
        print("\n系统启动终止：Python版本不符合要求")
        input("按Enter键退出...")
        return False
    print()
    
    # 第二步：检查项目文件完整性
    print("📁 第二步：检查项目文件")
    if not check_project_files():
        print("\n❌ 系统启动终止：项目文件不完整")
        print("请确保所有必需文件存在后重试")
        input("按Enter键退出...")
        return False
    print()
    
    # 第三步：检查Python依赖包
    print("📦 第三步：检查Python依赖")
    missing_packages = check_dependencies()
    if missing_packages:
        return False
    print()
    
    # 第四步：检查CAN设备硬件库
    print("🔌 第四步：检查CAN设备库")
    has_can_dll = check_can_dll()
    if not has_can_dll:
        print("⚠️  系统将在仅软件模式下启动（无CAN通信功能）")
    print()
    
    # 第五步：启动系统服务
    print("🎯 第五步：启动系统服务")
    print("-" * 40)
    print("所有检查完成，正在启动CAN总线遥控系统...")
    print("提示：")
    print("  - 启动后请在浏览器中打开 web_interface.html")
    print("  - 使用 Ctrl+C 可以安全停止系统")
    print("  - 系统日志将实时显示在此窗口中")
    print("-" * 40)
    
    try:        
        # 动态导入并启动服务器
        print("🖥️  正在启动WebSocket服务器...")
        import can_control_server
        import asyncio
        
        # 运行异步服务器主循环
        asyncio.run(can_control_server.main())
        
    except KeyboardInterrupt:
        # 用户主动停止系统（Ctrl+C）
        print("\n⏹️  接收到停止信号，正在安全关闭系统...")
        print("正在清理资源...")
        time.sleep(1)  # 给系统一点时间清理资源
        
    except ImportError as e:
        # 模块导入失败
        print(f"\n❌ 模块导入失败：{e}")
        print("可能的原因：")
        print("  1. can_control_server.py 文件损坏或缺失")
        print("  2. Python依赖包未正确安装")
        print("  3. 项目目录结构不正确")
        print("建议：重新下载项目或检查文件完整性")
        input("按Enter键退出...")
        return False
        
    except Exception as e:
        # 其他运行时错误
        print(f"\n❌ 系统运行异常：{e}")
        print("这可能是一个未预期的错误，请联系开发者或查看详细错误信息")
        print(f"错误类型：{type(e).__name__}")
        input("按Enter键退出...")
        return False
    
    print("\n✅ 系统已安全关闭，感谢使用CAN总线遥控系统")
    return True

if __name__ == '__main__':
    """
    脚本入口点
    
    程序的入口点，当直接运行此脚本时会执行这里的代码。
    包含了最外层的异常处理，确保任何未捕获的异常都能被妥善处理。
    
    退出码说明：
    - 0: 正常退出（系统成功启动并正常关闭）
    - 1: 异常退出（启动失败或运行时出现严重错误）
    """
    try:
        # 调用主函数开始系统启动流程
        success = main()
        
        if not success:
            # 启动失败，以错误码1退出
            print("系统启动失败，程序即将退出")
            sys.exit(1)
        else:
            # 正常启动和关闭，以成功码0退出
            sys.exit(0)
            
    except Exception as e:
        # 捕获所有未处理的异常，避免程序崩溃时没有错误提示
        print(f"\n💥 启动脚本发生未预期的异常：{e}")
        print(f"异常类型：{type(e).__name__}")
        print("这可能是一个严重的系统错误，请联系开发者")
        print("或者尝试以下步骤：")
        print("  1. 重新下载项目文件")
        print("  2. 检查Python版本和环境")
        print("  3. 查看是否有权限问题")
        
        # 等待用户确认后退出
        input("\n按Enter键退出...")
        sys.exit(1)
