#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
增强型CAN消息解析器 - 使用cantools解析指定的CAN消息
支持彩色输出、详细的信号说明和更好的格式化
作者：Claude AI助手
日期：2025年9月13日
"""

import cantools
import struct
from datetime import datetime
from typing import Dict, Any, List
import sys

class Colors:
    """ANSI颜色代码"""
    RED = '\033[91m'
    GREEN = '\033[92m'
    YELLOW = '\033[93m'
    BLUE = '\033[94m'
    MAGENTA = '\033[95m'
    CYAN = '\033[96m'
    WHITE = '\033[97m'
    BOLD = '\033[1m'
    UNDERLINE = '\033[4m'
    END = '\033[0m'

def print_colored(text: str, color: str = Colors.WHITE, end: str = '\n'):
    """打印彩色文本"""
    print(f"{color}{text}{Colors.END}", end=end)

def print_header(text: str):
    """打印标题"""
    print_colored(f"\n{Colors.BOLD}{Colors.CYAN}{'=' * 80}", Colors.CYAN)
    print_colored(f"{Colors.BOLD}{text}", Colors.CYAN)
    print_colored(f"{'=' * 80}{Colors.END}", Colors.CYAN)

def print_separator():
    """打印分隔线"""
    print_colored("-" * 80, Colors.YELLOW)

class EnhancedCANParser:
    """增强型CAN消息解析器"""
    
    def __init__(self, dbc_path: str = 'can_protocol.dbc'):
        """初始化解析器"""
        self.dbc_path = dbc_path
        self.db = None
        self.load_dbc()
        
        # 信号单位映射
        self.unit_descriptions = {
            "mA": "毫安",
            "V": "伏特", 
            "A": "安培",
            "rpm": "转/分钟",
            "Nm": "牛·米",
            "W": "瓦特",
            "°": "度"
        }
        
        # 消息类型映射
        self.message_types = {
            0x18000001: {"name": "底盘控制", "type": "控制指令"},
            0x18000002: {"name": "液压电机控制", "type": "控制指令"},
            0x18000003: {"name": "行走电机控制", "type": "控制指令"},
            0x18000004: {"name": "执行器电磁阀控制", "type": "控制指令"}
        }
        
    def load_dbc(self):
        """加载DBC文件"""
        try:
            self.db = cantools.database.load_file(self.dbc_path, encoding='utf-8')
            print_colored(f"✓ 成功加载DBC文件: {self.dbc_path}", Colors.GREEN)
        except Exception as e:
            print_colored(f"✗ 加载DBC文件失败: {e}", Colors.RED)
            sys.exit(1)
    
    def format_raw_message(self, raw_msg: str) -> Dict[str, Any]:
        """
        将原始CAN消息格式转换为结构化数据
        输入格式: "18000001x Rx d 8 01 02 00 00 00 00 00 00"
        """
        parts = raw_msg.strip().split()
        
        if len(parts) < 4:
            raise ValueError(f"消息格式不正确: {raw_msg}")
        
        # 提取ID (去掉末尾的x)
        msg_id = int(parts[0].rstrip('x'), 16)
        
        # 提取方向 (Rx/Tx)
        direction = parts[1]
        
        # 提取数据长度
        data_length = int(parts[3])
        
        # 提取数据字节
        data_bytes = []
        for i in range(4, 4 + data_length):
            if i < len(parts):
                data_bytes.append(int(parts[i], 16))
        
        return {
            'id': msg_id,
            'direction': direction,
            'length': data_length,
            'data': bytes(data_bytes),
            'timestamp': datetime.now()
        }
    
    def get_signal_description(self, message_name: str, signal_name: str) -> str:
        """获取信号的详细描述"""
        descriptions = {
            # Chassis_Control 底盘控制消息
            ("Chassis_Control", "HighVoltage_Enable"): "整车上高压控制：1=上高压开管，0=下高压关管",
            ("Chassis_Control", "Soft_Emergency_Stop"): "软急停：1=停止PWM和行进电机输出，0=不生效",
            ("Chassis_Control", "Left_Turn_Light"): "左转灯控制：1=使能",
            ("Chassis_Control", "Right_Turn_Light"): "右转灯控制：1=使能",
            ("Chassis_Control", "Vehicle_Mode"): "整车模式切换：1=翻转当前状态",
            ("Chassis_Control", "Heartbeat_Signal"): "心跳信号：200ms翻转一次",
            ("Chassis_Control", "Speed_Gear"): "速度挡位：0=低速档，1=高速档",
            ("Chassis_Control", "Work_Light"): "工作大灯：0=关闭，1=开启",
            ("Chassis_Control", "Clear_Steering_Error"): "清除转向阀错误：1=生效一次",
            ("Chassis_Control", "High_Beam"): "远光灯：0=关闭，1=开启",
            ("Chassis_Control", "Low_Beam"): "近光灯：0=关闭，1=开启",
            ("Chassis_Control", "Horn"): "喇叭：0=关闭，1=开启",
            ("Chassis_Control", "Sound_Light_Alarm"): "声光报警器：每个bit对应红绿蓝黄白",
            ("Chassis_Control", "Clear_Error"): "清错：1=生效一次，退出心跳安全状态",
            
            # Hydraulic_Motor_Control 液压电机控制消息
            ("Hydraulic_Motor_Control", "Hydraulic_Motor_Enable"): "液压电机使能：0=不使能，1=使能",
            ("Hydraulic_Motor_Control", "Hydraulic_Motor_Mode"): "液压电机工作模式：0=不控制，1=扭矩，2=转速",
            ("Hydraulic_Motor_Control", "Hydraulic_Economy_Mode"): "液压电机经济模式：0=标准，1=经济，2=动力",
            ("Hydraulic_Motor_Control", "Steering_Valve_Direction"): "转向电磁阀方向：0=不控制，1=左转，2=右转",
            ("Hydraulic_Motor_Control", "Hydraulic_Motor_Torque"): "液压电机请求扭矩（范围-3000~3000）",
            ("Hydraulic_Motor_Control", "Hydraulic_Motor_Speed"): "液压电机请求转速（范围-15000~15000）",
            ("Hydraulic_Motor_Control", "Steering_Valve_Current"): "转向电磁阀电流控制：0~1500mA",
            
            # Walking_Motor_Control 行走电机控制消息
            ("Walking_Motor_Control", "Walking_Motor_Enable"): "行走电机使能：0=不使能，1=使能",
            ("Walking_Motor_Control", "Walking_Motor_Mode"): "行走电机工作模式：0=不控制，1=扭矩，2=转速",
            ("Walking_Motor_Control", "Walking_Motor_Direction"): "行走电机方向：0=空档，1=前进档，2=后退档",
            ("Walking_Motor_Control", "Walking_Economy_Mode"): "行走电机经济模式：0=标准，1=经济，2=动力",
            ("Walking_Motor_Control", "Walking_Motor_Speed"): "行走电机请求转速（范围-15000~15000）",
            ("Walking_Motor_Control", "Walking_Motor_Torque"): "行走电机请求扭矩（范围-3000~3000）",
            ("Walking_Motor_Control", "Brake_Valve_Current"): "刹车电磁阀：400~1600mA",
            
            # Actuator_Valve_Control 执行器电磁阀控制消息
            ("Actuator_Valve_Control", "Boom_Lift_Valve_Current"): "大臂抬电磁阀: 电流控制0~1500mA",
            ("Actuator_Valve_Control", "Boom_Lower_Valve_Current"): "大臂降电磁阀: 电流控制0~1500mA",
            ("Actuator_Valve_Control", "Bucket_Retract_Valve_Current"): "铲斗内收电磁阀: 电流控制0~1500mA",
            ("Actuator_Valve_Control", "Bucket_Tilt_Valve_Current"): "铲斗外翻电磁阀: 电流控制0~1500mA"
        }
        
        return descriptions.get((message_name, signal_name), "")
    
    def format_signal_value(self, value: Any, unit: str = "") -> str:
        """格式化信号值"""
        if isinstance(value, float):
            return f"{value:.2f} {unit}".strip()
        elif isinstance(value, int):
            if unit:
                return f"{value} {unit}"
            else:
                return str(value)
        else:
            return str(value)
    
    def parse_message(self, formatted_msg: Dict[str, Any]) -> Dict[str, Any]:
        """解析单个CAN消息"""
        try:
            # 查找消息定义
            message_def = self.db.get_message_by_frame_id(formatted_msg['id'])
            
            # 解码消息数据
            decoded_data = self.db.decode_message(formatted_msg['id'], formatted_msg['data'])
            
            result = {
                'message_def': message_def,
                'decoded_data': decoded_data,
                'success': True,
                'error': None
            }
            
        except Exception as e:
            result = {
                'message_def': None,
                'decoded_data': None,
                'success': False,
                'error': str(e)
            }
            
        return result
    
    def print_message_header(self, formatted_msg: Dict[str, Any], index: int):
        """打印消息头部信息"""
        msg_type = self.message_types.get(formatted_msg['id'], {"name": "未知消息", "type": "未知"})
        
        print_colored(f"\n📨 消息 {index}: {msg_type['name']} ({msg_type['type']})", Colors.BOLD + Colors.BLUE)
        print_colored(f"⏰ 时间戳: {formatted_msg['timestamp'].strftime('%Y-%m-%d %H:%M:%S.%f')[:-3]}", Colors.CYAN)
        print_colored(f"🆔 消息ID: 0x{formatted_msg['id']:08X} ({formatted_msg['id']})", Colors.MAGENTA)
        print_colored(f"📡 方向: {formatted_msg['direction']}", Colors.YELLOW)
        print_colored(f"📏 长度: {formatted_msg['length']} 字节", Colors.GREEN)
        print_colored(f"📊 原始数据: {' '.join([f'{b:02X}' for b in formatted_msg['data']])}", Colors.WHITE)
    
    def print_decoded_signals(self, message_def, decoded_data: Dict[str, Any]):
        """打印解码后的信号"""
        print_colored(f"\n🔍 解析结果:", Colors.BOLD + Colors.GREEN)
        
        for signal_name, value in decoded_data.items():
            try:
                signal_def = message_def.get_signal_by_name(signal_name)
                unit = signal_def.unit if signal_def.unit else ""
                
                # 格式化值
                formatted_value = self.format_signal_value(value, unit)
                
                # 获取描述
                description = self.get_signal_description(message_def.name, signal_name)
                
                # 确定值的状态颜色
                if isinstance(value, (int, float)) and value > 0:
                    value_color = Colors.GREEN
                else:
                    value_color = Colors.WHITE
                
                print_colored(f"  📍 {signal_name}:", Colors.CYAN, end="")
                print_colored(f" {formatted_value}", value_color)
                
                if description:
                    print_colored(f"     💡 {description}", Colors.YELLOW)
                    
            except Exception as e:
                print_colored(f"  ❌ {signal_name}: 解析失败 - {e}", Colors.RED)
    
    def parse_raw_messages(self, raw_messages: List[str]):
        """解析原始格式的CAN消息列表"""
        print_header("🚗 增强型CAN消息解析器")
        print_colored(f"📁 DBC文件: {self.dbc_path}", Colors.GREEN)
        print_colored(f"📦 消息数量: {len(raw_messages)}", Colors.BLUE)
        
        for i, raw_msg in enumerate(raw_messages, 1):
            print_separator()
            
            try:
                # 格式化原始消息
                formatted_msg = self.format_raw_message(raw_msg)
                
                # 打印消息头部信息
                self.print_message_header(formatted_msg, i)
                
                # 解析消息
                parse_result = self.parse_message(formatted_msg)
                
                if parse_result['success']:
                    print_colored(f"✅ 消息解析成功: {parse_result['message_def'].name}", Colors.GREEN)
                    self.print_decoded_signals(parse_result['message_def'], parse_result['decoded_data'])
                else:
                    print_colored(f"❌ 消息解析失败: {parse_result['error']}", Colors.RED)
                    
            except Exception as e:
                print_colored(f"❌ 处理消息失败: {e}", Colors.RED)
        
        print_separator()
        print_colored("\n✅ 所有消息解析完成！", Colors.BOLD + Colors.GREEN)

def main():
    """主函数"""
    # 原始消息列表
    raw_messages = [
        "18000001x Rx d 8 01 02 00 00 00 00 00 00",
        "18000002x Rx d 8 03 B8 0B 38 4A 00 00 00", 
        "18000003x Rx d 8 05 98 3A B8 0B BC 02 00",
        "18000004x Rx d 8 00 00 00 00 C3 00 00 00"
    ]
    
    # 创建解析器并解析消息
    parser = EnhancedCANParser()
    parser.parse_raw_messages(raw_messages)

if __name__ == "__main__":
    main()
