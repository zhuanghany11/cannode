#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
CAN消息解析器 - 游戏手柄到CAN消息转换核心
===========================================

这是系统的核心解析模块，负责以下关键功能：

核心功能：
1. 游戏手柄数据到CAN消息的转换和映射
2. CAN消息的DBC协议解析和信号提取
3. 消息方向判断和数据格式化
4. 控制状态管理（累积控制、上升沿触发等）

设计特点：
- 双向解析：支持发送消息生成和接收消息解析
- 状态管理：维护游戏手柄的累积状态和触发状态
- DBC支持：自动解析DBC文件中的信号定义
- 容错处理：在cantools库缺失时提供简化解析功能

控制映射策略：
- 摇杆控制：连续值控制（大臂、铲斗等液压动作）
- 方向键：累积值控制（速度、转向等渐进调节）
- 按钮：档位控制和状态切换（前进后退、开关等）
- 肩键：上升沿触发的开关控制（档位切换、灯光等）


"""

import json
import math
import struct
import logging
from typing import Dict, List, Any, Tuple, Optional
from enum import Enum
from .data_assignment import DataAssignmentHandler, CANMessage

# ====== 日志系统配置 ======
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s:%(lineno)d - %(levelname)s - %(message)s',
    handlers=[
        logging.StreamHandler()  # 输出到控制台
        # 如需输出到文件，可以添加：FileHandler('can_server.log')
    ]
)
logger = logging.getLogger(__name__)
logger.info("启动脚本初始化完成")

# ====== DBC解析库导入 ======
# cantools是可选依赖，提供完整的DBC文件解析功能
try:
    import cantools
    logger.info("cantools库已加载，支持完整DBC解析功能")
except ImportError:
    cantools = None
    logger.warning("cantools库未安装，将使用简化版DBC解析功能")
    logger.info("如需完整功能，请安装：pip install cantools")

class MessageDirection(Enum):
    """
    CAN消息方向枚举类
    =================
    
    用于标识CAN消息的传输方向：
    - SEND: 主机发送到设备（控制命令）
    - RECV: 设备发送到主机（状态反馈）
    """
    SEND = "send"  # 发送方向（主机 → 设备）
    RECV = "recv"  # 接收方向（设备 → 主机）

class JSONMessage:
    """
    JSON消息结构体类
    ================
    
    用于封装CAN消息的所有信息，包括：
    - 消息ID和方向
    - 原始二进制数据
    - 解析后的结构化数据
    - 时间戳信息
    
    支持多种输出格式，便于前端显示和调试。
    """

    def __init__(self, message_id: int, direction: MessageDirection, raw_data: bytes, parsed_data: Dict[str, Any] = None):
        """
        初始化JSON消息对象
        
        Args:
            message_id: CAN消息ID
            direction: 消息方向（发送/接收）
            raw_data: 原始CAN数据（bytes格式）
            parsed_data: 可选的解析后数据字典
        """
        self.id = message_id                    # CAN消息ID
        self.direction = direction              # 消息传输方向
        self.raw_data = raw_data                # 原始字节数据
        self.parsed_data = parsed_data or {}    # 解析后的结构化数据
        self.timestamp = None                   # 消息时间戳（稍后设置）

    def to_json(self) -> Dict[str, Any]:
        """
        转换为标准JSON格式
        
        包含完整的消息信息，适合调试和日志记录。
        
        Returns:
            包含所有消息信息的字典
        """
        return {
            "id": self.id,
            "direction": self.direction.value,
            "parsed_data": self.parsed_data,
            "raw_data": list(self.raw_data),     # 转换bytes为数字列表
            "hex_data": ' '.join(f'{b:02X}' for b in self.raw_data),  # 十六进制表示
            "timestamp": self.timestamp
        }
    
    def to_json_with_signals(self, signal_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        转换为包含信号数据的JSON格式
        
        这是发送给前端的主要格式，包含解析后的信号值。
        
        Args:
            signal_data: 从DBC解析得到的信号数据字典
            
        Returns:
            适合前端显示的消息格式
        """
        return {
            "type": "can_message",
            "id": self.id,
            "direction": self.direction.value,
            "hex_data": ' '.join(f'{b:02X}' for b in self.raw_data),
            "signal_data": signal_data  # DBC解析的信号值
        }

    def __str__(self):
        """
        字符串表示方法
        
        Returns:
            人类可读的消息描述字符串
        """
        hex_data = ' '.join(f'{b:02X}' for b in self.raw_data)
        direction_str = "发送" if self.direction == MessageDirection.SEND else "接收"
        return f"CAN消息 ID: 0x{self.id:08X}, 方向: {direction_str}, 数据: [{hex_data}]"



class CANMessageParser:
    """
    CAN消息解析器核心类
    ===================
    
    系统的核心解析引擎，负责：
    1. 游戏手柄数据到CAN消息的转换
    2. DBC文件的加载和信号解析
    3. 控制状态的管理和维护
    4. CAN消息的双向解析功能
    
    控制状态管理包括：
    - 累积控制状态（速度、转向等渐进调节）
    - 触发状态（按钮上升沿检测）
    - 档位状态（前进、后退、空档）
    - 开关状态（灯光、喇叭等）
    """

    def __init__(self, dbc_file_path: str = "can_protocol.dbc"):
        self.dbc_file_path = dbc_file_path
        self.db = None
        self.message_definitions = {}

        # 控制状态管理 - 用于上升沿触发和累积控制
        self.control_states = {
            # 上升沿触发的toggle状态
            'speed_gear_toggle': False,  # 当前速度档位状态
            'work_light_toggle': False,  # 当前工作灯状态
            
            # 按钮上一次状态，用于检测上升沿
            'prev_left_bumper': False,
            'prev_right_bumper': False,
            'prev_left_trigger': 0.0,    # 急停按钮上一次状态
            'prev_right_trigger': 0.0,    # 手刹按钮上一次状态

            # 累积控制状态
            'steering_accumulator': 0,    # 转向累积值 (-100 到 100)
            'walking_torque_accumulator': 0,       # 速度累积值 (0 到 100)
            
            # 当前档位状态
            'current_gear': 0,            # 当前档位 (0=空档, 1=前进, 2=后退)

            'parking_brake_toggle': False,    # 手刹状态

            # 心跳状态
            'heartbeat_state': False,
            'heartbeat_counter': 0,
            # 急停状态管理
            'emergency_stop_active': False,  # 急停激活状态
            
            # 电磁阀控制状态
            'boom_lift_valve_current': 0,     # 大臂抬电磁阀电流 (0-1500mA)
            'boom_lower_valve_current': 0,    # 大臂降电磁阀电流 (0-1500mA)
            'bucket_retract_valve_current': 0, # 铲斗内收电磁阀电流 (0-1500mA)
            'bucket_tilt_valve_current': 0,   # 铲斗外翻电磁阀电流 (0-1500mA)
        }

        # 如果有cantools库，使用它解析DBC
        if cantools:
            try:
                # 使用non-strict模式加载DBC文件
                self.db = cantools.database.load_file(dbc_file_path, strict=False)
                logger.info(f"成功加载DBC文件: {dbc_file_path}")
            except Exception as e:
                logger.error(f"加载DBC文件失败: {e}")
                self.db = None
        else:
            logger.info("cantools库不可用，使用手动DBC解析")
            self._load_dbc_manually()
        
        # 创建数据分配处理器实例
        self.data_assignment_handler = DataAssignmentHandler(self.control_states)

    def _load_dbc_manually(self):
        """手动解析DBC文件（简化版）"""
        try:
            with open(self.dbc_file_path, 'r', encoding='utf-8') as f:
                content = f.read()

            # 解析消息定义
            self.message_definitions = self._parse_dbc_content(content)
            logger.info(f"手动解析DBC文件完成，找到 {len(self.message_definitions)} 个消息")

        except Exception as e:
            logger.error(f"手动解析DBC文件失败: {e}")
            self.message_definitions = {}

    def _parse_dbc_content(self, content: str) -> Dict[int, Dict[str, Any]]:
        """解析DBC内容"""
        messages = {}
        lines = content.split('\n')

        current_message = None
        i = 0

        while i < len(lines):
            line = lines[i].strip()

            # 消息定义开始
            if line.startswith('BO_ '):
                parts = line.split()
                if len(parts) >= 3:
                    msg_id = int(parts[1])
                    msg_name = parts[2]
                    current_message = {
                        'id': msg_id,
                        'name': msg_name,
                        'signals': {}
                    }
                    messages[msg_id] = current_message

            # 信号定义
            elif line.startswith('SG_ ') and current_message:
                parts = line.split(' : ')
                if len(parts) >= 2:
                    signal_info = parts[1].split()
                    if len(signal_info) >= 3:
                        signal_name = parts[0].replace('SG_ ', '').strip()
                        bit_info = signal_info[0]  # 位信息，如 "24|16@1+"
                        scale_offset = signal_info[1]  # 缩放和偏移，如 "(1,-15000)"
                        range_info = signal_info[2]  # 范围，如 "[-15000|15000]"

                        # 解析位信息
                        bit_parts = bit_info.split('|')
                        if len(bit_parts) >= 2:
                            start_bit = int(bit_parts[0])
                            bit_length = int(bit_parts[1].split('@')[0])

                            # 解析缩放和偏移
                            scale = 1.0
                            offset = 0.0
                            if scale_offset.startswith('(') and scale_offset.endswith(')'):
                                scale_str = scale_offset[1:-1]
                                if ',' in scale_str:
                                    scale_part, offset_part = scale_str.split(',')
                                    scale = float(scale_part)
                                    offset = float(offset_part)

                            current_message['signals'][signal_name] = {
                                'start_bit': start_bit,
                                'bit_length': bit_length,
                                'scale': scale,
                                'offset': offset,
                                'is_signed': '@1-' in bit_info
                            }

            i += 1

        return messages

    def parse_gamepad_data(self, gamepad_json: Dict[str, Any]) -> List[CANMessage]:
        """
        将游戏手柄JSON数据解析为CAN消息列表
        消息例子：{
            'type': 'gamepad_data', 
            'timestamp': 1757687498490, 
            'axes': {'left_x': 1.5259021896696368e-05, 'left_y': -1.5259021896696368e-05, 'right_x': 1.5259021896696368e-05, 'right_y': -1.5259021896696368e-05}, 
            'buttons': {'a': False, 'b': False, 'x': False, 'y': False, 'left_bumper': False, 'right_bumper': False, 'left_trigger': 0, 'right_trigger': 0}, 
            'dpad': {'up': False, 'down': False, 'left': False, 'right': False}
        }
        Args:
            gamepad_json: 游戏手柄数据JSON

        Returns:
            CAN消息列表
        """
        messages = []

        try:
            # ==================================
            #   以下是CAN消息的主要赋值部分，如果注释掉代码，则会发送全0数据；如果不希望发送数据，请在can_control_server.py中150行左右的can_message_cache对应消息注释掉，则全程不会发送
            # self.can_message_cache = {
            #     0x18000001: None,  # 控制命令消息
            #    # 0x18000002: None,  # 液压电机控制消息   比如注释掉这一行，那么就不会发送0x18000002消息
            #     0x18000003: None,  # 行走电机控制消息
            #     0x18000004: None   # 机构电磁阀控制消息
            # }
            # ==================================

            # 解析控制命令
            self.data_assignment_handler.check_emergency_stop(gamepad_json)

            # 解析车身控制消息0x18000001
            chassis_control_msg = self.data_assignment_handler.create_chassis_control_message(gamepad_json)
            if chassis_control_msg:
                messages.append(chassis_control_msg)

            # 解析液压电机控制消息0x18000002
            hydraulic_msg = self.data_assignment_handler.create_hydraulic_message(gamepad_json)
            if hydraulic_msg:
                messages.append(hydraulic_msg)

            # 解析行走电机控制消息0x18000003
            # TODO: 行走电机控制暂时不使用，尚未通过测试
            walking_msg = self.data_assignment_handler.create_walking_message(gamepad_json)
            if walking_msg:
                messages.append(walking_msg)

            # 解析机构电磁阀控制0x 18000004
            actuator_msg = self.data_assignment_handler.create_actuator_valve_control_message(gamepad_json)
            if actuator_msg:
                messages.append(actuator_msg)
            

            
            logger.info(f"当前控制状态: {self.control_states}")
            

        except Exception as e:
            logger.error(f"解析游戏手柄数据失败: {e}")

        return messages

    def reset_control_states(self):
        """重置所有控制状态 - 用于系统重启或急停时"""
        logger.info("重置控制状态")
        self.control_states = {
            # 上升沿触发的toggle状态
            'speed_gear_toggle': False,  # 当前速度档位状态
            'work_light_toggle': False,  # 当前工作灯状态
            
            # 按钮上一次状态，用于检测上升沿
            'prev_left_bumper': False,
            'prev_right_bumper': False,
            'prev_left_trigger': 0.0,    # 急停按钮上一次状态
            'prev_right_trigger': 0.0,    # 手刹按钮上一次状态

            # 累积控制状态
            'steering_accumulator': 0,    # 转向累积值 (-100 到 100)
            'walking_torque_accumulator': 0,       # 速度累积值 (0 到 100)
            
            # 当前档位状态
            'current_gear': 0,            # 当前档位 (0=空档, 1=前进, 2=后退)
            
            'parking_brake_toggle': False,    # 手刹状态
            
            # 急停状态管理
            'emergency_stop_active': False,  # 急停激活状态

            # 心跳状态
            'heartbeat_state': False,
            'heartbeat_counter': 0,

            # 电磁阀控制状态
            'boom_lift_valve_current': 0,     # 大臂抬电磁阀电流 (0-1500mA)
            'boom_lower_valve_current': 0,    # 大臂降电磁阀电流 (0-1500mA)
            'bucket_retract_valve_current': 0, # 铲斗内收电磁阀电流 (0-1500mA)
            'bucket_tilt_valve_current': 0,   # 铲斗外翻电磁阀电流 (0-1500mA)
        }

               


    def get_control_states(self) -> Dict[str, Any]:
        """获取当前控制状态 - 用于调试和监控"""
        return self.control_states.copy()



        
    def parse_received_message(self, message_id: int, data: bytes) -> Optional[JSONMessage]:
        """
        解析接收到的CAN消息为JSON消息结构体

        Args:
            message_id: CAN消息ID
            data: CAN消息数据

        Returns:
            JSONMessage对象或None
        """
        try:
            # 判断消息方向
            if (message_id & 0xFFFF0000) == 0x18000000:  # 0x1800开头 - 发送消息
                direction = MessageDirection.SEND
                parsed_data = self._parse_send_message(message_id, data)
            elif (message_id & 0xFFFF0000) == 0x18F10000:  # 0x18F1开头 - 接收消息
                direction = MessageDirection.RECV
                parsed_data = self._parse_recv_message(message_id, data)
            else:
                logger.warning(f"未知的消息ID格式: 0x{message_id:08X}")
                return None

            # 创建JSON消息结构体
            json_msg = JSONMessage(message_id, direction, data, parsed_data)

            return json_msg

        except Exception as e:
            logger.error(f"解析接收消息失败 (ID: 0x{message_id:08X}): {e}")
            return None

    def _parse_send_message(self, message_id: int, data: bytes) -> Dict[str, Any]:
        """解析发送消息的数据内容"""
        parsed_data = {}

        try:
            if message_id == 0x18000001:  # 控制命令
                parsed_data = {
                    "message_type": "control_command",
                    "speed_gear": bool(data[1] & (1 << 2)),  # bit 10
                    "heartbeat": bool(data[1] & (1 << 1)),   # bit 9
                    "description": "控制命令消息"
                }
            elif message_id == 0x18000002:  # 液压电机控制
                steering_direction = (data[0] >> 5) & 0x03
                motor_speed = struct.unpack('>H', data[3:5])[0]
                steering_current = struct.unpack('>H', data[5:7])[0]

                direction_map = {0: "停止", 1: "左转", 2: "右转"}

                parsed_data = {
                    "message_type": "hydraulic_motor_control",
                    "enabled": bool(data[0] & 0x01),
                    "steering_direction": direction_map.get(steering_direction, "未知"),
                    "motor_speed": motor_speed,
                    "steering_current": steering_current,
                    "description": "液压电机控制消息"
                }
            elif message_id == 0x18000003:  # 行走电机控制
                direction = (data[0] >> 3) & 0x03
                walking_speed = struct.unpack('>H', data[1:3])[0]
                brake_current = struct.unpack('>H', data[5:7])[0]

                direction_map = {0: "停止", 1: "前进", 2: "后退"}

                parsed_data = {
                    "message_type": "walking_motor_control",
                    "enabled": bool(data[0] & 0x01),
                    "direction": direction_map.get(direction, "未知"),
                    "walking_speed": walking_speed,
                    "brake_current": brake_current,
                    "description": "行走电机控制消息"
                }
        except Exception as e:
            logger.error(f"解析发送消息失败: {e}")

        return parsed_data

    def _parse_recv_message(self, message_id: int, data: bytes) -> Dict[str, Any]:
        """解析接收消息的数据内容"""
        parsed_data = {}

        try:
            # 0x18F1开头的反馈指令
            if (message_id & 0xFFFF0000) == 0x18F10000:
                feedback_type = message_id & 0xFF  # 最后8位表示反馈类型

                if feedback_type == 0x01:  # 系统状态反馈
                    parsed_data = {
                        "message_type": "system_status_feedback",
                        "system_voltage": data[0] * 0.1,  # 电压 (0.1V单位)
                        "motor_temperature": data[1],     # 电机温度 (°C)
                        "controller_status": data[2],     # 控制器状态
                        "error_code": data[3],            # 错误码
                        "description": "系统状态反馈消息"
                    }
                elif feedback_type == 0x02:  # 电机状态反馈
                    motor_id = (data[0] >> 4) & 0x0F
                    motor_speed = struct.unpack('>h', data[1:3])[0]  # 有符号16位
                    motor_current = struct.unpack('>H', data[3:5])[0]
                    motor_position = struct.unpack('>l', data[4:8])[0] if len(data) >= 8 else 0

                    parsed_data = {
                        "message_type": "motor_status_feedback",
                        "motor_id": motor_id,
                        "motor_speed": motor_speed,
                        "motor_current": motor_current,
                        "motor_position": motor_position,
                        "description": "电机状态反馈消息"
                    }
                elif feedback_type == 0x03:  # 传感器反馈
                    sensor_data = []
                    for i in range(0, len(data), 2):
                        if i + 1 < len(data):
                            sensor_value = struct.unpack('>H', data[i:i+2])[0]
                            sensor_data.append(sensor_value)

                    parsed_data = {
                        "message_type": "sensor_feedback",
                        "sensor_count": len(sensor_data),
                        "sensor_values": sensor_data,
                        "description": "传感器反馈消息"
                    }
                else:
                    parsed_data = {
                        "message_type": "unknown_feedback",
                        "feedback_type": feedback_type,
                        "description": f"未知反馈类型: 0x{feedback_type:02X}"
                    }

        except Exception as e:
            logger.error(f"解析接收消息失败: {e}")

        return parsed_data

    def create_json_message_batch(self, can_messages: List[CANMessage]) -> List[JSONMessage]:
        """
        将CAN消息列表转换为JSON消息结构体列表

        Args:
            can_messages: CAN消息列表

        Returns:
            JSON消息结构体列表
        """
        json_messages = []

        for can_msg in can_messages:
            json_msg = self.parse_received_message(can_msg.id, can_msg.data)
            if json_msg:
                json_messages.append(json_msg)

        return json_messages

    def get_message_info(self, message_id: int) -> Optional[Dict[str, Any]]:
        """获取消息信息"""
        if self.db:
            try:
                message = self.db.get_message_by_frame_id(message_id)
                return {
                    'id': message.frame_id,
                    'name': message.name,
                    'length': message.length,
                    'signals': [sig.name for sig in message.signals]
                }
            except:
                return None
        else:
            return self.message_definitions.get(message_id)

    def parse_signals_from_data(self, message_id: int, data: bytes) -> Dict[str, Any]:
        """
        使用cantools解析消息数据中的信号值
        
        Args:
            message_id: CAN消息ID
            data: CAN消息数据
            
        Returns:
            信号名称和值的字典
        """
        signal_data = {}
        
        try:
            if self.db:
                # 直接使用cantools的decode功能
                message = self.db.get_message_by_frame_id(message_id)
                signal_data = message.decode(data)
            else:
                logger.warning(f"DBC数据库未加载，无法解析消息 0x{message_id:08X}")
                
        except Exception as e:
            logger.error(f"解析信号失败 (ID: 0x{message_id:08X}): {e}")

        return signal_data

    def parse_message_with_signals(self, message_id: int, data: bytes, direction: MessageDirection) -> JSONMessage:
        """
        解析CAN消息并返回包含信号数据的JSONMessage对象
        
        Args:
            message_id: CAN消息ID
            data: CAN消息数据
            direction: 消息方向
            
        Returns:
            JSONMessage对象
        """
        # 解析信号数据
        signal_data = self.parse_signals_from_data(message_id, data)
        
        # 创建JSONMessage对象
        json_msg = JSONMessage(message_id, direction, data)
        
        return json_msg, signal_data


