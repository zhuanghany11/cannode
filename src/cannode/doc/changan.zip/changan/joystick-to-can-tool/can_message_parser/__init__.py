"""
CAN消息解析器包
用于将游戏手柄JSON数据转换为CAN消息
"""

from .can_parser import CANMessageParser

__version__ = "1.0.0"
__all__ = ['CANMessageParser']
