#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
CAN消息数据分配器 - 控制指令生成核心
=====================================

此模块负责将游戏手柄的输入数据转换为具体的CAN消息格式。
实现了完整的控制逻辑映射，包括各种控制模式和安全机制。

主要功能：
1. 车身控制命令消息生成 - 系统级控制指令
2. 液压电机控制消息 - 转向和液压泵控制
3. 行走电机控制消息 - 前进后退和速度控制  
4. 机构电磁阀控制消息 - 大臂和铲斗动作控制

控制特性：
- 累积式控制：转向和速度采用累积调节模式
- 上升沿触发：档位和开关采用边沿触发
- 死区处理：摇杆输入具有死区防抖功能
- 电流映射：将控制强度转换为实际电流值


"""

import struct
import logging
from typing import Dict, Any, Optional

# ====== 日志系统配置 ======
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s:%(lineno)d - %(levelname)s - %(message)s',
    handlers=[
        logging.StreamHandler()  # 输出到控制台
        # 如需输出到文件，可以添加：FileHandler('can_server.log')
    ]
)
logger = logging.getLogger(__name__)
logger.info("启动脚本初始化完成")

class CANMessage:
    """
    CAN消息封装类
    =============
    
    封装单个CAN消息的所有信息，包括ID、数据和长度。
    提供便捷的格式转换和显示功能。
    """

    def __init__(self, message_id: int, data: bytes, length: int = 8):
        """
        初始化CAN消息
        
        Args:
            message_id: CAN消息ID (32位)
            data: 消息数据 (最多8字节)
            length: 数据长度 (默认8字节)
        """
        self.id = message_id
        self.data = data
        self.length = length

    def to_dict(self) -> Dict[str, Any]:
        """转换为字典格式，便于JSON序列化"""
        return {
            'id': self.id,
            'data': list(self.data),
            'length': self.length
        }

    def __str__(self):
        """字符串表示，便于日志输出和调试"""
        data_hex = ' '.join(f'{b:02X}' for b in self.data)
        return f"CAN ID: 0x{self.id:08X}, Data: [{data_hex}]"


class DataAssignmentHandler:
    """
    数据分配处理器核心类
    ===================
    
    负责将游戏手柄的各种输入转换为对应的CAN控制消息。
    实现了完整的控制逻辑，包括各种控制模式和状态管理。
    
    处理的消息类型：
    - 0x18000001: 车身控制命令（档位、灯光、喇叭等）
    - 0x18000002: 液压电机控制（转向、液压泵）
    - 0x18000003: 行走电机控制（前进后退、速度）
    - 0x18000004: 机构电磁阀控制（大臂、铲斗）
    """
    
    def __init__(self, control_states: Dict[str, Any]):
        """
        初始化数据分配处理器
        
        Args:
            control_states: 控制状态字典的引用，用于状态管理和累积控制
        """
        self.control_states = control_states
    
    
    def check_emergency_stop(self, gamepad_data: Dict[str, Any]) -> bool:
        """
        检测急停状态（left_trigger > 0.1的上升沿）
        
        Args:
            gamepad_data: 游戏手柄数据
            案例如下{
                'type': 'gamepad_data', 
                'timestamp': 1757687498490, 
                'axes': {'left_x': 1.5259021896696368e-05, 'left_y': -1.5259021896696368e-05, 'right_x': 1.5259021896696368e-05, 'right_y': -1.5259021896696368e-05}, 
                'buttons': {'a': False, 'b': False, 'x': False, 'y': False, 'left_bumper': False, 'right_bumper': False, 'left_trigger': 0, 'right_trigger': 0}, 
                'dpad': {'up': False, 'down': False, 'left': False, 'right': False}
            }
        Returns:
            bool: True如果检测到急停触发
        """
        buttons = gamepad_data.get('buttons', {})
        current_left_trigger = buttons.get('left_trigger', 0.0)
        prev_left_trigger = self.control_states.get('prev_left_trigger', 0.0)
        
        # 检测上升沿：当前值>0.1且上一次值<=0.1
        emergency_triggered = (current_left_trigger > 0.1 and prev_left_trigger <= 0.1)
        
        if emergency_triggered:
            # 切换急停状态
            self.control_states['emergency_stop_active'] = not self.control_states['emergency_stop_active']
            logger.warning(f"急停状态切换: {'激活' if self.control_states['emergency_stop_active'] else '解除'}")
        
        # 更新上一次trigger状态
        self.control_states['prev_left_trigger'] = current_left_trigger
        
        return self.control_states['emergency_stop_active']
    
    def create_chassis_control_message(self, gamepad_data: Dict[str, Any]) -> Optional[CANMessage]:
        """创建控制命令消息 (ID: 0x18000001)"""
        message_id = 0x18000001
        data = bytearray([0] * 8)  # 8字节数据，初始化为0

        try:
            # 解析按钮状态
            buttons = gamepad_data.get('buttons', {})
            
            # 默认启用高压 (bit 0)
            data[0] |= 1  # HighVoltage_Enable

            # 软急停 （bit 2）
            if self.control_states['emergency_stop_active']:
                data[0] |= (1 << 2)

            # 心跳信号现在在发送时由CAN通信线程直接更新
            # 这里不再设置心跳位，避免与发送时的更新冲突
            
            # left_bumper上升沿触发速度档位toggle
            current_left_bumper = buttons.get('left_bumper', False)
            if current_left_bumper and not self.control_states['prev_left_bumper']:
                # 检测到上升沿，切换速度档位
                self.control_states['speed_gear_toggle'] = not self.control_states['speed_gear_toggle']
                logger.info(f"速度档位切换: {'高速档' if self.control_states['speed_gear_toggle'] else '低速档'}")
            self.control_states['prev_left_bumper'] = current_left_bumper
            # 设置速度档位 (bit 10)
            if self.control_states['speed_gear_toggle']:
                data[1] |= (1 << 2)  # bit 10 = byte 1, bit 2


            # right_bumper上升沿触发工作灯toggle
            current_right_bumper = buttons.get('right_bumper', False)
            if current_right_bumper and not self.control_states['prev_right_bumper']:
                # 检测到上升沿，切换工作灯状态
                self.control_states['work_light_toggle'] = not self.control_states['work_light_toggle']
                logger.info(f"工作灯切换: {'开启' if self.control_states['work_light_toggle'] else '关闭'}")
            self.control_states['prev_right_bumper'] = current_right_bumper
            # 设置工作灯 (bit 11)
            if self.control_states['work_light_toggle']:
                data[1] |= (1 << 3)  # Work_Light
            


            # # 调试打印 - 控制命令消息
            # logger.debug(f"控制命令消息 - 心跳: {'1' if self.control_states.get('heartbeat_state', False) else '0'}({heartbeat_counter}/20), "
            #             f"速度档位: {'高速' if self.control_states['speed_gear_toggle'] else '低速'}, "
            #             f"工作灯: {'开启' if self.control_states['work_light_toggle'] else '关闭'}, "
            #             f"手刹: {'拉起' if self.control_states['parking_brake_toggle'] else '松开'}")

            return CANMessage(message_id, bytes(data))

        except Exception as e:
            logger.error(f"创建控制命令消息失败: {e}")
            return None



    def create_hydraulic_message(self, gamepad_data: Dict[str, Any]) -> Optional[CANMessage]:
        """创建液压电机控制消息 (ID: 0x18000002)"""
        message_id = 0x18000002
        data = bytearray([0] * 8)  # 8字节数据，初始化为0

        try:
            # 解析摇杆和方向键用于转向控制
            axes = gamepad_data.get('axes', {})
            dpad = gamepad_data.get('dpad', {})
            left_x = axes.get('left_x', 0.0)  # 左摇杆X轴
            
            # 转向控制：结合左摇杆X轴
            steering_increment = 5  # D-Pad每次增减5个单位
            max_steering = 100      # 最大转向值
            
            # 确保转向累积器初始化
            if 'steering_accumulator' not in self.control_states:
                self.control_states['steering_accumulator'] = 0
                
            old_steering = self.control_states['steering_accumulator']
            
            # 左摇杆X轴转向控制（大于阈值时累积式控制）
            joystick_threshold = 0.15  # 摇杆死区
            joystick_steering_increment = 5  # 摇杆每次增减的固定值
            
            if left_x > joystick_threshold:
                # 右转 - 增加转向值
                self.control_states['steering_accumulator'] = min(
                    self.control_states['steering_accumulator'] + joystick_steering_increment, 
                    max_steering
                )
            elif left_x < -joystick_threshold:
                # 左转 - 减少转向值
                self.control_states['steering_accumulator'] = max(
                    self.control_states['steering_accumulator'] - joystick_steering_increment, 
                    -max_steering
                )
            # 根据累积值确定转向方向
            steering_direction = 0  # 0=不控制
            steering_current = 0
            if self.control_states['steering_accumulator'] < -10:  # 左转死区
                steering_direction = 1  # 左转
                # 根据转向强度设置电流 (300-1500mA)
                steering_current = int(1000 + abs(self.control_states['steering_accumulator']))
                steering_current = min(steering_current, 1500)
            elif self.control_states['steering_accumulator'] > 10:  # 右转死区
                steering_direction = 2  # 右转
                # 根据转向强度设置电流 (300-1500mA)
                steering_current = int(1000 + self.control_states['steering_accumulator'])
                steering_current = min(steering_current, 1500)

            # 默认液压电机使能 (bit 0)
            data[0] |= 1

            # 默认电机工作模式 (bit 1-2): 1=扭矩模式 2=转速模式
            # TODO 这里dbc本身存在一定问题，需要确认模式（目前看起来1应该是转速模式）
            data[0] |= (1 << 1)

            # 设置转向阀方向 (bit 5-6, 2bit)
            data[0] |= (steering_direction << 5)

            hydraulic_motor_torque = 3000 # 物理量3000 Nm
            b = hydraulic_motor_torque.to_bytes(2, 'little') # 修复：使用小端序，与DBC定义@1+一致
            data[1] = b[0]  # bit 8-15 (低字节)
            data[2] = b[1]  # bit 16-23 (高字节)

            # 设置液压电机请求转速，范围-15000~15000，默认2000转，即底层数据发送17000
            hydraulic_motor_speed = 17000 # 物理量2000 rpm
            b = hydraulic_motor_speed.to_bytes(2, 'little') # 修复：使用小端序，与DBC定义@1+一致
            data[3] = b[0]  # bit 24-31 (低字节)
            data[4] = b[1]  # bit 32-39 (高字节)

            # 设置转向阀电流 (bit 40-55, 16bit)
            # current_bytes = struct.pack('>H', steering_current & 0xFFFF)
            current_bytes = steering_current.to_bytes(2, 'little')
            data[5] = current_bytes[0]  # bit 40-47
            data[6] = current_bytes[1]  # bit 48-55

            # 调试打印 - 液压电机消息
            # direction_text = ['停止', '左转', '右转'][steering_direction]
            # logger.debug(f"液压电机消息 - 左摇杆X: {left_x:.3f}, 转向累积值: {self.control_states['steering_accumulator']}, "
            #             f"转向方向: {direction_text}, 转向电流: {steering_current}mA, "
            #             f"液压速度: {hydraulic_motor_speed}, 液压启用: {steering_direction != 0}")
            # 打印16进制数据
            print(data.hex())
            return CANMessage(message_id, bytes(data))

        except Exception as e:
            logger.error(f"创建液压电机消息失败: {e}")
            return None

    def create_walking_message(self, gamepad_data: Dict[str, Any]) -> Optional[CANMessage]:
        """创建行走电机控制消息 (ID: 0x18000003)"""
        # TODO 行走电机以及控制尚未测试
        message_id = 0x18000003
        data = bytearray([0] * 8)  # 8字节数据，初始化为0

        try:
            # 解析摇杆、方向键和按钮用于速度和档位控制
            axes = gamepad_data.get('axes', {})
            dpad = gamepad_data.get('dpad', {})
            buttons = gamepad_data.get('buttons', {})
            left_y = axes.get('left_y', 0.0)  # 左摇杆Y轴
            
            # 累积扭矩控制：结合左摇杆Y轴和方向键
            speed_increment = 3  # D-Pad每次增减3个单位
            max_speed = 120   # 最大累积值
            
                        
            # 手刹控制：right_trigger上升沿触发手刹toggle
            current_right_trigger = buttons.get('right_trigger', 0.0)
            if current_right_trigger > 0.1 and self.control_states.get('prev_right_trigger', 0.0) <= 0.1:
                # 检测到上升沿，切换手刹状态
                self.control_states['parking_brake_toggle'] = not self.control_states['parking_brake_toggle']
                logger.info(f"手刹状态切换: {'拉起' if self.control_states['parking_brake_toggle'] else '松开'}")
            self.control_states['prev_right_trigger'] = current_right_trigger


            # 确保累积器初始化（50对应零扭矩）
            if 'walking_torque_accumulator' not in self.control_states:
                self.control_states['walking_torque_accumulator'] = 50
            old_speed = self.control_states['walking_torque_accumulator']
            # 左摇杆Y轴速度控制（大于阈值时累积式控制）
            # 没有输入时，速度保持不变（累积值）
            joystick_threshold = 0.15  # 摇杆死区
            if abs(left_y) > joystick_threshold:
                # 根据摇杆偏移量调整速度累积值
                # 注意：向前推是负值（加速），向后拉是正值（减速）
                joystick_speed_increment = int(-left_y * 5)  # 摇杆影响强度
                self.control_states['walking_torque_accumulator'] = max(0,
                    min(self.control_states['walking_torque_accumulator'] + joystick_speed_increment, max_speed))
            else:
                self.control_states['walking_torque_accumulator'] = 50

            # 速度累积值变化时记录日志
            if old_speed != self.control_states['walking_torque_accumulator']:
                logger.debug(f"速度累积值变化: {old_speed} -> {self.control_states['walking_torque_accumulator']}")
            
            # 根据累积值计算实际扭矩 (-3000~3000)
            # 将累积值(0-100)映射到扭矩范围(-3000~3000)
            walking_torque = int((self.control_states['walking_torque_accumulator'] - 50) * 60)  # -3000~3000范围
            
            # 档位控制：X=P档(空档)，Y=D档(前进)，A=倒档
            direction = 0  # 默认空档
            if buttons.get('y', False):  # Y按钮 = D档(前进)
                direction = 1
            elif buttons.get('a', False):  # A按钮 = 倒档
                direction = 2
            elif buttons.get('x', False):  # X按钮 = P档(空档)
                direction = 0
                walking_torque = 0  # P档时速度为0，但不清空累积值
            
            if self.control_states['parking_brake_toggle']:
                direction = 0
                walking_torque = 0

            # 更新当前档位状态
            self.control_states['current_gear'] = direction

            # 行走电机使能信号 (bit 0)
            data[0] |= 1

            # 设置行走电机工作模式 (bit 1-2): 1=扭矩模式 2=转速模式
            # TODO 这里的驾驶模式也存疑？？
            data[0] |= (1 << 1)

            # 设置行走电机方向 (bit 3-4, 2bit)，也就是车辆党委
             # ！！尚未测试过！！
            data[0] |= (direction << 3)
            
            # 设置行走电机转速值 (bit 8-23, 16bit)
            # ！！尚未测试过！！
            walking_motor_speed = 17000
            b = walking_motor_speed.to_bytes(2, 'little') # 修复：使用小端序，与DBC定义@1+一致
            data[1] = b[0]  # bit 8-15 (低字节)
            data[2] = b[1]  # bit 16-23 (高字节)

            # 设置行走电机扭矩值 (bit 24-39, 16bit)
            # ！！尚未测试过！！
            walking_motor_torque = walking_torque
            b = walking_motor_torque.to_bytes(2, 'little') # 修复：使用小端序，与DBC定义@1+一致
            data[3] = b[0]  # bit 24-31 (低字节)
            data[4] = b[1]  # bit 32-39 (高字节)
            
            # 设置刹车制动阀的压力
            # 由于车辆没有驻车制动，因此通过该方式作为紧急驻车制动使用
            # ！！尚未测试过！！
            if self.control_states['parking_brake_toggle']:
                brake_current = 800
                b = brake_current.to_bytes(2, 'little') # 修复：使用小端序，与DBC定义@1+一致
                data[5] = b[0]  # bit 40-47 (低字节)
                data[6] = b[1]  # bit 48-55 (高字节)

            # 调试打印 - 行走电机消息
            # gear_text = ['空档(P)', '前进(D)', '后退(R)'][direction]
            # brake_current = 800 if self.control_states['parking_brake_toggle'] else 0
            # logger.debug(f"行走电机消息 - 左摇杆Y: {left_y:.3f}, 行走扭矩累积值: {self.control_states['walking_torque_accumulator']}, "
            #             f"当前档位: {gear_text}, 实际扭矩: {walking_torque}, 传输值: {walking_torque_transmission}, "
            #             f"手刹: {'拉起' if self.control_states['parking_brake_toggle'] else '松开'}, 刹车电流: {brake_current}mA")

            return CANMessage(message_id, bytes(data))

        except Exception as e:
            logger.error(f"创建行走电机消息失败: {e}")
            return None


    def create_actuator_valve_control_message(self, gamepad_data: Dict[str, Any]) -> Optional[CANMessage]:
        """创建机构电磁阀控制消息 (ID: 0x18000004)"""
        message_id = 0x18000004
        data = bytearray([0] * 8)  # 8字节数据，初始化为0

        try:
            # 解析右摇杆数据用于boom和bucket控制
            axes = gamepad_data.get('axes', {})
            right_x = axes.get('right_x', 0.0)  # 右摇杆X轴控制铲斗
            right_y = axes.get('right_y', 0.0)  # 右摇杆Y轴控制大臂
            
            # Bucket控制 (铲斗)：right_x > 0为bucket外翻，< 0为bucket内收
            bucket_tilt_current = 0
            bucket_retract_current = 0
            
            if right_x > 0.1:  # 死区0.1
                # Bucket外翻：铲斗外翻电磁阀
                bucket_tilt_current = int(abs(right_x) * 1000)  # 0~1500mA
                bucket_tilt_current = min(bucket_tilt_current, 1500)
            elif right_x < -0.1:  # 死区0.1
                # Bucket内收：铲斗内收电磁阀
                bucket_retract_current = int(abs(right_x) * 1000)  # 0~1500mA
                bucket_retract_current = min(bucket_retract_current, 1500)
            
            # Boom控制 (大臂)：right_y > 0为boom抬起，< 0为boom下降
            boom_lift_current = 0
            boom_lower_current = 0
            
            if right_y > 0.1:  # 死区0.1
                # Boom抬起：大臂抬电磁阀
                boom_lift_current = int(abs(right_y) * 1000)  # 0~1500mA
                boom_lift_current = min(boom_lift_current, 1500)
            elif right_y < -0.1:  # 死区0.1
                # Boom下降：大臂降电磁阀
                boom_lower_current = int(abs(right_y) * 1000)  # 0~1500mA
                boom_lower_current = min(boom_lower_current, 1500)
            
            # 更新电磁阀控制状态
            self.control_states['boom_lift_valve_current'] = boom_lift_current
            self.control_states['boom_lower_valve_current'] = boom_lower_current
            self.control_states['bucket_retract_valve_current'] = bucket_retract_current
            self.control_states['bucket_tilt_valve_current'] = bucket_tilt_current
            
            # 设置大臂抬电磁阀电流 (bit 0-15, 16bit) - 修复：使用小端序
            lift_bytes = boom_lift_current.to_bytes(2, 'little')
            data[0] = lift_bytes[0]  # bit 0-7 (低字节)
            data[1] = lift_bytes[1]  # bit 8-15 (高字节)
            
            # 设置大臂降电磁阀电流 (bit 16-31, 16bit) - 修复：使用小端序
            lower_bytes = boom_lower_current.to_bytes(2, 'little')
            data[2] = lower_bytes[0]  # bit 16-23 (低字节)
            data[3] = lower_bytes[1]  # bit 24-31 (高字节)
            
            # 设置铲斗内收电磁阀电流 (bit 32-47, 16bit) - 修复：使用小端序
            retract_bytes = bucket_retract_current.to_bytes(2, 'little')
            data[4] = retract_bytes[0]  # bit 32-39 (低字节)
            data[5] = retract_bytes[1]  # bit 40-47 (高字节)
            
            # 设置铲斗外翻电磁阀电流 (bit 48-63, 16bit) - 修复：使用小端序
            tilt_bytes = bucket_tilt_current.to_bytes(2, 'little')
            data[6] = tilt_bytes[0]  # bit 48-55 (低字节)
            data[7] = tilt_bytes[1]  # bit 56-63 (高字节)

            # 调试打印 - 电磁阀控制消息
            logger.info(f"电磁阀控制消息 - 右摇杆X(铲斗): {right_x:.3f}, 右摇杆Y(大臂): {right_y:.3f}, "
                        f"大臂抬: {boom_lift_current}mA, 大臂降: {boom_lower_current}mA, "
                        f"铲斗收: {bucket_retract_current}mA, 铲斗翻: {bucket_tilt_current}mA")

            return CANMessage(message_id, bytes(data))

        except Exception as e:
            logger.error(f"创建机构电磁阀控制消息失败: {e}")
            return None
