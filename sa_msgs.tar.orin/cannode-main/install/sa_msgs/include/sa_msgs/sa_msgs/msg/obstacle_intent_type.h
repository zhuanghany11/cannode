// generated from rosidl_generator_c/resource/idl.h.em
// with input from sa_msgs:msg/ObstacleIntentType.idl
// generated code does not contain a copyright notice

#ifndef SA_MSGS__MSG__OBSTACLE_INTENT_TYPE_H_
#define SA_MSGS__MSG__OBSTACLE_INTENT_TYPE_H_

#include "sa_msgs/msg/detail/obstacle_intent_type__struct.h"
#include "sa_msgs/msg/detail/obstacle_intent_type__functions.h"
#include "sa_msgs/msg/detail/obstacle_intent_type__type_support.h"

#endif  // SA_MSGS__MSG__OBSTACLE_INTENT_TYPE_H_
