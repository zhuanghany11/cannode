// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef SA_MSGS__MSG__POSITION_OR_VELOCITY_TYPE_HPP_
#define SA_MSGS__MSG__POSITION_OR_VELOCITY_TYPE_HPP_

#include "sa_msgs/msg/detail/position_or_velocity_type__struct.hpp"
#include "sa_msgs/msg/detail/position_or_velocity_type__builder.hpp"
#include "sa_msgs/msg/detail/position_or_velocity_type__traits.hpp"
#include "sa_msgs/msg/detail/position_or_velocity_type__type_support.hpp"

#endif  // SA_MSGS__MSG__POSITION_OR_VELOCITY_TYPE_HPP_
