// generated from rosidl_generator_c/resource/idl.h.em
// with input from sa_msgs:msg/SaLidarCraneLocCmdStatus.idl
// generated code does not contain a copyright notice

#ifndef SA_MSGS__MSG__SA_LIDAR_CRANE_LOC_CMD_STATUS_H_
#define SA_MSGS__MSG__SA_LIDAR_CRANE_LOC_CMD_STATUS_H_

#include "sa_msgs/msg/detail/sa_lidar_crane_loc_cmd_status__struct.h"
#include "sa_msgs/msg/detail/sa_lidar_crane_loc_cmd_status__functions.h"
#include "sa_msgs/msg/detail/sa_lidar_crane_loc_cmd_status__type_support.h"

#endif  // SA_MSGS__MSG__SA_LIDAR_CRANE_LOC_CMD_STATUS_H_
