// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from sa_msgs:msg/SaPlanningStopVehicleMsgData.idl
// generated code does not contain a copyright notice

#ifndef SA_MSGS__MSG__DETAIL__SA_PLANNING_STOP_VEHICLE_MSG_DATA__BUILDER_HPP_
#define SA_MSGS__MSG__DETAIL__SA_PLANNING_STOP_VEHICLE_MSG_DATA__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "sa_msgs/msg/detail/sa_planning_stop_vehicle_msg_data__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace sa_msgs
{

namespace msg
{

namespace builder
{

class Init_SaPlanningStopVehicleMsgData_timestamp
{
public:
  explicit Init_SaPlanningStopVehicleMsgData_timestamp(::sa_msgs::msg::SaPlanningStopVehicleMsgData & msg)
  : msg_(msg)
  {}
  ::sa_msgs::msg::SaPlanningStopVehicleMsgData timestamp(::sa_msgs::msg::SaPlanningStopVehicleMsgData::_timestamp_type arg)
  {
    msg_.timestamp = std::move(arg);
    return std::move(msg_);
  }

private:
  ::sa_msgs::msg::SaPlanningStopVehicleMsgData msg_;
};

class Init_SaPlanningStopVehicleMsgData_task_id
{
public:
  Init_SaPlanningStopVehicleMsgData_task_id()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_SaPlanningStopVehicleMsgData_timestamp task_id(::sa_msgs::msg::SaPlanningStopVehicleMsgData::_task_id_type arg)
  {
    msg_.task_id = std::move(arg);
    return Init_SaPlanningStopVehicleMsgData_timestamp(msg_);
  }

private:
  ::sa_msgs::msg::SaPlanningStopVehicleMsgData msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::sa_msgs::msg::SaPlanningStopVehicleMsgData>()
{
  return sa_msgs::msg::builder::Init_SaPlanningStopVehicleMsgData_task_id();
}

}  // namespace sa_msgs

#endif  // SA_MSGS__MSG__DETAIL__SA_PLANNING_STOP_VEHICLE_MSG_DATA__BUILDER_HPP_
