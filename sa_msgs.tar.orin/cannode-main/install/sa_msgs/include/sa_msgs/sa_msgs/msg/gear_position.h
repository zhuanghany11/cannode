// generated from rosidl_generator_c/resource/idl.h.em
// with input from sa_msgs:msg/GearPosition.idl
// generated code does not contain a copyright notice

#ifndef SA_MSGS__MSG__GEAR_POSITION_H_
#define SA_MSGS__MSG__GEAR_POSITION_H_

#include "sa_msgs/msg/detail/gear_position__struct.h"
#include "sa_msgs/msg/detail/gear_position__functions.h"
#include "sa_msgs/msg/detail/gear_position__type_support.h"

#endif  // SA_MSGS__MSG__GEAR_POSITION_H_
