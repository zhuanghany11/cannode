// generated from rosidl_generator_c/resource/idl.h.em
// with input from sa_msgs:msg/SaLocGnssInfo.idl
// generated code does not contain a copyright notice

#ifndef SA_MSGS__MSG__SA_LOC_GNSS_INFO_H_
#define SA_MSGS__MSG__SA_LOC_GNSS_INFO_H_

#include "sa_msgs/msg/detail/sa_loc_gnss_info__struct.h"
#include "sa_msgs/msg/detail/sa_loc_gnss_info__functions.h"
#include "sa_msgs/msg/detail/sa_loc_gnss_info__type_support.h"

#endif  // SA_MSGS__MSG__SA_LOC_GNSS_INFO_H_
