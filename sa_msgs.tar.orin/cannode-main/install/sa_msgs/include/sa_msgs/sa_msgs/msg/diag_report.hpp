// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef SA_MSGS__MSG__DIAG_REPORT_HPP_
#define SA_MSGS__MSG__DIAG_REPORT_HPP_

#include "sa_msgs/msg/detail/diag_report__struct.hpp"
#include "sa_msgs/msg/detail/diag_report__builder.hpp"
#include "sa_msgs/msg/detail/diag_report__traits.hpp"
#include "sa_msgs/msg/detail/diag_report__type_support.hpp"

#endif  // SA_MSGS__MSG__DIAG_REPORT_HPP_
