// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef SA_MSGS__MSG__SA_PLANNING_LOCAL_PATH_REPORT_DATA_HPP_
#define SA_MSGS__MSG__SA_PLANNING_LOCAL_PATH_REPORT_DATA_HPP_

#include "sa_msgs/msg/detail/sa_planning_local_path_report_data__struct.hpp"
#include "sa_msgs/msg/detail/sa_planning_local_path_report_data__builder.hpp"
#include "sa_msgs/msg/detail/sa_planning_local_path_report_data__traits.hpp"
#include "sa_msgs/msg/detail/sa_planning_local_path_report_data__type_support.hpp"

#endif  // SA_MSGS__MSG__SA_PLANNING_LOCAL_PATH_REPORT_DATA_HPP_
