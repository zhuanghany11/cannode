// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from sa_msgs:msg/SaContainerState.idl
// generated code does not contain a copyright notice

#ifndef SA_MSGS__MSG__DETAIL__SA_CONTAINER_STATE__BUILDER_HPP_
#define SA_MSGS__MSG__DETAIL__SA_CONTAINER_STATE__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "sa_msgs/msg/detail/sa_container_state__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace sa_msgs
{

namespace msg
{

namespace builder
{

class Init_SaContainerState_container_on_igv
{
public:
  explicit Init_SaContainerState_container_on_igv(::sa_msgs::msg::SaContainerState & msg)
  : msg_(msg)
  {}
  ::sa_msgs::msg::SaContainerState container_on_igv(::sa_msgs::msg::SaContainerState::_container_on_igv_type arg)
  {
    msg_.container_on_igv = std::move(arg);
    return std::move(msg_);
  }

private:
  ::sa_msgs::msg::SaContainerState msg_;
};

class Init_SaContainerState_header
{
public:
  Init_SaContainerState_header()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_SaContainerState_container_on_igv header(::sa_msgs::msg::SaContainerState::_header_type arg)
  {
    msg_.header = std::move(arg);
    return Init_SaContainerState_container_on_igv(msg_);
  }

private:
  ::sa_msgs::msg::SaContainerState msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::sa_msgs::msg::SaContainerState>()
{
  return sa_msgs::msg::builder::Init_SaContainerState_header();
}

}  // namespace sa_msgs

#endif  // SA_MSGS__MSG__DETAIL__SA_CONTAINER_STATE__BUILDER_HPP_
