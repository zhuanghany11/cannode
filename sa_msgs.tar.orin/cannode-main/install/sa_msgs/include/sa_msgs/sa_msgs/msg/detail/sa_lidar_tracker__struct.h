﻿// NOLINT: This file starts with a BOM since it contain non-ASCII characters
// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from sa_msgs:msg/SaLidarTracker.idl
// generated code does not contain a copyright notice

#ifndef SA_MSGS__MSG__DETAIL__SA_LIDAR_TRACKER__STRUCT_H_
#define SA_MSGS__MSG__DETAIL__SA_LIDAR_TRACKER__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__struct.h"
// Member 'grid_id'
// Member 'grid_map'
#include "rosidl_runtime_c/primitives_sequence.h"
// Member 'dynamic_obstacles'
#include "sa_msgs/msg/detail/sa_dynamic_obstacle__struct.h"

/// Struct defined in msg/SaLidarTracker in the package sa_msgs.
typedef struct sa_msgs__msg__SaLidarTracker
{
  /// 与lidar_det时间戳保持一致
  std_msgs__msg__Header header;
  /// 栅格图尺寸 750*500
  uint32_t height;
  uint32_t width;
  /// 障碍物idx栅格图，1*map_length*map_width
  /// 索引含义与SaLidarDet.msg中grid_map一致
  /// 默认值cv::Mat::zeros(map_length=750, map_width=500, CV_32SC1)
  /// 具体值标识障碍物信息，
  /// 0标识无障碍物，
  /// -1标识未被跟踪到的通用障碍物，
  /// 其它值标识dynamic_obstacles对应列表序号
  rosidl_runtime_c__int32__Sequence grid_id;
  /// 输出栅格图 4*map_length*map_width，含义与SaLidarDet.msg一致
  rosidl_runtime_c__uint8__Sequence grid_map;
  /// 跟踪目标检测列表
  sa_msgs__msg__SaDynamicObstacle__Sequence dynamic_obstacles;
} sa_msgs__msg__SaLidarTracker;

// Struct for a sequence of sa_msgs__msg__SaLidarTracker.
typedef struct sa_msgs__msg__SaLidarTracker__Sequence
{
  sa_msgs__msg__SaLidarTracker * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} sa_msgs__msg__SaLidarTracker__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // SA_MSGS__MSG__DETAIL__SA_LIDAR_TRACKER__STRUCT_H_
