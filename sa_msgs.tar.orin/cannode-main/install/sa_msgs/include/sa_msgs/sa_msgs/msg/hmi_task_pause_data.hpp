// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef SA_MSGS__MSG__HMI_TASK_PAUSE_DATA_HPP_
#define SA_MSGS__MSG__HMI_TASK_PAUSE_DATA_HPP_

#include "sa_msgs/msg/detail/hmi_task_pause_data__struct.hpp"
#include "sa_msgs/msg/detail/hmi_task_pause_data__builder.hpp"
#include "sa_msgs/msg/detail/hmi_task_pause_data__traits.hpp"
#include "sa_msgs/msg/detail/hmi_task_pause_data__type_support.hpp"

#endif  // SA_MSGS__MSG__HMI_TASK_PAUSE_DATA_HPP_
