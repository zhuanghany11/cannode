﻿// NOLINT: This file starts with a BOM since it contain non-ASCII characters
// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from sa_msgs:msg/SaLidarCraneLocCmdStatus.idl
// generated code does not contain a copyright notice

#ifndef SA_MSGS__MSG__DETAIL__SA_LIDAR_CRANE_LOC_CMD_STATUS__STRUCT_H_
#define SA_MSGS__MSG__DETAIL__SA_LIDAR_CRANE_LOC_CMD_STATUS__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

/// Constant 'ACTIVATE'.
enum
{
  sa_msgs__msg__SaLidarCraneLocCmdStatus__ACTIVATE = 0
};

/// Constant 'STOP'.
enum
{
  sa_msgs__msg__SaLidarCraneLocCmdStatus__STOP = 1
};

/// Struct defined in msg/SaLidarCraneLocCmdStatus in the package sa_msgs.
/**
  * SaLidarCraneLocCmdStatus.msg
  *  对位程序命令，开启和关闭两种
 */
typedef struct sa_msgs__msg__SaLidarCraneLocCmdStatus
{
  int8_t value;
} sa_msgs__msg__SaLidarCraneLocCmdStatus;

// Struct for a sequence of sa_msgs__msg__SaLidarCraneLocCmdStatus.
typedef struct sa_msgs__msg__SaLidarCraneLocCmdStatus__Sequence
{
  sa_msgs__msg__SaLidarCraneLocCmdStatus * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} sa_msgs__msg__SaLidarCraneLocCmdStatus__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // SA_MSGS__MSG__DETAIL__SA_LIDAR_CRANE_LOC_CMD_STATUS__STRUCT_H_
