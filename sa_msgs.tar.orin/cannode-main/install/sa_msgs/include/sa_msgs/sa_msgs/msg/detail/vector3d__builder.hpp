// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from sa_msgs:msg/Vector3d.idl
// generated code does not contain a copyright notice

#ifndef SA_MSGS__MSG__DETAIL__VECTOR3D__BUILDER_HPP_
#define SA_MSGS__MSG__DETAIL__VECTOR3D__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "sa_msgs/msg/detail/vector3d__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace sa_msgs
{

namespace msg
{

namespace builder
{

class Init_Vector3d_z
{
public:
  explicit Init_Vector3d_z(::sa_msgs::msg::Vector3d & msg)
  : msg_(msg)
  {}
  ::sa_msgs::msg::Vector3d z(::sa_msgs::msg::Vector3d::_z_type arg)
  {
    msg_.z = std::move(arg);
    return std::move(msg_);
  }

private:
  ::sa_msgs::msg::Vector3d msg_;
};

class Init_Vector3d_y
{
public:
  explicit Init_Vector3d_y(::sa_msgs::msg::Vector3d & msg)
  : msg_(msg)
  {}
  Init_Vector3d_z y(::sa_msgs::msg::Vector3d::_y_type arg)
  {
    msg_.y = std::move(arg);
    return Init_Vector3d_z(msg_);
  }

private:
  ::sa_msgs::msg::Vector3d msg_;
};

class Init_Vector3d_x
{
public:
  Init_Vector3d_x()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_Vector3d_y x(::sa_msgs::msg::Vector3d::_x_type arg)
  {
    msg_.x = std::move(arg);
    return Init_Vector3d_y(msg_);
  }

private:
  ::sa_msgs::msg::Vector3d msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::sa_msgs::msg::Vector3d>()
{
  return sa_msgs::msg::builder::Init_Vector3d_x();
}

}  // namespace sa_msgs

#endif  // SA_MSGS__MSG__DETAIL__VECTOR3D__BUILDER_HPP_
