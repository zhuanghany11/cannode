// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef SA_MSGS__MSG__HAF_DISPLAY_OBSTACLE_HPP_
#define SA_MSGS__MSG__HAF_DISPLAY_OBSTACLE_HPP_

#include "sa_msgs/msg/detail/haf_display_obstacle__struct.hpp"
#include "sa_msgs/msg/detail/haf_display_obstacle__builder.hpp"
#include "sa_msgs/msg/detail/haf_display_obstacle__traits.hpp"
#include "sa_msgs/msg/detail/haf_display_obstacle__type_support.hpp"

#endif  // SA_MSGS__MSG__HAF_DISPLAY_OBSTACLE_HPP_
