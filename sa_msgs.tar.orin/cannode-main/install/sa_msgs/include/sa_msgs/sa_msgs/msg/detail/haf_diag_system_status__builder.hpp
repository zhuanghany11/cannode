// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from sa_msgs:msg/HafDiagSystemStatus.idl
// generated code does not contain a copyright notice

#ifndef SA_MSGS__MSG__DETAIL__HAF_DIAG_SYSTEM_STATUS__BUILDER_HPP_
#define SA_MSGS__MSG__DETAIL__HAF_DIAG_SYSTEM_STATUS__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "sa_msgs/msg/detail/haf_diag_system_status__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace sa_msgs
{

namespace msg
{

namespace builder
{

class Init_HafDiagSystemStatus_emmc_disk_free_space
{
public:
  explicit Init_HafDiagSystemStatus_emmc_disk_free_space(::sa_msgs::msg::HafDiagSystemStatus & msg)
  : msg_(msg)
  {}
  ::sa_msgs::msg::HafDiagSystemStatus emmc_disk_free_space(::sa_msgs::msg::HafDiagSystemStatus::_emmc_disk_free_space_type arg)
  {
    msg_.emmc_disk_free_space = std::move(arg);
    return std::move(msg_);
  }

private:
  ::sa_msgs::msg::HafDiagSystemStatus msg_;
};

class Init_HafDiagSystemStatus_disk_free_space
{
public:
  explicit Init_HafDiagSystemStatus_disk_free_space(::sa_msgs::msg::HafDiagSystemStatus & msg)
  : msg_(msg)
  {}
  Init_HafDiagSystemStatus_emmc_disk_free_space disk_free_space(::sa_msgs::msg::HafDiagSystemStatus::_disk_free_space_type arg)
  {
    msg_.disk_free_space = std::move(arg);
    return Init_HafDiagSystemStatus_emmc_disk_free_space(msg_);
  }

private:
  ::sa_msgs::msg::HafDiagSystemStatus msg_;
};

class Init_HafDiagSystemStatus_nodes
{
public:
  explicit Init_HafDiagSystemStatus_nodes(::sa_msgs::msg::HafDiagSystemStatus & msg)
  : msg_(msg)
  {}
  Init_HafDiagSystemStatus_disk_free_space nodes(::sa_msgs::msg::HafDiagSystemStatus::_nodes_type arg)
  {
    msg_.nodes = std::move(arg);
    return Init_HafDiagSystemStatus_disk_free_space(msg_);
  }

private:
  ::sa_msgs::msg::HafDiagSystemStatus msg_;
};

class Init_HafDiagSystemStatus_bm_offline_reason
{
public:
  explicit Init_HafDiagSystemStatus_bm_offline_reason(::sa_msgs::msg::HafDiagSystemStatus & msg)
  : msg_(msg)
  {}
  Init_HafDiagSystemStatus_nodes bm_offline_reason(::sa_msgs::msg::HafDiagSystemStatus::_bm_offline_reason_type arg)
  {
    msg_.bm_offline_reason = std::move(arg);
    return Init_HafDiagSystemStatus_nodes(msg_);
  }

private:
  ::sa_msgs::msg::HafDiagSystemStatus msg_;
};

class Init_HafDiagSystemStatus_bm_fault_reason
{
public:
  explicit Init_HafDiagSystemStatus_bm_fault_reason(::sa_msgs::msg::HafDiagSystemStatus & msg)
  : msg_(msg)
  {}
  Init_HafDiagSystemStatus_bm_offline_reason bm_fault_reason(::sa_msgs::msg::HafDiagSystemStatus::_bm_fault_reason_type arg)
  {
    msg_.bm_fault_reason = std::move(arg);
    return Init_HafDiagSystemStatus_bm_offline_reason(msg_);
  }

private:
  ::sa_msgs::msg::HafDiagSystemStatus msg_;
};

class Init_HafDiagSystemStatus_bm_switch
{
public:
  explicit Init_HafDiagSystemStatus_bm_switch(::sa_msgs::msg::HafDiagSystemStatus & msg)
  : msg_(msg)
  {}
  Init_HafDiagSystemStatus_bm_fault_reason bm_switch(::sa_msgs::msg::HafDiagSystemStatus::_bm_switch_type arg)
  {
    msg_.bm_switch = std::move(arg);
    return Init_HafDiagSystemStatus_bm_fault_reason(msg_);
  }

private:
  ::sa_msgs::msg::HafDiagSystemStatus msg_;
};

class Init_HafDiagSystemStatus_bm_online
{
public:
  explicit Init_HafDiagSystemStatus_bm_online(::sa_msgs::msg::HafDiagSystemStatus & msg)
  : msg_(msg)
  {}
  Init_HafDiagSystemStatus_bm_switch bm_online(::sa_msgs::msg::HafDiagSystemStatus::_bm_online_type arg)
  {
    msg_.bm_online = std::move(arg);
    return Init_HafDiagSystemStatus_bm_switch(msg_);
  }

private:
  ::sa_msgs::msg::HafDiagSystemStatus msg_;
};

class Init_HafDiagSystemStatus_bm_warn
{
public:
  explicit Init_HafDiagSystemStatus_bm_warn(::sa_msgs::msg::HafDiagSystemStatus & msg)
  : msg_(msg)
  {}
  Init_HafDiagSystemStatus_bm_online bm_warn(::sa_msgs::msg::HafDiagSystemStatus::_bm_warn_type arg)
  {
    msg_.bm_warn = std::move(arg);
    return Init_HafDiagSystemStatus_bm_online(msg_);
  }

private:
  ::sa_msgs::msg::HafDiagSystemStatus msg_;
};

class Init_HafDiagSystemStatus_bm_fault
{
public:
  explicit Init_HafDiagSystemStatus_bm_fault(::sa_msgs::msg::HafDiagSystemStatus & msg)
  : msg_(msg)
  {}
  Init_HafDiagSystemStatus_bm_warn bm_fault(::sa_msgs::msg::HafDiagSystemStatus::_bm_fault_type arg)
  {
    msg_.bm_fault = std::move(arg);
    return Init_HafDiagSystemStatus_bm_warn(msg_);
  }

private:
  ::sa_msgs::msg::HafDiagSystemStatus msg_;
};

class Init_HafDiagSystemStatus_auto_drive_mode
{
public:
  explicit Init_HafDiagSystemStatus_auto_drive_mode(::sa_msgs::msg::HafDiagSystemStatus & msg)
  : msg_(msg)
  {}
  Init_HafDiagSystemStatus_bm_fault auto_drive_mode(::sa_msgs::msg::HafDiagSystemStatus::_auto_drive_mode_type arg)
  {
    msg_.auto_drive_mode = std::move(arg);
    return Init_HafDiagSystemStatus_bm_fault(msg_);
  }

private:
  ::sa_msgs::msg::HafDiagSystemStatus msg_;
};

class Init_HafDiagSystemStatus_status
{
public:
  explicit Init_HafDiagSystemStatus_status(::sa_msgs::msg::HafDiagSystemStatus & msg)
  : msg_(msg)
  {}
  Init_HafDiagSystemStatus_auto_drive_mode status(::sa_msgs::msg::HafDiagSystemStatus::_status_type arg)
  {
    msg_.status = std::move(arg);
    return Init_HafDiagSystemStatus_auto_drive_mode(msg_);
  }

private:
  ::sa_msgs::msg::HafDiagSystemStatus msg_;
};

class Init_HafDiagSystemStatus_header
{
public:
  Init_HafDiagSystemStatus_header()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_HafDiagSystemStatus_status header(::sa_msgs::msg::HafDiagSystemStatus::_header_type arg)
  {
    msg_.header = std::move(arg);
    return Init_HafDiagSystemStatus_status(msg_);
  }

private:
  ::sa_msgs::msg::HafDiagSystemStatus msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::sa_msgs::msg::HafDiagSystemStatus>()
{
  return sa_msgs::msg::builder::Init_HafDiagSystemStatus_header();
}

}  // namespace sa_msgs

#endif  // SA_MSGS__MSG__DETAIL__HAF_DIAG_SYSTEM_STATUS__BUILDER_HPP_
