// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from sa_msgs:msg/Translation.idl
// generated code does not contain a copyright notice

#ifndef SA_MSGS__MSG__DETAIL__TRANSLATION__STRUCT_H_
#define SA_MSGS__MSG__DETAIL__TRANSLATION__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'translation'
#include "sa_msgs/msg/detail/translation_offset__struct.h"
// Member 'frame'
#include "sa_msgs/msg/detail/ins_frame__struct.h"
// Member 'translation_source'
#include "sa_msgs/msg/detail/ins_source_status__struct.h"

/// Struct defined in msg/Translation in the package sa_msgs.
typedef struct sa_msgs__msg__Translation
{
  sa_msgs__msg__TranslationOffset translation;
  sa_msgs__msg__INSFrame frame;
  float x_offset;
  float y_offset;
  float z_offset;
  float x_uncertainty;
  float y_uncertainty;
  float z_uncertainty;
  sa_msgs__msg__INSSourceStatus translation_source;
} sa_msgs__msg__Translation;

// Struct for a sequence of sa_msgs__msg__Translation.
typedef struct sa_msgs__msg__Translation__Sequence
{
  sa_msgs__msg__Translation * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} sa_msgs__msg__Translation__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // SA_MSGS__MSG__DETAIL__TRANSLATION__STRUCT_H_
