// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from sa_msgs:msg/PullOverReq.idl
// generated code does not contain a copyright notice

#ifndef SA_MSGS__MSG__DETAIL__PULL_OVER_REQ__STRUCT_HPP_
#define SA_MSGS__MSG__DETAIL__PULL_OVER_REQ__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__struct.hpp"

#ifndef _WIN32
# define DEPRECATED__sa_msgs__msg__PullOverReq __attribute__((deprecated))
#else
# define DEPRECATED__sa_msgs__msg__PullOverReq __declspec(deprecated)
#endif

namespace sa_msgs
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct PullOverReq_
{
  using Type = PullOverReq_<ContainerAllocator>;

  explicit PullOverReq_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : header(_init)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->seq = 0ul;
      this->stop_point_id = "";
      this->lon = 0.0;
      this->lat = 0.0;
      this->alt = 0.0;
      this->heading = 0.0;
    }
  }

  explicit PullOverReq_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : header(_alloc, _init),
    stop_point_id(_alloc)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->seq = 0ul;
      this->stop_point_id = "";
      this->lon = 0.0;
      this->lat = 0.0;
      this->alt = 0.0;
      this->heading = 0.0;
    }
  }

  // field types and members
  using _header_type =
    std_msgs::msg::Header_<ContainerAllocator>;
  _header_type header;
  using _seq_type =
    uint32_t;
  _seq_type seq;
  using _stop_point_id_type =
    std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>;
  _stop_point_id_type stop_point_id;
  using _lon_type =
    double;
  _lon_type lon;
  using _lat_type =
    double;
  _lat_type lat;
  using _alt_type =
    double;
  _alt_type alt;
  using _heading_type =
    double;
  _heading_type heading;
  using _pb_type =
    std::vector<unsigned char, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<unsigned char>>;
  _pb_type pb;

  // setters for named parameter idiom
  Type & set__header(
    const std_msgs::msg::Header_<ContainerAllocator> & _arg)
  {
    this->header = _arg;
    return *this;
  }
  Type & set__seq(
    const uint32_t & _arg)
  {
    this->seq = _arg;
    return *this;
  }
  Type & set__stop_point_id(
    const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> & _arg)
  {
    this->stop_point_id = _arg;
    return *this;
  }
  Type & set__lon(
    const double & _arg)
  {
    this->lon = _arg;
    return *this;
  }
  Type & set__lat(
    const double & _arg)
  {
    this->lat = _arg;
    return *this;
  }
  Type & set__alt(
    const double & _arg)
  {
    this->alt = _arg;
    return *this;
  }
  Type & set__heading(
    const double & _arg)
  {
    this->heading = _arg;
    return *this;
  }
  Type & set__pb(
    const std::vector<unsigned char, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<unsigned char>> & _arg)
  {
    this->pb = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    sa_msgs::msg::PullOverReq_<ContainerAllocator> *;
  using ConstRawPtr =
    const sa_msgs::msg::PullOverReq_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<sa_msgs::msg::PullOverReq_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<sa_msgs::msg::PullOverReq_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      sa_msgs::msg::PullOverReq_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<sa_msgs::msg::PullOverReq_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      sa_msgs::msg::PullOverReq_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<sa_msgs::msg::PullOverReq_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<sa_msgs::msg::PullOverReq_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<sa_msgs::msg::PullOverReq_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__sa_msgs__msg__PullOverReq
    std::shared_ptr<sa_msgs::msg::PullOverReq_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__sa_msgs__msg__PullOverReq
    std::shared_ptr<sa_msgs::msg::PullOverReq_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const PullOverReq_ & other) const
  {
    if (this->header != other.header) {
      return false;
    }
    if (this->seq != other.seq) {
      return false;
    }
    if (this->stop_point_id != other.stop_point_id) {
      return false;
    }
    if (this->lon != other.lon) {
      return false;
    }
    if (this->lat != other.lat) {
      return false;
    }
    if (this->alt != other.alt) {
      return false;
    }
    if (this->heading != other.heading) {
      return false;
    }
    if (this->pb != other.pb) {
      return false;
    }
    return true;
  }
  bool operator!=(const PullOverReq_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct PullOverReq_

// alias to use template instance with default allocator
using PullOverReq =
  sa_msgs::msg::PullOverReq_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace sa_msgs

#endif  // SA_MSGS__MSG__DETAIL__PULL_OVER_REQ__STRUCT_HPP_
