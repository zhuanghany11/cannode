// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from sa_msgs:msg/LightStatus.idl
// generated code does not contain a copyright notice

#ifndef SA_MSGS__MSG__DETAIL__LIGHT_STATUS__TRAITS_HPP_
#define SA_MSGS__MSG__DETAIL__LIGHT_STATUS__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "sa_msgs/msg/detail/light_status__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

namespace sa_msgs
{

namespace msg
{

inline void to_flow_style_yaml(
  const LightStatus & msg,
  std::ostream & out)
{
  out << "{";
  // member: brake_visible
  {
    out << "brake_visible: ";
    rosidl_generator_traits::value_to_yaml(msg.brake_visible, out);
    out << ", ";
  }

  // member: brake_switch_on
  {
    out << "brake_switch_on: ";
    rosidl_generator_traits::value_to_yaml(msg.brake_switch_on, out);
    out << ", ";
  }

  // member: left_turn_visible
  {
    out << "left_turn_visible: ";
    rosidl_generator_traits::value_to_yaml(msg.left_turn_visible, out);
    out << ", ";
  }

  // member: left_turn_switch_on
  {
    out << "left_turn_switch_on: ";
    rosidl_generator_traits::value_to_yaml(msg.left_turn_switch_on, out);
    out << ", ";
  }

  // member: right_turn_visible
  {
    out << "right_turn_visible: ";
    rosidl_generator_traits::value_to_yaml(msg.right_turn_visible, out);
    out << ", ";
  }

  // member: right_turn_switch_on
  {
    out << "right_turn_switch_on: ";
    rosidl_generator_traits::value_to_yaml(msg.right_turn_switch_on, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const LightStatus & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: brake_visible
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "brake_visible: ";
    rosidl_generator_traits::value_to_yaml(msg.brake_visible, out);
    out << "\n";
  }

  // member: brake_switch_on
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "brake_switch_on: ";
    rosidl_generator_traits::value_to_yaml(msg.brake_switch_on, out);
    out << "\n";
  }

  // member: left_turn_visible
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "left_turn_visible: ";
    rosidl_generator_traits::value_to_yaml(msg.left_turn_visible, out);
    out << "\n";
  }

  // member: left_turn_switch_on
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "left_turn_switch_on: ";
    rosidl_generator_traits::value_to_yaml(msg.left_turn_switch_on, out);
    out << "\n";
  }

  // member: right_turn_visible
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "right_turn_visible: ";
    rosidl_generator_traits::value_to_yaml(msg.right_turn_visible, out);
    out << "\n";
  }

  // member: right_turn_switch_on
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "right_turn_switch_on: ";
    rosidl_generator_traits::value_to_yaml(msg.right_turn_switch_on, out);
    out << "\n";
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const LightStatus & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace msg

}  // namespace sa_msgs

namespace rosidl_generator_traits
{

[[deprecated("use sa_msgs::msg::to_block_style_yaml() instead")]]
inline void to_yaml(
  const sa_msgs::msg::LightStatus & msg,
  std::ostream & out, size_t indentation = 0)
{
  sa_msgs::msg::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use sa_msgs::msg::to_yaml() instead")]]
inline std::string to_yaml(const sa_msgs::msg::LightStatus & msg)
{
  return sa_msgs::msg::to_yaml(msg);
}

template<>
inline const char * data_type<sa_msgs::msg::LightStatus>()
{
  return "sa_msgs::msg::LightStatus";
}

template<>
inline const char * name<sa_msgs::msg::LightStatus>()
{
  return "sa_msgs/msg/LightStatus";
}

template<>
struct has_fixed_size<sa_msgs::msg::LightStatus>
  : std::integral_constant<bool, true> {};

template<>
struct has_bounded_size<sa_msgs::msg::LightStatus>
  : std::integral_constant<bool, true> {};

template<>
struct is_message<sa_msgs::msg::LightStatus>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // SA_MSGS__MSG__DETAIL__LIGHT_STATUS__TRAITS_HPP_
