// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef SA_MSGS__MSG__SA_EGO_TRAJECTORY_HPP_
#define SA_MSGS__MSG__SA_EGO_TRAJECTORY_HPP_

#include "sa_msgs/msg/detail/sa_ego_trajectory__struct.hpp"
#include "sa_msgs/msg/detail/sa_ego_trajectory__builder.hpp"
#include "sa_msgs/msg/detail/sa_ego_trajectory__traits.hpp"
#include "sa_msgs/msg/detail/sa_ego_trajectory__type_support.hpp"

#endif  // SA_MSGS__MSG__SA_EGO_TRAJECTORY_HPP_
