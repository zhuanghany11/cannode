// generated from rosidl_generator_c/resource/idl.h.em
// with input from sa_msgs:msg/Vector3f.idl
// generated code does not contain a copyright notice

#ifndef SA_MSGS__MSG__VECTOR3F_H_
#define SA_MSGS__MSG__VECTOR3F_H_

#include "sa_msgs/msg/detail/vector3f__struct.h"
#include "sa_msgs/msg/detail/vector3f__functions.h"
#include "sa_msgs/msg/detail/vector3f__type_support.h"

#endif  // SA_MSGS__MSG__VECTOR3F_H_
