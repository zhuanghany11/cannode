// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from sa_msgs:msg/SanetLaneAttribute.idl
// generated code does not contain a copyright notice

#ifndef SA_MSGS__MSG__DETAIL__SANET_LANE_ATTRIBUTE__STRUCT_HPP_
#define SA_MSGS__MSG__DETAIL__SANET_LANE_ATTRIBUTE__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


#ifndef _WIN32
# define DEPRECATED__sa_msgs__msg__SanetLaneAttribute __attribute__((deprecated))
#else
# define DEPRECATED__sa_msgs__msg__SanetLaneAttribute __declspec(deprecated)
#endif

namespace sa_msgs
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct SanetLaneAttribute_
{
  using Type = SanetLaneAttribute_<ContainerAllocator>;

  explicit SanetLaneAttribute_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->lane_type = 0;
      this->lane_color = 0;
      this->road_type = 0;
      this->feature_type = 0;
      this->intersection = 0;
    }
  }

  explicit SanetLaneAttribute_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    (void)_alloc;
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->lane_type = 0;
      this->lane_color = 0;
      this->road_type = 0;
      this->feature_type = 0;
      this->intersection = 0;
    }
  }

  // field types and members
  using _lane_type_type =
    uint8_t;
  _lane_type_type lane_type;
  using _lane_color_type =
    uint8_t;
  _lane_color_type lane_color;
  using _road_type_type =
    uint8_t;
  _road_type_type road_type;
  using _feature_type_type =
    uint8_t;
  _feature_type_type feature_type;
  using _intersection_type =
    uint8_t;
  _intersection_type intersection;

  // setters for named parameter idiom
  Type & set__lane_type(
    const uint8_t & _arg)
  {
    this->lane_type = _arg;
    return *this;
  }
  Type & set__lane_color(
    const uint8_t & _arg)
  {
    this->lane_color = _arg;
    return *this;
  }
  Type & set__road_type(
    const uint8_t & _arg)
  {
    this->road_type = _arg;
    return *this;
  }
  Type & set__feature_type(
    const uint8_t & _arg)
  {
    this->feature_type = _arg;
    return *this;
  }
  Type & set__intersection(
    const uint8_t & _arg)
  {
    this->intersection = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    sa_msgs::msg::SanetLaneAttribute_<ContainerAllocator> *;
  using ConstRawPtr =
    const sa_msgs::msg::SanetLaneAttribute_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<sa_msgs::msg::SanetLaneAttribute_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<sa_msgs::msg::SanetLaneAttribute_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      sa_msgs::msg::SanetLaneAttribute_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<sa_msgs::msg::SanetLaneAttribute_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      sa_msgs::msg::SanetLaneAttribute_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<sa_msgs::msg::SanetLaneAttribute_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<sa_msgs::msg::SanetLaneAttribute_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<sa_msgs::msg::SanetLaneAttribute_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__sa_msgs__msg__SanetLaneAttribute
    std::shared_ptr<sa_msgs::msg::SanetLaneAttribute_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__sa_msgs__msg__SanetLaneAttribute
    std::shared_ptr<sa_msgs::msg::SanetLaneAttribute_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const SanetLaneAttribute_ & other) const
  {
    if (this->lane_type != other.lane_type) {
      return false;
    }
    if (this->lane_color != other.lane_color) {
      return false;
    }
    if (this->road_type != other.road_type) {
      return false;
    }
    if (this->feature_type != other.feature_type) {
      return false;
    }
    if (this->intersection != other.intersection) {
      return false;
    }
    return true;
  }
  bool operator!=(const SanetLaneAttribute_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct SanetLaneAttribute_

// alias to use template instance with default allocator
using SanetLaneAttribute =
  sa_msgs::msg::SanetLaneAttribute_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace sa_msgs

#endif  // SA_MSGS__MSG__DETAIL__SANET_LANE_ATTRIBUTE__STRUCT_HPP_
