// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef SA_MSGS__MSG__OBSTACLE_SL_BOUNDARY_HPP_
#define SA_MSGS__MSG__OBSTACLE_SL_BOUNDARY_HPP_

#include "sa_msgs/msg/detail/obstacle_sl_boundary__struct.hpp"
#include "sa_msgs/msg/detail/obstacle_sl_boundary__builder.hpp"
#include "sa_msgs/msg/detail/obstacle_sl_boundary__traits.hpp"
#include "sa_msgs/msg/detail/obstacle_sl_boundary__type_support.hpp"

#endif  // SA_MSGS__MSG__OBSTACLE_SL_BOUNDARY_HPP_
