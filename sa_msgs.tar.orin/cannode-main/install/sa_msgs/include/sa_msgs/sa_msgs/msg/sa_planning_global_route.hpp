// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef SA_MSGS__MSG__SA_PLANNING_GLOBAL_ROUTE_HPP_
#define SA_MSGS__MSG__SA_PLANNING_GLOBAL_ROUTE_HPP_

#include "sa_msgs/msg/detail/sa_planning_global_route__struct.hpp"
#include "sa_msgs/msg/detail/sa_planning_global_route__builder.hpp"
#include "sa_msgs/msg/detail/sa_planning_global_route__traits.hpp"
#include "sa_msgs/msg/detail/sa_planning_global_route__type_support.hpp"

#endif  // SA_MSGS__MSG__SA_PLANNING_GLOBAL_ROUTE_HPP_
