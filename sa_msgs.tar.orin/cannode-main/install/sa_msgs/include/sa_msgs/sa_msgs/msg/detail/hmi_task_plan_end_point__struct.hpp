// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from sa_msgs:msg/HmiTaskPlanEndPoint.idl
// generated code does not contain a copyright notice

#ifndef SA_MSGS__MSG__DETAIL__HMI_TASK_PLAN_END_POINT__STRUCT_HPP_
#define SA_MSGS__MSG__DETAIL__HMI_TASK_PLAN_END_POINT__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


#ifndef _WIN32
# define DEPRECATED__sa_msgs__msg__HmiTaskPlanEndPoint __attribute__((deprecated))
#else
# define DEPRECATED__sa_msgs__msg__HmiTaskPlanEndPoint __declspec(deprecated)
#endif

namespace sa_msgs
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct HmiTaskPlanEndPoint_
{
  using Type = HmiTaskPlanEndPoint_<ContainerAllocator>;

  explicit HmiTaskPlanEndPoint_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->heading = 0.0f;
      this->station_name = "";
      this->parkingspace_id = 0;
      this->parkingspot_id = 0;
    }
  }

  explicit HmiTaskPlanEndPoint_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : station_name(_alloc)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->heading = 0.0f;
      this->station_name = "";
      this->parkingspace_id = 0;
      this->parkingspot_id = 0;
    }
  }

  // field types and members
  using _point_type =
    std::vector<double, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<double>>;
  _point_type point;
  using _heading_type =
    float;
  _heading_type heading;
  using _station_name_type =
    std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>;
  _station_name_type station_name;
  using _parkingspace_id_type =
    int16_t;
  _parkingspace_id_type parkingspace_id;
  using _parkingspot_id_type =
    int16_t;
  _parkingspot_id_type parkingspot_id;

  // setters for named parameter idiom
  Type & set__point(
    const std::vector<double, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<double>> & _arg)
  {
    this->point = _arg;
    return *this;
  }
  Type & set__heading(
    const float & _arg)
  {
    this->heading = _arg;
    return *this;
  }
  Type & set__station_name(
    const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> & _arg)
  {
    this->station_name = _arg;
    return *this;
  }
  Type & set__parkingspace_id(
    const int16_t & _arg)
  {
    this->parkingspace_id = _arg;
    return *this;
  }
  Type & set__parkingspot_id(
    const int16_t & _arg)
  {
    this->parkingspot_id = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    sa_msgs::msg::HmiTaskPlanEndPoint_<ContainerAllocator> *;
  using ConstRawPtr =
    const sa_msgs::msg::HmiTaskPlanEndPoint_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<sa_msgs::msg::HmiTaskPlanEndPoint_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<sa_msgs::msg::HmiTaskPlanEndPoint_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      sa_msgs::msg::HmiTaskPlanEndPoint_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<sa_msgs::msg::HmiTaskPlanEndPoint_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      sa_msgs::msg::HmiTaskPlanEndPoint_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<sa_msgs::msg::HmiTaskPlanEndPoint_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<sa_msgs::msg::HmiTaskPlanEndPoint_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<sa_msgs::msg::HmiTaskPlanEndPoint_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__sa_msgs__msg__HmiTaskPlanEndPoint
    std::shared_ptr<sa_msgs::msg::HmiTaskPlanEndPoint_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__sa_msgs__msg__HmiTaskPlanEndPoint
    std::shared_ptr<sa_msgs::msg::HmiTaskPlanEndPoint_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const HmiTaskPlanEndPoint_ & other) const
  {
    if (this->point != other.point) {
      return false;
    }
    if (this->heading != other.heading) {
      return false;
    }
    if (this->station_name != other.station_name) {
      return false;
    }
    if (this->parkingspace_id != other.parkingspace_id) {
      return false;
    }
    if (this->parkingspot_id != other.parkingspot_id) {
      return false;
    }
    return true;
  }
  bool operator!=(const HmiTaskPlanEndPoint_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct HmiTaskPlanEndPoint_

// alias to use template instance with default allocator
using HmiTaskPlanEndPoint =
  sa_msgs::msg::HmiTaskPlanEndPoint_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace sa_msgs

#endif  // SA_MSGS__MSG__DETAIL__HMI_TASK_PLAN_END_POINT__STRUCT_HPP_
