// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from sa_msgs:msg/HafWayPointV2.idl
// generated code does not contain a copyright notice

#ifndef SA_MSGS__MSG__DETAIL__HAF_WAY_POINT_V2__BUILDER_HPP_
#define SA_MSGS__MSG__DETAIL__HAF_WAY_POINT_V2__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "sa_msgs/msg/detail/haf_way_point_v2__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace sa_msgs
{

namespace msg
{

namespace builder
{

class Init_HafWayPointV2_station_name
{
public:
  explicit Init_HafWayPointV2_station_name(::sa_msgs::msg::HafWayPointV2 & msg)
  : msg_(msg)
  {}
  ::sa_msgs::msg::HafWayPointV2 station_name(::sa_msgs::msg::HafWayPointV2::_station_name_type arg)
  {
    msg_.station_name = std::move(arg);
    return std::move(msg_);
  }

private:
  ::sa_msgs::msg::HafWayPointV2 msg_;
};

class Init_HafWayPointV2_point
{
public:
  explicit Init_HafWayPointV2_point(::sa_msgs::msg::HafWayPointV2 & msg)
  : msg_(msg)
  {}
  Init_HafWayPointV2_station_name point(::sa_msgs::msg::HafWayPointV2::_point_type arg)
  {
    msg_.point = std::move(arg);
    return Init_HafWayPointV2_station_name(msg_);
  }

private:
  ::sa_msgs::msg::HafWayPointV2 msg_;
};

class Init_HafWayPointV2_type
{
public:
  Init_HafWayPointV2_type()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_HafWayPointV2_point type(::sa_msgs::msg::HafWayPointV2::_type_type arg)
  {
    msg_.type = std::move(arg);
    return Init_HafWayPointV2_point(msg_);
  }

private:
  ::sa_msgs::msg::HafWayPointV2 msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::sa_msgs::msg::HafWayPointV2>()
{
  return sa_msgs::msg::builder::Init_HafWayPointV2_type();
}

}  // namespace sa_msgs

#endif  // SA_MSGS__MSG__DETAIL__HAF_WAY_POINT_V2__BUILDER_HPP_
