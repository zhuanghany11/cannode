// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from sa_msgs:msg/Sa2dDetection.idl
// generated code does not contain a copyright notice

#ifndef SA_MSGS__MSG__DETAIL__SA2D_DETECTION__BUILDER_HPP_
#define SA_MSGS__MSG__DETAIL__SA2D_DETECTION__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "sa_msgs/msg/detail/sa2d_detection__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace sa_msgs
{

namespace msg
{

namespace builder
{

class Init_Sa2dDetection_confidence
{
public:
  explicit Init_Sa2dDetection_confidence(::sa_msgs::msg::Sa2dDetection & msg)
  : msg_(msg)
  {}
  ::sa_msgs::msg::Sa2dDetection confidence(::sa_msgs::msg::Sa2dDetection::_confidence_type arg)
  {
    msg_.confidence = std::move(arg);
    return std::move(msg_);
  }

private:
  ::sa_msgs::msg::Sa2dDetection msg_;
};

class Init_Sa2dDetection_size
{
public:
  explicit Init_Sa2dDetection_size(::sa_msgs::msg::Sa2dDetection & msg)
  : msg_(msg)
  {}
  Init_Sa2dDetection_confidence size(::sa_msgs::msg::Sa2dDetection::_size_type arg)
  {
    msg_.size = std::move(arg);
    return Init_Sa2dDetection_confidence(msg_);
  }

private:
  ::sa_msgs::msg::Sa2dDetection msg_;
};

class Init_Sa2dDetection_center
{
public:
  explicit Init_Sa2dDetection_center(::sa_msgs::msg::Sa2dDetection & msg)
  : msg_(msg)
  {}
  Init_Sa2dDetection_size center(::sa_msgs::msg::Sa2dDetection::_center_type arg)
  {
    msg_.center = std::move(arg);
    return Init_Sa2dDetection_size(msg_);
  }

private:
  ::sa_msgs::msg::Sa2dDetection msg_;
};

class Init_Sa2dDetection_remainning_time
{
public:
  explicit Init_Sa2dDetection_remainning_time(::sa_msgs::msg::Sa2dDetection & msg)
  : msg_(msg)
  {}
  Init_Sa2dDetection_center remainning_time(::sa_msgs::msg::Sa2dDetection::_remainning_time_type arg)
  {
    msg_.remainning_time = std::move(arg);
    return Init_Sa2dDetection_center(msg_);
  }

private:
  ::sa_msgs::msg::Sa2dDetection msg_;
};

class Init_Sa2dDetection_direction
{
public:
  explicit Init_Sa2dDetection_direction(::sa_msgs::msg::Sa2dDetection & msg)
  : msg_(msg)
  {}
  Init_Sa2dDetection_remainning_time direction(::sa_msgs::msg::Sa2dDetection::_direction_type arg)
  {
    msg_.direction = std::move(arg);
    return Init_Sa2dDetection_remainning_time(msg_);
  }

private:
  ::sa_msgs::msg::Sa2dDetection msg_;
};

class Init_Sa2dDetection_cls
{
public:
  explicit Init_Sa2dDetection_cls(::sa_msgs::msg::Sa2dDetection & msg)
  : msg_(msg)
  {}
  Init_Sa2dDetection_direction cls(::sa_msgs::msg::Sa2dDetection::_cls_type arg)
  {
    msg_.cls = std::move(arg);
    return Init_Sa2dDetection_direction(msg_);
  }

private:
  ::sa_msgs::msg::Sa2dDetection msg_;
};

class Init_Sa2dDetection_object_id
{
public:
  Init_Sa2dDetection_object_id()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_Sa2dDetection_cls object_id(::sa_msgs::msg::Sa2dDetection::_object_id_type arg)
  {
    msg_.object_id = std::move(arg);
    return Init_Sa2dDetection_cls(msg_);
  }

private:
  ::sa_msgs::msg::Sa2dDetection msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::sa_msgs::msg::Sa2dDetection>()
{
  return sa_msgs::msg::builder::Init_Sa2dDetection_object_id();
}

}  // namespace sa_msgs

#endif  // SA_MSGS__MSG__DETAIL__SA2D_DETECTION__BUILDER_HPP_
