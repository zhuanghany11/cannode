// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from sa_msgs:msg/HmiTaskPlanBase.idl
// generated code does not contain a copyright notice

#ifndef SA_MSGS__MSG__DETAIL__HMI_TASK_PLAN_BASE__BUILDER_HPP_
#define SA_MSGS__MSG__DETAIL__HMI_TASK_PLAN_BASE__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "sa_msgs/msg/detail/hmi_task_plan_base__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace sa_msgs
{

namespace msg
{

namespace builder
{

class Init_HmiTaskPlanBase_data
{
public:
  explicit Init_HmiTaskPlanBase_data(::sa_msgs::msg::HmiTaskPlanBase & msg)
  : msg_(msg)
  {}
  ::sa_msgs::msg::HmiTaskPlanBase data(::sa_msgs::msg::HmiTaskPlanBase::_data_type arg)
  {
    msg_.data = std::move(arg);
    return std::move(msg_);
  }

private:
  ::sa_msgs::msg::HmiTaskPlanBase msg_;
};

class Init_HmiTaskPlanBase_flow_id
{
public:
  explicit Init_HmiTaskPlanBase_flow_id(::sa_msgs::msg::HmiTaskPlanBase & msg)
  : msg_(msg)
  {}
  Init_HmiTaskPlanBase_data flow_id(::sa_msgs::msg::HmiTaskPlanBase::_flow_id_type arg)
  {
    msg_.flow_id = std::move(arg);
    return Init_HmiTaskPlanBase_data(msg_);
  }

private:
  ::sa_msgs::msg::HmiTaskPlanBase msg_;
};

class Init_HmiTaskPlanBase_signature
{
public:
  explicit Init_HmiTaskPlanBase_signature(::sa_msgs::msg::HmiTaskPlanBase & msg)
  : msg_(msg)
  {}
  Init_HmiTaskPlanBase_flow_id signature(::sa_msgs::msg::HmiTaskPlanBase::_signature_type arg)
  {
    msg_.signature = std::move(arg);
    return Init_HmiTaskPlanBase_flow_id(msg_);
  }

private:
  ::sa_msgs::msg::HmiTaskPlanBase msg_;
};

class Init_HmiTaskPlanBase_command
{
public:
  Init_HmiTaskPlanBase_command()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_HmiTaskPlanBase_signature command(::sa_msgs::msg::HmiTaskPlanBase::_command_type arg)
  {
    msg_.command = std::move(arg);
    return Init_HmiTaskPlanBase_signature(msg_);
  }

private:
  ::sa_msgs::msg::HmiTaskPlanBase msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::sa_msgs::msg::HmiTaskPlanBase>()
{
  return sa_msgs::msg::builder::Init_HmiTaskPlanBase_command();
}

}  // namespace sa_msgs

#endif  // SA_MSGS__MSG__DETAIL__HMI_TASK_PLAN_BASE__BUILDER_HPP_
