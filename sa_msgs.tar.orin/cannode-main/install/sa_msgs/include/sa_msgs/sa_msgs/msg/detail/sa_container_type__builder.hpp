// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from sa_msgs:msg/SaContainerType.idl
// generated code does not contain a copyright notice

#ifndef SA_MSGS__MSG__DETAIL__SA_CONTAINER_TYPE__BUILDER_HPP_
#define SA_MSGS__MSG__DETAIL__SA_CONTAINER_TYPE__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "sa_msgs/msg/detail/sa_container_type__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace sa_msgs
{

namespace msg
{

namespace builder
{

class Init_SaContainerType_value
{
public:
  Init_SaContainerType_value()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  ::sa_msgs::msg::SaContainerType value(::sa_msgs::msg::SaContainerType::_value_type arg)
  {
    msg_.value = std::move(arg);
    return std::move(msg_);
  }

private:
  ::sa_msgs::msg::SaContainerType msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::sa_msgs::msg::SaContainerType>()
{
  return sa_msgs::msg::builder::Init_SaContainerType_value();
}

}  // namespace sa_msgs

#endif  // SA_MSGS__MSG__DETAIL__SA_CONTAINER_TYPE__BUILDER_HPP_
