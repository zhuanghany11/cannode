// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef SA_MSGS__MSG__HAF_DIAG_SWITCH_HPP_
#define SA_MSGS__MSG__HAF_DIAG_SWITCH_HPP_

#include "sa_msgs/msg/detail/haf_diag_switch__struct.hpp"
#include "sa_msgs/msg/detail/haf_diag_switch__builder.hpp"
#include "sa_msgs/msg/detail/haf_diag_switch__traits.hpp"
#include "sa_msgs/msg/detail/haf_diag_switch__type_support.hpp"

#endif  // SA_MSGS__MSG__HAF_DIAG_SWITCH_HPP_
