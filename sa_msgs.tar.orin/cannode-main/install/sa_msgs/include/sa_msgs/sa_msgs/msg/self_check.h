// generated from rosidl_generator_c/resource/idl.h.em
// with input from sa_msgs:msg/SelfCheck.idl
// generated code does not contain a copyright notice

#ifndef SA_MSGS__MSG__SELF_CHECK_H_
#define SA_MSGS__MSG__SELF_CHECK_H_

#include "sa_msgs/msg/detail/self_check__struct.h"
#include "sa_msgs/msg/detail/self_check__functions.h"
#include "sa_msgs/msg/detail/self_check__type_support.h"

#endif  // SA_MSGS__MSG__SELF_CHECK_H_
