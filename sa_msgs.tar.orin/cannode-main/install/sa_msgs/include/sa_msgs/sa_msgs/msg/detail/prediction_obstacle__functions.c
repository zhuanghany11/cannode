// generated from rosidl_generator_c/resource/idl__functions.c.em
// with input from sa_msgs:msg/PredictionObstacle.idl
// generated code does not contain a copyright notice
#include "sa_msgs/msg/detail/prediction_obstacle__functions.h"

#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

#include "rcutils/allocator.h"


// Include directives for member types
// Member `perception_obstacle`
#include "sa_msgs/msg/detail/perception_obstacle__functions.h"
// Member `trajectory`
#include "sa_msgs/msg/detail/trajectory__functions.h"

bool
sa_msgs__msg__PredictionObstacle__init(sa_msgs__msg__PredictionObstacle * msg)
{
  if (!msg) {
    return false;
  }
  // perception_obstacle
  if (!sa_msgs__msg__PerceptionObstacle__init(&msg->perception_obstacle)) {
    sa_msgs__msg__PredictionObstacle__fini(msg);
    return false;
  }
  // predicted_period
  // trajectory
  if (!sa_msgs__msg__Trajectory__Sequence__init(&msg->trajectory, 0)) {
    sa_msgs__msg__PredictionObstacle__fini(msg);
    return false;
  }
  // is_static
  // adjust_stopped_to_move
  // evaluator_type
  // predictor_type
  return true;
}

void
sa_msgs__msg__PredictionObstacle__fini(sa_msgs__msg__PredictionObstacle * msg)
{
  if (!msg) {
    return;
  }
  // perception_obstacle
  sa_msgs__msg__PerceptionObstacle__fini(&msg->perception_obstacle);
  // predicted_period
  // trajectory
  sa_msgs__msg__Trajectory__Sequence__fini(&msg->trajectory);
  // is_static
  // adjust_stopped_to_move
  // evaluator_type
  // predictor_type
}

bool
sa_msgs__msg__PredictionObstacle__are_equal(const sa_msgs__msg__PredictionObstacle * lhs, const sa_msgs__msg__PredictionObstacle * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // perception_obstacle
  if (!sa_msgs__msg__PerceptionObstacle__are_equal(
      &(lhs->perception_obstacle), &(rhs->perception_obstacle)))
  {
    return false;
  }
  // predicted_period
  if (lhs->predicted_period != rhs->predicted_period) {
    return false;
  }
  // trajectory
  if (!sa_msgs__msg__Trajectory__Sequence__are_equal(
      &(lhs->trajectory), &(rhs->trajectory)))
  {
    return false;
  }
  // is_static
  if (lhs->is_static != rhs->is_static) {
    return false;
  }
  // adjust_stopped_to_move
  if (lhs->adjust_stopped_to_move != rhs->adjust_stopped_to_move) {
    return false;
  }
  // evaluator_type
  if (lhs->evaluator_type != rhs->evaluator_type) {
    return false;
  }
  // predictor_type
  if (lhs->predictor_type != rhs->predictor_type) {
    return false;
  }
  return true;
}

bool
sa_msgs__msg__PredictionObstacle__copy(
  const sa_msgs__msg__PredictionObstacle * input,
  sa_msgs__msg__PredictionObstacle * output)
{
  if (!input || !output) {
    return false;
  }
  // perception_obstacle
  if (!sa_msgs__msg__PerceptionObstacle__copy(
      &(input->perception_obstacle), &(output->perception_obstacle)))
  {
    return false;
  }
  // predicted_period
  output->predicted_period = input->predicted_period;
  // trajectory
  if (!sa_msgs__msg__Trajectory__Sequence__copy(
      &(input->trajectory), &(output->trajectory)))
  {
    return false;
  }
  // is_static
  output->is_static = input->is_static;
  // adjust_stopped_to_move
  output->adjust_stopped_to_move = input->adjust_stopped_to_move;
  // evaluator_type
  output->evaluator_type = input->evaluator_type;
  // predictor_type
  output->predictor_type = input->predictor_type;
  return true;
}

sa_msgs__msg__PredictionObstacle *
sa_msgs__msg__PredictionObstacle__create()
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  sa_msgs__msg__PredictionObstacle * msg = (sa_msgs__msg__PredictionObstacle *)allocator.allocate(sizeof(sa_msgs__msg__PredictionObstacle), allocator.state);
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(sa_msgs__msg__PredictionObstacle));
  bool success = sa_msgs__msg__PredictionObstacle__init(msg);
  if (!success) {
    allocator.deallocate(msg, allocator.state);
    return NULL;
  }
  return msg;
}

void
sa_msgs__msg__PredictionObstacle__destroy(sa_msgs__msg__PredictionObstacle * msg)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (msg) {
    sa_msgs__msg__PredictionObstacle__fini(msg);
  }
  allocator.deallocate(msg, allocator.state);
}


bool
sa_msgs__msg__PredictionObstacle__Sequence__init(sa_msgs__msg__PredictionObstacle__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  sa_msgs__msg__PredictionObstacle * data = NULL;

  if (size) {
    data = (sa_msgs__msg__PredictionObstacle *)allocator.zero_allocate(size, sizeof(sa_msgs__msg__PredictionObstacle), allocator.state);
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = sa_msgs__msg__PredictionObstacle__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        sa_msgs__msg__PredictionObstacle__fini(&data[i - 1]);
      }
      allocator.deallocate(data, allocator.state);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
sa_msgs__msg__PredictionObstacle__Sequence__fini(sa_msgs__msg__PredictionObstacle__Sequence * array)
{
  if (!array) {
    return;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();

  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      sa_msgs__msg__PredictionObstacle__fini(&array->data[i]);
    }
    allocator.deallocate(array->data, allocator.state);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

sa_msgs__msg__PredictionObstacle__Sequence *
sa_msgs__msg__PredictionObstacle__Sequence__create(size_t size)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  sa_msgs__msg__PredictionObstacle__Sequence * array = (sa_msgs__msg__PredictionObstacle__Sequence *)allocator.allocate(sizeof(sa_msgs__msg__PredictionObstacle__Sequence), allocator.state);
  if (!array) {
    return NULL;
  }
  bool success = sa_msgs__msg__PredictionObstacle__Sequence__init(array, size);
  if (!success) {
    allocator.deallocate(array, allocator.state);
    return NULL;
  }
  return array;
}

void
sa_msgs__msg__PredictionObstacle__Sequence__destroy(sa_msgs__msg__PredictionObstacle__Sequence * array)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (array) {
    sa_msgs__msg__PredictionObstacle__Sequence__fini(array);
  }
  allocator.deallocate(array, allocator.state);
}

bool
sa_msgs__msg__PredictionObstacle__Sequence__are_equal(const sa_msgs__msg__PredictionObstacle__Sequence * lhs, const sa_msgs__msg__PredictionObstacle__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!sa_msgs__msg__PredictionObstacle__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
sa_msgs__msg__PredictionObstacle__Sequence__copy(
  const sa_msgs__msg__PredictionObstacle__Sequence * input,
  sa_msgs__msg__PredictionObstacle__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    const size_t allocation_size =
      input->size * sizeof(sa_msgs__msg__PredictionObstacle);
    rcutils_allocator_t allocator = rcutils_get_default_allocator();
    sa_msgs__msg__PredictionObstacle * data =
      (sa_msgs__msg__PredictionObstacle *)allocator.reallocate(
      output->data, allocation_size, allocator.state);
    if (!data) {
      return false;
    }
    // If reallocation succeeded, memory may or may not have been moved
    // to fulfill the allocation request, invalidating output->data.
    output->data = data;
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!sa_msgs__msg__PredictionObstacle__init(&output->data[i])) {
        // If initialization of any new item fails, roll back
        // all previously initialized items. Existing items
        // in output are to be left unmodified.
        for (; i-- > output->capacity; ) {
          sa_msgs__msg__PredictionObstacle__fini(&output->data[i]);
        }
        return false;
      }
    }
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!sa_msgs__msg__PredictionObstacle__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}
