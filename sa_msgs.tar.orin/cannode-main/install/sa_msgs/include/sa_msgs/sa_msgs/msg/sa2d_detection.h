// generated from rosidl_generator_c/resource/idl.h.em
// with input from sa_msgs:msg/Sa2dDetection.idl
// generated code does not contain a copyright notice

#ifndef SA_MSGS__MSG__SA2D_DETECTION_H_
#define SA_MSGS__MSG__SA2D_DETECTION_H_

#include "sa_msgs/msg/detail/sa2d_detection__struct.h"
#include "sa_msgs/msg/detail/sa2d_detection__functions.h"
#include "sa_msgs/msg/detail/sa2d_detection__type_support.h"

#endif  // SA_MSGS__MSG__SA2D_DETECTION_H_
