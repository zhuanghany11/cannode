// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef SA_MSGS__MSG__DUMP_TRUCK_CMD_HPP_
#define SA_MSGS__MSG__DUMP_TRUCK_CMD_HPP_

#include "sa_msgs/msg/detail/dump_truck_cmd__struct.hpp"
#include "sa_msgs/msg/detail/dump_truck_cmd__builder.hpp"
#include "sa_msgs/msg/detail/dump_truck_cmd__traits.hpp"
#include "sa_msgs/msg/detail/dump_truck_cmd__type_support.hpp"

#endif  // SA_MSGS__MSG__DUMP_TRUCK_CMD_HPP_
