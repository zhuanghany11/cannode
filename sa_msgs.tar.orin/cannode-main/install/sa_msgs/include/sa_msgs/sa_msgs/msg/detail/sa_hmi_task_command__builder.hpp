// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from sa_msgs:msg/SaHmiTaskCommand.idl
// generated code does not contain a copyright notice

#ifndef SA_MSGS__MSG__DETAIL__SA_HMI_TASK_COMMAND__BUILDER_HPP_
#define SA_MSGS__MSG__DETAIL__SA_HMI_TASK_COMMAND__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "sa_msgs/msg/detail/sa_hmi_task_command__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace sa_msgs
{

namespace msg
{

namespace builder
{

class Init_SaHmiTaskCommand_task_type
{
public:
  explicit Init_SaHmiTaskCommand_task_type(::sa_msgs::msg::SaHmiTaskCommand & msg)
  : msg_(msg)
  {}
  ::sa_msgs::msg::SaHmiTaskCommand task_type(::sa_msgs::msg::SaHmiTaskCommand::_task_type_type arg)
  {
    msg_.task_type = std::move(arg);
    return std::move(msg_);
  }

private:
  ::sa_msgs::msg::SaHmiTaskCommand msg_;
};

class Init_SaHmiTaskCommand_header
{
public:
  Init_SaHmiTaskCommand_header()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_SaHmiTaskCommand_task_type header(::sa_msgs::msg::SaHmiTaskCommand::_header_type arg)
  {
    msg_.header = std::move(arg);
    return Init_SaHmiTaskCommand_task_type(msg_);
  }

private:
  ::sa_msgs::msg::SaHmiTaskCommand msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::sa_msgs::msg::SaHmiTaskCommand>()
{
  return sa_msgs::msg::builder::Init_SaHmiTaskCommand_header();
}

}  // namespace sa_msgs

#endif  // SA_MSGS__MSG__DETAIL__SA_HMI_TASK_COMMAND__BUILDER_HPP_
