// generated from rosidl_generator_c/resource/idl__functions.c.em
// with input from sa_msgs:msg/SaPlanningRealDataReport.idl
// generated code does not contain a copyright notice
#include "sa_msgs/msg/detail/sa_planning_real_data_report__functions.h"

#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

#include "rcutils/allocator.h"


// Include directives for member types
// Member `header`
#include "std_msgs/msg/detail/header__functions.h"
// Member `plan_path`
#include "geometry_msgs/msg/detail/point__functions.h"
// Member `traffic_light_status`
// Member `traffic_light_time`
#include "rosidl_runtime_c/primitives_sequence_functions.h"
// Member `interruption_suggestion_msg`
// Member `next_station_name`
#include "rosidl_runtime_c/string_functions.h"

bool
sa_msgs__msg__SaPlanningRealDataReport__init(sa_msgs__msg__SaPlanningRealDataReport * msg)
{
  if (!msg) {
    return false;
  }
  // header
  if (!std_msgs__msg__Header__init(&msg->header)) {
    sa_msgs__msg__SaPlanningRealDataReport__fini(msg);
    return false;
  }
  // planning_status
  // is_odd
  // mission_type
  // velocity_limit
  // plan_path
  if (!geometry_msgs__msg__Point__Sequence__init(&msg->plan_path, 0)) {
    sa_msgs__msg__SaPlanningRealDataReport__fini(msg);
    return false;
  }
  // next_station_dist
  // end_station_dist
  // traffic_light_status
  if (!rosidl_runtime_c__int32__Sequence__init(&msg->traffic_light_status, 0)) {
    sa_msgs__msg__SaPlanningRealDataReport__fini(msg);
    return false;
  }
  // traffic_light_time
  if (!rosidl_runtime_c__int32__Sequence__init(&msg->traffic_light_time, 0)) {
    sa_msgs__msg__SaPlanningRealDataReport__fini(msg);
    return false;
  }
  // interruption_suggestion_type
  // interruption_suggestion_msg
  if (!rosidl_runtime_c__String__init(&msg->interruption_suggestion_msg)) {
    sa_msgs__msg__SaPlanningRealDataReport__fini(msg);
    return false;
  }
  // next_station_name
  if (!rosidl_runtime_c__String__init(&msg->next_station_name)) {
    sa_msgs__msg__SaPlanningRealDataReport__fini(msg);
    return false;
  }
  return true;
}

void
sa_msgs__msg__SaPlanningRealDataReport__fini(sa_msgs__msg__SaPlanningRealDataReport * msg)
{
  if (!msg) {
    return;
  }
  // header
  std_msgs__msg__Header__fini(&msg->header);
  // planning_status
  // is_odd
  // mission_type
  // velocity_limit
  // plan_path
  geometry_msgs__msg__Point__Sequence__fini(&msg->plan_path);
  // next_station_dist
  // end_station_dist
  // traffic_light_status
  rosidl_runtime_c__int32__Sequence__fini(&msg->traffic_light_status);
  // traffic_light_time
  rosidl_runtime_c__int32__Sequence__fini(&msg->traffic_light_time);
  // interruption_suggestion_type
  // interruption_suggestion_msg
  rosidl_runtime_c__String__fini(&msg->interruption_suggestion_msg);
  // next_station_name
  rosidl_runtime_c__String__fini(&msg->next_station_name);
}

bool
sa_msgs__msg__SaPlanningRealDataReport__are_equal(const sa_msgs__msg__SaPlanningRealDataReport * lhs, const sa_msgs__msg__SaPlanningRealDataReport * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // header
  if (!std_msgs__msg__Header__are_equal(
      &(lhs->header), &(rhs->header)))
  {
    return false;
  }
  // planning_status
  if (lhs->planning_status != rhs->planning_status) {
    return false;
  }
  // is_odd
  if (lhs->is_odd != rhs->is_odd) {
    return false;
  }
  // mission_type
  if (lhs->mission_type != rhs->mission_type) {
    return false;
  }
  // velocity_limit
  if (lhs->velocity_limit != rhs->velocity_limit) {
    return false;
  }
  // plan_path
  if (!geometry_msgs__msg__Point__Sequence__are_equal(
      &(lhs->plan_path), &(rhs->plan_path)))
  {
    return false;
  }
  // next_station_dist
  if (lhs->next_station_dist != rhs->next_station_dist) {
    return false;
  }
  // end_station_dist
  if (lhs->end_station_dist != rhs->end_station_dist) {
    return false;
  }
  // traffic_light_status
  if (!rosidl_runtime_c__int32__Sequence__are_equal(
      &(lhs->traffic_light_status), &(rhs->traffic_light_status)))
  {
    return false;
  }
  // traffic_light_time
  if (!rosidl_runtime_c__int32__Sequence__are_equal(
      &(lhs->traffic_light_time), &(rhs->traffic_light_time)))
  {
    return false;
  }
  // interruption_suggestion_type
  if (lhs->interruption_suggestion_type != rhs->interruption_suggestion_type) {
    return false;
  }
  // interruption_suggestion_msg
  if (!rosidl_runtime_c__String__are_equal(
      &(lhs->interruption_suggestion_msg), &(rhs->interruption_suggestion_msg)))
  {
    return false;
  }
  // next_station_name
  if (!rosidl_runtime_c__String__are_equal(
      &(lhs->next_station_name), &(rhs->next_station_name)))
  {
    return false;
  }
  return true;
}

bool
sa_msgs__msg__SaPlanningRealDataReport__copy(
  const sa_msgs__msg__SaPlanningRealDataReport * input,
  sa_msgs__msg__SaPlanningRealDataReport * output)
{
  if (!input || !output) {
    return false;
  }
  // header
  if (!std_msgs__msg__Header__copy(
      &(input->header), &(output->header)))
  {
    return false;
  }
  // planning_status
  output->planning_status = input->planning_status;
  // is_odd
  output->is_odd = input->is_odd;
  // mission_type
  output->mission_type = input->mission_type;
  // velocity_limit
  output->velocity_limit = input->velocity_limit;
  // plan_path
  if (!geometry_msgs__msg__Point__Sequence__copy(
      &(input->plan_path), &(output->plan_path)))
  {
    return false;
  }
  // next_station_dist
  output->next_station_dist = input->next_station_dist;
  // end_station_dist
  output->end_station_dist = input->end_station_dist;
  // traffic_light_status
  if (!rosidl_runtime_c__int32__Sequence__copy(
      &(input->traffic_light_status), &(output->traffic_light_status)))
  {
    return false;
  }
  // traffic_light_time
  if (!rosidl_runtime_c__int32__Sequence__copy(
      &(input->traffic_light_time), &(output->traffic_light_time)))
  {
    return false;
  }
  // interruption_suggestion_type
  output->interruption_suggestion_type = input->interruption_suggestion_type;
  // interruption_suggestion_msg
  if (!rosidl_runtime_c__String__copy(
      &(input->interruption_suggestion_msg), &(output->interruption_suggestion_msg)))
  {
    return false;
  }
  // next_station_name
  if (!rosidl_runtime_c__String__copy(
      &(input->next_station_name), &(output->next_station_name)))
  {
    return false;
  }
  return true;
}

sa_msgs__msg__SaPlanningRealDataReport *
sa_msgs__msg__SaPlanningRealDataReport__create()
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  sa_msgs__msg__SaPlanningRealDataReport * msg = (sa_msgs__msg__SaPlanningRealDataReport *)allocator.allocate(sizeof(sa_msgs__msg__SaPlanningRealDataReport), allocator.state);
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(sa_msgs__msg__SaPlanningRealDataReport));
  bool success = sa_msgs__msg__SaPlanningRealDataReport__init(msg);
  if (!success) {
    allocator.deallocate(msg, allocator.state);
    return NULL;
  }
  return msg;
}

void
sa_msgs__msg__SaPlanningRealDataReport__destroy(sa_msgs__msg__SaPlanningRealDataReport * msg)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (msg) {
    sa_msgs__msg__SaPlanningRealDataReport__fini(msg);
  }
  allocator.deallocate(msg, allocator.state);
}


bool
sa_msgs__msg__SaPlanningRealDataReport__Sequence__init(sa_msgs__msg__SaPlanningRealDataReport__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  sa_msgs__msg__SaPlanningRealDataReport * data = NULL;

  if (size) {
    data = (sa_msgs__msg__SaPlanningRealDataReport *)allocator.zero_allocate(size, sizeof(sa_msgs__msg__SaPlanningRealDataReport), allocator.state);
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = sa_msgs__msg__SaPlanningRealDataReport__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        sa_msgs__msg__SaPlanningRealDataReport__fini(&data[i - 1]);
      }
      allocator.deallocate(data, allocator.state);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
sa_msgs__msg__SaPlanningRealDataReport__Sequence__fini(sa_msgs__msg__SaPlanningRealDataReport__Sequence * array)
{
  if (!array) {
    return;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();

  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      sa_msgs__msg__SaPlanningRealDataReport__fini(&array->data[i]);
    }
    allocator.deallocate(array->data, allocator.state);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

sa_msgs__msg__SaPlanningRealDataReport__Sequence *
sa_msgs__msg__SaPlanningRealDataReport__Sequence__create(size_t size)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  sa_msgs__msg__SaPlanningRealDataReport__Sequence * array = (sa_msgs__msg__SaPlanningRealDataReport__Sequence *)allocator.allocate(sizeof(sa_msgs__msg__SaPlanningRealDataReport__Sequence), allocator.state);
  if (!array) {
    return NULL;
  }
  bool success = sa_msgs__msg__SaPlanningRealDataReport__Sequence__init(array, size);
  if (!success) {
    allocator.deallocate(array, allocator.state);
    return NULL;
  }
  return array;
}

void
sa_msgs__msg__SaPlanningRealDataReport__Sequence__destroy(sa_msgs__msg__SaPlanningRealDataReport__Sequence * array)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (array) {
    sa_msgs__msg__SaPlanningRealDataReport__Sequence__fini(array);
  }
  allocator.deallocate(array, allocator.state);
}

bool
sa_msgs__msg__SaPlanningRealDataReport__Sequence__are_equal(const sa_msgs__msg__SaPlanningRealDataReport__Sequence * lhs, const sa_msgs__msg__SaPlanningRealDataReport__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!sa_msgs__msg__SaPlanningRealDataReport__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
sa_msgs__msg__SaPlanningRealDataReport__Sequence__copy(
  const sa_msgs__msg__SaPlanningRealDataReport__Sequence * input,
  sa_msgs__msg__SaPlanningRealDataReport__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    const size_t allocation_size =
      input->size * sizeof(sa_msgs__msg__SaPlanningRealDataReport);
    rcutils_allocator_t allocator = rcutils_get_default_allocator();
    sa_msgs__msg__SaPlanningRealDataReport * data =
      (sa_msgs__msg__SaPlanningRealDataReport *)allocator.reallocate(
      output->data, allocation_size, allocator.state);
    if (!data) {
      return false;
    }
    // If reallocation succeeded, memory may or may not have been moved
    // to fulfill the allocation request, invalidating output->data.
    output->data = data;
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!sa_msgs__msg__SaPlanningRealDataReport__init(&output->data[i])) {
        // If initialization of any new item fails, roll back
        // all previously initialized items. Existing items
        // in output are to be left unmodified.
        for (; i-- > output->capacity; ) {
          sa_msgs__msg__SaPlanningRealDataReport__fini(&output->data[i]);
        }
        return false;
      }
    }
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!sa_msgs__msg__SaPlanningRealDataReport__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}
