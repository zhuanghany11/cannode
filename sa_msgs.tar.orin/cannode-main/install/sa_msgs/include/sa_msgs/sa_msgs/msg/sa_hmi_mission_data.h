// generated from rosidl_generator_c/resource/idl.h.em
// with input from sa_msgs:msg/SaHmiMissionData.idl
// generated code does not contain a copyright notice

#ifndef SA_MSGS__MSG__SA_HMI_MISSION_DATA_H_
#define SA_MSGS__MSG__SA_HMI_MISSION_DATA_H_

#include "sa_msgs/msg/detail/sa_hmi_mission_data__struct.h"
#include "sa_msgs/msg/detail/sa_hmi_mission_data__functions.h"
#include "sa_msgs/msg/detail/sa_hmi_mission_data__type_support.h"

#endif  // SA_MSGS__MSG__SA_HMI_MISSION_DATA_H_
