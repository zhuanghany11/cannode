// generated from rosidl_generator_c/resource/idl.h.em
// with input from sa_msgs:msg/SaLocation.idl
// generated code does not contain a copyright notice

#ifndef SA_MSGS__MSG__SA_LOCATION_H_
#define SA_MSGS__MSG__SA_LOCATION_H_

#include "sa_msgs/msg/detail/sa_location__struct.h"
#include "sa_msgs/msg/detail/sa_location__functions.h"
#include "sa_msgs/msg/detail/sa_location__type_support.h"

#endif  // SA_MSGS__MSG__SA_LOCATION_H_
