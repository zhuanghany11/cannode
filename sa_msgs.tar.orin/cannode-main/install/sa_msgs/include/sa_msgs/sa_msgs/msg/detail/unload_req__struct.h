﻿// NOLINT: This file starts with a BOM since it contain non-ASCII characters
// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from sa_msgs:msg/UnloadReq.idl
// generated code does not contain a copyright notice

#ifndef SA_MSGS__MSG__DETAIL__UNLOAD_REQ__STRUCT_H_
#define SA_MSGS__MSG__DETAIL__UNLOAD_REQ__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__struct.h"
// Member 'truck_id'
// Member 'load_slot_id'
#include "rosidl_runtime_c/string.h"
// Member 'pb'
#include "rosidl_runtime_c/primitives_sequence.h"

/// Struct defined in msg/UnloadReq in the package sa_msgs.
typedef struct sa_msgs__msg__UnloadReq
{
  std_msgs__msg__Header header;
  /// 动作指令唯一标识
  uint32_t seq;
  /// 自卸车ID
  rosidl_runtime_c__String truck_id;
  /// 装载位/卸载位ID
  rosidl_runtime_c__String load_slot_id;
  /// 装载位坐标
  double lon;
  /// 装载位坐标
  double lat;
  /// 装载位坐标
  double alt;
  /// 装载位航向角
  double heading;
  /// pb扩展
  rosidl_runtime_c__octet__Sequence pb;
} sa_msgs__msg__UnloadReq;

// Struct for a sequence of sa_msgs__msg__UnloadReq.
typedef struct sa_msgs__msg__UnloadReq__Sequence
{
  sa_msgs__msg__UnloadReq * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} sa_msgs__msg__UnloadReq__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // SA_MSGS__MSG__DETAIL__UNLOAD_REQ__STRUCT_H_
