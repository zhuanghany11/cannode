// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from sa_msgs:msg/HmiTaskPlanData.idl
// generated code does not contain a copyright notice

#ifndef SA_MSGS__MSG__DETAIL__HMI_TASK_PLAN_DATA__STRUCT_H_
#define SA_MSGS__MSG__DETAIL__HMI_TASK_PLAN_DATA__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'chs_pos'
// Member 'crane_id'
#include "rosidl_runtime_c/string.h"
// Member 'end_point'
#include "sa_msgs/msg/detail/hmi_task_plan_end_point__struct.h"
// Member 'way_points'
#include "sa_msgs/msg/detail/hmi_task_plan_way_point__struct.h"

/// Struct defined in msg/HmiTaskPlanData in the package sa_msgs.
typedef struct sa_msgs__msg__HmiTaskPlanData
{
  int64_t work_id;
  int8_t task_type;
  int64_t timestamp;
  int64_t task_id;
  rosidl_runtime_c__String chs_pos;
  int32_t lift_weight;
  rosidl_runtime_c__String crane_id;
  sa_msgs__msg__HmiTaskPlanEndPoint end_point;
  sa_msgs__msg__HmiTaskPlanWayPoint__Sequence way_points;
} sa_msgs__msg__HmiTaskPlanData;

// Struct for a sequence of sa_msgs__msg__HmiTaskPlanData.
typedef struct sa_msgs__msg__HmiTaskPlanData__Sequence
{
  sa_msgs__msg__HmiTaskPlanData * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} sa_msgs__msg__HmiTaskPlanData__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // SA_MSGS__MSG__DETAIL__HMI_TASK_PLAN_DATA__STRUCT_H_
