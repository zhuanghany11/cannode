// generated from rosidl_generator_c/resource/idl.h.em
// with input from sa_msgs:msg/ChassisStatus.idl
// generated code does not contain a copyright notice

#ifndef SA_MSGS__MSG__CHASSIS_STATUS_H_
#define SA_MSGS__MSG__CHASSIS_STATUS_H_

#include "sa_msgs/msg/detail/chassis_status__struct.h"
#include "sa_msgs/msg/detail/chassis_status__functions.h"
#include "sa_msgs/msg/detail/chassis_status__type_support.h"

#endif  // SA_MSGS__MSG__CHASSIS_STATUS_H_
