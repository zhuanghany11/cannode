// generated from rosidl_generator_c/resource/idl.h.em
// with input from sa_msgs:msg/SaTrafficLightInfo.idl
// generated code does not contain a copyright notice

#ifndef SA_MSGS__MSG__SA_TRAFFIC_LIGHT_INFO_H_
#define SA_MSGS__MSG__SA_TRAFFIC_LIGHT_INFO_H_

#include "sa_msgs/msg/detail/sa_traffic_light_info__struct.h"
#include "sa_msgs/msg/detail/sa_traffic_light_info__functions.h"
#include "sa_msgs/msg/detail/sa_traffic_light_info__type_support.h"

#endif  // SA_MSGS__MSG__SA_TRAFFIC_LIGHT_INFO_H_
