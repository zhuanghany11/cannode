// generated from rosidl_generator_c/resource/idl.h.em
// with input from sa_msgs:msg/Rotation.idl
// generated code does not contain a copyright notice

#ifndef SA_MSGS__MSG__ROTATION_H_
#define SA_MSGS__MSG__ROTATION_H_

#include "sa_msgs/msg/detail/rotation__struct.h"
#include "sa_msgs/msg/detail/rotation__functions.h"
#include "sa_msgs/msg/detail/rotation__type_support.h"

#endif  // SA_MSGS__MSG__ROTATION_H_
