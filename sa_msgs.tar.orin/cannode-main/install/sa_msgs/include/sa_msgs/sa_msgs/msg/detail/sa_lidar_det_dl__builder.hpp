// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from sa_msgs:msg/SaLidarDetDl.idl
// generated code does not contain a copyright notice

#ifndef SA_MSGS__MSG__DETAIL__SA_LIDAR_DET_DL__BUILDER_HPP_
#define SA_MSGS__MSG__DETAIL__SA_LIDAR_DET_DL__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "sa_msgs/msg/detail/sa_lidar_det_dl__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace sa_msgs
{

namespace msg
{

namespace builder
{

class Init_SaLidarDetDl_detection_out
{
public:
  explicit Init_SaLidarDetDl_detection_out(::sa_msgs::msg::SaLidarDetDl & msg)
  : msg_(msg)
  {}
  ::sa_msgs::msg::SaLidarDetDl detection_out(::sa_msgs::msg::SaLidarDetDl::_detection_out_type arg)
  {
    msg_.detection_out = std::move(arg);
    return std::move(msg_);
  }

private:
  ::sa_msgs::msg::SaLidarDetDl msg_;
};

class Init_SaLidarDetDl_header
{
public:
  Init_SaLidarDetDl_header()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_SaLidarDetDl_detection_out header(::sa_msgs::msg::SaLidarDetDl::_header_type arg)
  {
    msg_.header = std::move(arg);
    return Init_SaLidarDetDl_detection_out(msg_);
  }

private:
  ::sa_msgs::msg::SaLidarDetDl msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::sa_msgs::msg::SaLidarDetDl>()
{
  return sa_msgs::msg::builder::Init_SaLidarDetDl_header();
}

}  // namespace sa_msgs

#endif  // SA_MSGS__MSG__DETAIL__SA_LIDAR_DET_DL__BUILDER_HPP_
