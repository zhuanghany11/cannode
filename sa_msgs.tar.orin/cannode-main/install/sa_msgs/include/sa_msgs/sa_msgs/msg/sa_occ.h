// generated from rosidl_generator_c/resource/idl.h.em
// with input from sa_msgs:msg/SaOcc.idl
// generated code does not contain a copyright notice

#ifndef SA_MSGS__MSG__SA_OCC_H_
#define SA_MSGS__MSG__SA_OCC_H_

#include "sa_msgs/msg/detail/sa_occ__struct.h"
#include "sa_msgs/msg/detail/sa_occ__functions.h"
#include "sa_msgs/msg/detail/sa_occ__type_support.h"

#endif  // SA_MSGS__MSG__SA_OCC_H_
