// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef SA_MSGS__MSG__HAF_GLOBAL_PLANNING_RESULT_HPP_
#define SA_MSGS__MSG__HAF_GLOBAL_PLANNING_RESULT_HPP_

#include "sa_msgs/msg/detail/haf_global_planning_result__struct.hpp"
#include "sa_msgs/msg/detail/haf_global_planning_result__builder.hpp"
#include "sa_msgs/msg/detail/haf_global_planning_result__traits.hpp"
#include "sa_msgs/msg/detail/haf_global_planning_result__type_support.hpp"

#endif  // SA_MSGS__MSG__HAF_GLOBAL_PLANNING_RESULT_HPP_
