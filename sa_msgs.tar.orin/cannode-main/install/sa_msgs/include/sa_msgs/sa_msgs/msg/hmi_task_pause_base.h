// generated from rosidl_generator_c/resource/idl.h.em
// with input from sa_msgs:msg/HmiTaskPauseBase.idl
// generated code does not contain a copyright notice

#ifndef SA_MSGS__MSG__HMI_TASK_PAUSE_BASE_H_
#define SA_MSGS__MSG__HMI_TASK_PAUSE_BASE_H_

#include "sa_msgs/msg/detail/hmi_task_pause_base__struct.h"
#include "sa_msgs/msg/detail/hmi_task_pause_base__functions.h"
#include "sa_msgs/msg/detail/hmi_task_pause_base__type_support.h"

#endif  // SA_MSGS__MSG__HMI_TASK_PAUSE_BASE_H_
