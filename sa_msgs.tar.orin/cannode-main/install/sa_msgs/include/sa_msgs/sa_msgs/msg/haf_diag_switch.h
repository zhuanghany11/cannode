// generated from rosidl_generator_c/resource/idl.h.em
// with input from sa_msgs:msg/HafDiagSwitch.idl
// generated code does not contain a copyright notice

#ifndef SA_MSGS__MSG__HAF_DIAG_SWITCH_H_
#define SA_MSGS__MSG__HAF_DIAG_SWITCH_H_

#include "sa_msgs/msg/detail/haf_diag_switch__struct.h"
#include "sa_msgs/msg/detail/haf_diag_switch__functions.h"
#include "sa_msgs/msg/detail/haf_diag_switch__type_support.h"

#endif  // SA_MSGS__MSG__HAF_DIAG_SWITCH_H_
