﻿// NOLINT: This file starts with a BOM since it contain non-ASCII characters
// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from sa_msgs:msg/SaTrafficLightInfo.idl
// generated code does not contain a copyright notice

#ifndef SA_MSGS__MSG__DETAIL__SA_TRAFFIC_LIGHT_INFO__STRUCT_H_
#define SA_MSGS__MSG__DETAIL__SA_TRAFFIC_LIGHT_INFO__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'id'
#include "std_msgs/msg/detail/string__struct.h"
// Member 'color'
#include "sa_msgs/msg/detail/sa_traffic_light_color__struct.h"
// Member 'type'
#include "sa_msgs/msg/detail/sa_traffic_light_type__struct.h"

/// Struct defined in msg/SaTrafficLightInfo in the package sa_msgs.
/**
  * map id
 */
typedef struct sa_msgs__msg__SaTrafficLightInfo
{
  std_msgs__msg__String id;
  /// detect color
  sa_msgs__msg__SaTrafficLightColor color;
  /// map type
  sa_msgs__msg__SaTrafficLightType type;
  /// How confidence about the detected results, between 0 and 1.
  double confidence;
  /// Duration of the traffic light since detected.
  double tracking_time;
  /// Is traffic blinking 闪烁
  bool blink;
  /// v2x traffic light remaining time. 倒计时 -1: 无倒计时； 0-99之间为倒计时秒
  int8_t remaining_time;
  /// 触发快照  二进制字节：01: 颜色异常  10：漏检测
  int8_t snap_id;
  /// 车后轴中心到停止线的距离[60m>,>-10m]. 无效距离：10086 单位：m
  double car2stopline;
  /// 车后轴中心到红绿灯的距离(在停止线的合理范围内). 无效距离：10086 单位：m
  double car2light;
} sa_msgs__msg__SaTrafficLightInfo;

// Struct for a sequence of sa_msgs__msg__SaTrafficLightInfo.
typedef struct sa_msgs__msg__SaTrafficLightInfo__Sequence
{
  sa_msgs__msg__SaTrafficLightInfo * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} sa_msgs__msg__SaTrafficLightInfo__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // SA_MSGS__MSG__DETAIL__SA_TRAFFIC_LIGHT_INFO__STRUCT_H_
