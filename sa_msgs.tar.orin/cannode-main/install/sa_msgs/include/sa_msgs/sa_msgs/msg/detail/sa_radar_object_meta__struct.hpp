// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from sa_msgs:msg/SaRadarObjectMeta.idl
// generated code does not contain a copyright notice

#ifndef SA_MSGS__MSG__DETAIL__SA_RADAR_OBJECT_META__STRUCT_HPP_
#define SA_MSGS__MSG__DETAIL__SA_RADAR_OBJECT_META__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


#ifndef _WIN32
# define DEPRECATED__sa_msgs__msg__SaRadarObjectMeta __attribute__((deprecated))
#else
# define DEPRECATED__sa_msgs__msg__SaRadarObjectMeta __declspec(deprecated)
#endif

namespace sa_msgs
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct SaRadarObjectMeta_
{
  using Type = SaRadarObjectMeta_<ContainerAllocator>;

  explicit SaRadarObjectMeta_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->object_id = 0;
      this->object_distlong = 0.0f;
      this->object_distlat = 0.0f;
      this->object_vrellong = 0.0f;
      this->object_vrellat = 0.0f;
      this->object_dynprop = 0;
      this->object_rcs = 0.0f;
      this->object_distlong_rms = 0;
      this->object_vrellong_rms = 0;
      this->object_distlat_rms = 0;
      this->object_vrellat_rms = 0;
      this->object_arellat_rms = 0;
      this->object_arellong_rms = 0;
      this->object_orientation_rms = 0;
      this->object_measstate = 0;
      this->object_probofexist = 0;
      this->object_arellong = 0.0f;
      this->object_class = 0;
      this->object_arellat = 0.0f;
      this->object_orientationangle = 0.0f;
      this->object_length = 0.0f;
      this->object_width = 0.0f;
      this->object_colldetregionbitfield = 0;
    }
  }

  explicit SaRadarObjectMeta_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    (void)_alloc;
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->object_id = 0;
      this->object_distlong = 0.0f;
      this->object_distlat = 0.0f;
      this->object_vrellong = 0.0f;
      this->object_vrellat = 0.0f;
      this->object_dynprop = 0;
      this->object_rcs = 0.0f;
      this->object_distlong_rms = 0;
      this->object_vrellong_rms = 0;
      this->object_distlat_rms = 0;
      this->object_vrellat_rms = 0;
      this->object_arellat_rms = 0;
      this->object_arellong_rms = 0;
      this->object_orientation_rms = 0;
      this->object_measstate = 0;
      this->object_probofexist = 0;
      this->object_arellong = 0.0f;
      this->object_class = 0;
      this->object_arellat = 0.0f;
      this->object_orientationangle = 0.0f;
      this->object_length = 0.0f;
      this->object_width = 0.0f;
      this->object_colldetregionbitfield = 0;
    }
  }

  // field types and members
  using _object_id_type =
    uint8_t;
  _object_id_type object_id;
  using _object_distlong_type =
    float;
  _object_distlong_type object_distlong;
  using _object_distlat_type =
    float;
  _object_distlat_type object_distlat;
  using _object_vrellong_type =
    float;
  _object_vrellong_type object_vrellong;
  using _object_vrellat_type =
    float;
  _object_vrellat_type object_vrellat;
  using _object_dynprop_type =
    uint8_t;
  _object_dynprop_type object_dynprop;
  using _object_rcs_type =
    float;
  _object_rcs_type object_rcs;
  using _object_distlong_rms_type =
    uint8_t;
  _object_distlong_rms_type object_distlong_rms;
  using _object_vrellong_rms_type =
    uint8_t;
  _object_vrellong_rms_type object_vrellong_rms;
  using _object_distlat_rms_type =
    uint8_t;
  _object_distlat_rms_type object_distlat_rms;
  using _object_vrellat_rms_type =
    uint8_t;
  _object_vrellat_rms_type object_vrellat_rms;
  using _object_arellat_rms_type =
    uint8_t;
  _object_arellat_rms_type object_arellat_rms;
  using _object_arellong_rms_type =
    uint8_t;
  _object_arellong_rms_type object_arellong_rms;
  using _object_orientation_rms_type =
    uint8_t;
  _object_orientation_rms_type object_orientation_rms;
  using _object_measstate_type =
    uint8_t;
  _object_measstate_type object_measstate;
  using _object_probofexist_type =
    uint8_t;
  _object_probofexist_type object_probofexist;
  using _object_arellong_type =
    float;
  _object_arellong_type object_arellong;
  using _object_class_type =
    uint8_t;
  _object_class_type object_class;
  using _object_arellat_type =
    float;
  _object_arellat_type object_arellat;
  using _object_orientationangle_type =
    float;
  _object_orientationangle_type object_orientationangle;
  using _object_length_type =
    float;
  _object_length_type object_length;
  using _object_width_type =
    float;
  _object_width_type object_width;
  using _object_colldetregionbitfield_type =
    uint8_t;
  _object_colldetregionbitfield_type object_colldetregionbitfield;

  // setters for named parameter idiom
  Type & set__object_id(
    const uint8_t & _arg)
  {
    this->object_id = _arg;
    return *this;
  }
  Type & set__object_distlong(
    const float & _arg)
  {
    this->object_distlong = _arg;
    return *this;
  }
  Type & set__object_distlat(
    const float & _arg)
  {
    this->object_distlat = _arg;
    return *this;
  }
  Type & set__object_vrellong(
    const float & _arg)
  {
    this->object_vrellong = _arg;
    return *this;
  }
  Type & set__object_vrellat(
    const float & _arg)
  {
    this->object_vrellat = _arg;
    return *this;
  }
  Type & set__object_dynprop(
    const uint8_t & _arg)
  {
    this->object_dynprop = _arg;
    return *this;
  }
  Type & set__object_rcs(
    const float & _arg)
  {
    this->object_rcs = _arg;
    return *this;
  }
  Type & set__object_distlong_rms(
    const uint8_t & _arg)
  {
    this->object_distlong_rms = _arg;
    return *this;
  }
  Type & set__object_vrellong_rms(
    const uint8_t & _arg)
  {
    this->object_vrellong_rms = _arg;
    return *this;
  }
  Type & set__object_distlat_rms(
    const uint8_t & _arg)
  {
    this->object_distlat_rms = _arg;
    return *this;
  }
  Type & set__object_vrellat_rms(
    const uint8_t & _arg)
  {
    this->object_vrellat_rms = _arg;
    return *this;
  }
  Type & set__object_arellat_rms(
    const uint8_t & _arg)
  {
    this->object_arellat_rms = _arg;
    return *this;
  }
  Type & set__object_arellong_rms(
    const uint8_t & _arg)
  {
    this->object_arellong_rms = _arg;
    return *this;
  }
  Type & set__object_orientation_rms(
    const uint8_t & _arg)
  {
    this->object_orientation_rms = _arg;
    return *this;
  }
  Type & set__object_measstate(
    const uint8_t & _arg)
  {
    this->object_measstate = _arg;
    return *this;
  }
  Type & set__object_probofexist(
    const uint8_t & _arg)
  {
    this->object_probofexist = _arg;
    return *this;
  }
  Type & set__object_arellong(
    const float & _arg)
  {
    this->object_arellong = _arg;
    return *this;
  }
  Type & set__object_class(
    const uint8_t & _arg)
  {
    this->object_class = _arg;
    return *this;
  }
  Type & set__object_arellat(
    const float & _arg)
  {
    this->object_arellat = _arg;
    return *this;
  }
  Type & set__object_orientationangle(
    const float & _arg)
  {
    this->object_orientationangle = _arg;
    return *this;
  }
  Type & set__object_length(
    const float & _arg)
  {
    this->object_length = _arg;
    return *this;
  }
  Type & set__object_width(
    const float & _arg)
  {
    this->object_width = _arg;
    return *this;
  }
  Type & set__object_colldetregionbitfield(
    const uint8_t & _arg)
  {
    this->object_colldetregionbitfield = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    sa_msgs::msg::SaRadarObjectMeta_<ContainerAllocator> *;
  using ConstRawPtr =
    const sa_msgs::msg::SaRadarObjectMeta_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<sa_msgs::msg::SaRadarObjectMeta_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<sa_msgs::msg::SaRadarObjectMeta_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      sa_msgs::msg::SaRadarObjectMeta_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<sa_msgs::msg::SaRadarObjectMeta_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      sa_msgs::msg::SaRadarObjectMeta_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<sa_msgs::msg::SaRadarObjectMeta_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<sa_msgs::msg::SaRadarObjectMeta_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<sa_msgs::msg::SaRadarObjectMeta_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__sa_msgs__msg__SaRadarObjectMeta
    std::shared_ptr<sa_msgs::msg::SaRadarObjectMeta_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__sa_msgs__msg__SaRadarObjectMeta
    std::shared_ptr<sa_msgs::msg::SaRadarObjectMeta_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const SaRadarObjectMeta_ & other) const
  {
    if (this->object_id != other.object_id) {
      return false;
    }
    if (this->object_distlong != other.object_distlong) {
      return false;
    }
    if (this->object_distlat != other.object_distlat) {
      return false;
    }
    if (this->object_vrellong != other.object_vrellong) {
      return false;
    }
    if (this->object_vrellat != other.object_vrellat) {
      return false;
    }
    if (this->object_dynprop != other.object_dynprop) {
      return false;
    }
    if (this->object_rcs != other.object_rcs) {
      return false;
    }
    if (this->object_distlong_rms != other.object_distlong_rms) {
      return false;
    }
    if (this->object_vrellong_rms != other.object_vrellong_rms) {
      return false;
    }
    if (this->object_distlat_rms != other.object_distlat_rms) {
      return false;
    }
    if (this->object_vrellat_rms != other.object_vrellat_rms) {
      return false;
    }
    if (this->object_arellat_rms != other.object_arellat_rms) {
      return false;
    }
    if (this->object_arellong_rms != other.object_arellong_rms) {
      return false;
    }
    if (this->object_orientation_rms != other.object_orientation_rms) {
      return false;
    }
    if (this->object_measstate != other.object_measstate) {
      return false;
    }
    if (this->object_probofexist != other.object_probofexist) {
      return false;
    }
    if (this->object_arellong != other.object_arellong) {
      return false;
    }
    if (this->object_class != other.object_class) {
      return false;
    }
    if (this->object_arellat != other.object_arellat) {
      return false;
    }
    if (this->object_orientationangle != other.object_orientationangle) {
      return false;
    }
    if (this->object_length != other.object_length) {
      return false;
    }
    if (this->object_width != other.object_width) {
      return false;
    }
    if (this->object_colldetregionbitfield != other.object_colldetregionbitfield) {
      return false;
    }
    return true;
  }
  bool operator!=(const SaRadarObjectMeta_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct SaRadarObjectMeta_

// alias to use template instance with default allocator
using SaRadarObjectMeta =
  sa_msgs::msg::SaRadarObjectMeta_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace sa_msgs

#endif  // SA_MSGS__MSG__DETAIL__SA_RADAR_OBJECT_META__STRUCT_HPP_
