﻿// NOLINT: This file starts with a BOM since it contain non-ASCII characters
// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from sa_msgs:msg/SaLidarCraneLocCmd.idl
// generated code does not contain a copyright notice

#ifndef SA_MSGS__MSG__DETAIL__SA_LIDAR_CRANE_LOC_CMD__STRUCT_H_
#define SA_MSGS__MSG__DETAIL__SA_LIDAR_CRANE_LOC_CMD__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__struct.h"
// Member 'command'
#include "sa_msgs/msg/detail/sa_lidar_crane_loc_cmd_status__struct.h"
// Member 'crane_id'
#include "rosidl_runtime_c/string.h"
// Member 'container_type'
#include "sa_msgs/msg/detail/sa_container_type__struct.h"

/// Struct defined in msg/SaLidarCraneLocCmd in the package sa_msgs.
/**
  * SaLidarCraneLocCmd.msg
 */
typedef struct sa_msgs__msg__SaLidarCraneLocCmd
{
  std_msgs__msg__Header header;
  /// 对位程序交互命令，ACTIVATE or STOP
  sa_msgs__msg__SaLidarCraneLocCmdStatus command;
  /// 若command==ACTIVATE，需要对下列变量赋值
  /// 待对位大机ID，用于匹配先验信息
  rosidl_runtime_c__String crane_id;
  /// 初始定位，用于给ego坐标赋初值
  double start_x;
  /// 待检测集装箱类型
  sa_msgs__msg__SaContainerType container_type;
} sa_msgs__msg__SaLidarCraneLocCmd;

// Struct for a sequence of sa_msgs__msg__SaLidarCraneLocCmd.
typedef struct sa_msgs__msg__SaLidarCraneLocCmd__Sequence
{
  sa_msgs__msg__SaLidarCraneLocCmd * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} sa_msgs__msg__SaLidarCraneLocCmd__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // SA_MSGS__MSG__DETAIL__SA_LIDAR_CRANE_LOC_CMD__STRUCT_H_
