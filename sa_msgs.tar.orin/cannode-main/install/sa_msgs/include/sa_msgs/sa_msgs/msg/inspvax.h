// generated from rosidl_generator_c/resource/idl.h.em
// with input from sa_msgs:msg/INSPVAX.idl
// generated code does not contain a copyright notice

#ifndef SA_MSGS__MSG__INSPVAX_H_
#define SA_MSGS__MSG__INSPVAX_H_

#include "sa_msgs/msg/detail/inspvax__struct.h"
#include "sa_msgs/msg/detail/inspvax__functions.h"
#include "sa_msgs/msg/detail/inspvax__type_support.h"

#endif  // SA_MSGS__MSG__INSPVAX_H_
