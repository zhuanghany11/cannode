// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from sa_msgs:msg/SaLidarGridMap.idl
// generated code does not contain a copyright notice

#ifndef SA_MSGS__MSG__DETAIL__SA_LIDAR_GRID_MAP__BUILDER_HPP_
#define SA_MSGS__MSG__DETAIL__SA_LIDAR_GRID_MAP__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "sa_msgs/msg/detail/sa_lidar_grid_map__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace sa_msgs
{

namespace msg
{

namespace builder
{

class Init_SaLidarGridMap_grid_map_layer
{
public:
  explicit Init_SaLidarGridMap_grid_map_layer(::sa_msgs::msg::SaLidarGridMap & msg)
  : msg_(msg)
  {}
  ::sa_msgs::msg::SaLidarGridMap grid_map_layer(::sa_msgs::msg::SaLidarGridMap::_grid_map_layer_type arg)
  {
    msg_.grid_map_layer = std::move(arg);
    return std::move(msg_);
  }

private:
  ::sa_msgs::msg::SaLidarGridMap msg_;
};

class Init_SaLidarGridMap_grid_map
{
public:
  explicit Init_SaLidarGridMap_grid_map(::sa_msgs::msg::SaLidarGridMap & msg)
  : msg_(msg)
  {}
  Init_SaLidarGridMap_grid_map_layer grid_map(::sa_msgs::msg::SaLidarGridMap::_grid_map_type arg)
  {
    msg_.grid_map = std::move(arg);
    return Init_SaLidarGridMap_grid_map_layer(msg_);
  }

private:
  ::sa_msgs::msg::SaLidarGridMap msg_;
};

class Init_SaLidarGridMap_width
{
public:
  explicit Init_SaLidarGridMap_width(::sa_msgs::msg::SaLidarGridMap & msg)
  : msg_(msg)
  {}
  Init_SaLidarGridMap_grid_map width(::sa_msgs::msg::SaLidarGridMap::_width_type arg)
  {
    msg_.width = std::move(arg);
    return Init_SaLidarGridMap_grid_map(msg_);
  }

private:
  ::sa_msgs::msg::SaLidarGridMap msg_;
};

class Init_SaLidarGridMap_height
{
public:
  explicit Init_SaLidarGridMap_height(::sa_msgs::msg::SaLidarGridMap & msg)
  : msg_(msg)
  {}
  Init_SaLidarGridMap_width height(::sa_msgs::msg::SaLidarGridMap::_height_type arg)
  {
    msg_.height = std::move(arg);
    return Init_SaLidarGridMap_width(msg_);
  }

private:
  ::sa_msgs::msg::SaLidarGridMap msg_;
};

class Init_SaLidarGridMap_header
{
public:
  Init_SaLidarGridMap_header()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_SaLidarGridMap_height header(::sa_msgs::msg::SaLidarGridMap::_header_type arg)
  {
    msg_.header = std::move(arg);
    return Init_SaLidarGridMap_height(msg_);
  }

private:
  ::sa_msgs::msg::SaLidarGridMap msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::sa_msgs::msg::SaLidarGridMap>()
{
  return sa_msgs::msg::builder::Init_SaLidarGridMap_header();
}

}  // namespace sa_msgs

#endif  // SA_MSGS__MSG__DETAIL__SA_LIDAR_GRID_MAP__BUILDER_HPP_
