// generated from rosidl_generator_c/resource/idl.h.em
// with input from sa_msgs:msg/HafPlanningOutV2.idl
// generated code does not contain a copyright notice

#ifndef SA_MSGS__MSG__HAF_PLANNING_OUT_V2_H_
#define SA_MSGS__MSG__HAF_PLANNING_OUT_V2_H_

#include "sa_msgs/msg/detail/haf_planning_out_v2__struct.h"
#include "sa_msgs/msg/detail/haf_planning_out_v2__functions.h"
#include "sa_msgs/msg/detail/haf_planning_out_v2__type_support.h"

#endif  // SA_MSGS__MSG__HAF_PLANNING_OUT_V2_H_
