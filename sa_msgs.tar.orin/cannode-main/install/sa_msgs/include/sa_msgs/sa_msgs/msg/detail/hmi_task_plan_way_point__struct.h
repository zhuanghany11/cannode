// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from sa_msgs:msg/HmiTaskPlanWayPoint.idl
// generated code does not contain a copyright notice

#ifndef SA_MSGS__MSG__DETAIL__HMI_TASK_PLAN_WAY_POINT__STRUCT_H_
#define SA_MSGS__MSG__DETAIL__HMI_TASK_PLAN_WAY_POINT__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'point'
#include "rosidl_runtime_c/primitives_sequence.h"
// Member 'station_name'
#include "rosidl_runtime_c/string.h"

/// Struct defined in msg/HmiTaskPlanWayPoint in the package sa_msgs.
typedef struct sa_msgs__msg__HmiTaskPlanWayPoint
{
  rosidl_runtime_c__double__Sequence point;
  int32_t type;
  rosidl_runtime_c__String station_name;
} sa_msgs__msg__HmiTaskPlanWayPoint;

// Struct for a sequence of sa_msgs__msg__HmiTaskPlanWayPoint.
typedef struct sa_msgs__msg__HmiTaskPlanWayPoint__Sequence
{
  sa_msgs__msg__HmiTaskPlanWayPoint * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} sa_msgs__msg__HmiTaskPlanWayPoint__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // SA_MSGS__MSG__DETAIL__HMI_TASK_PLAN_WAY_POINT__STRUCT_H_
