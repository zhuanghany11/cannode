// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from sa_msgs:msg/HafNavigationResultV2.idl
// generated code does not contain a copyright notice

#ifndef SA_MSGS__MSG__DETAIL__HAF_NAVIGATION_RESULT_V2__TRAITS_HPP_
#define SA_MSGS__MSG__DETAIL__HAF_NAVIGATION_RESULT_V2__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "sa_msgs/msg/detail/haf_navigation_result_v2__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__traits.hpp"
// Member 'start_point'
// Member 'end_point'
// Member 'stop_point'
#include "geometry_msgs/msg/detail/point__traits.hpp"
// Member 'way_points'
#include "sa_msgs/msg/detail/haf_way_point_v2__traits.hpp"

namespace sa_msgs
{

namespace msg
{

inline void to_flow_style_yaml(
  const HafNavigationResultV2 & msg,
  std::ostream & out)
{
  out << "{";
  // member: header
  {
    out << "header: ";
    to_flow_style_yaml(msg.header, out);
    out << ", ";
  }

  // member: task_finish_time
  {
    out << "task_finish_time: ";
    rosidl_generator_traits::value_to_yaml(msg.task_finish_time, out);
    out << ", ";
  }

  // member: start_point
  {
    out << "start_point: ";
    to_flow_style_yaml(msg.start_point, out);
    out << ", ";
  }

  // member: end_point
  {
    out << "end_point: ";
    to_flow_style_yaml(msg.end_point, out);
    out << ", ";
  }

  // member: end_point_station_name
  {
    out << "end_point_station_name: ";
    rosidl_generator_traits::value_to_yaml(msg.end_point_station_name, out);
    out << ", ";
  }

  // member: way_points
  {
    if (msg.way_points.size() == 0) {
      out << "way_points: []";
    } else {
      out << "way_points: [";
      size_t pending_items = msg.way_points.size();
      for (auto item : msg.way_points) {
        to_flow_style_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
    out << ", ";
  }

  // member: stop_point
  {
    out << "stop_point: ";
    to_flow_style_yaml(msg.stop_point, out);
    out << ", ";
  }

  // member: stop_point_heading
  {
    out << "stop_point_heading: ";
    rosidl_generator_traits::value_to_yaml(msg.stop_point_heading, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const HafNavigationResultV2 & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: header
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "header:\n";
    to_block_style_yaml(msg.header, out, indentation + 2);
  }

  // member: task_finish_time
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "task_finish_time: ";
    rosidl_generator_traits::value_to_yaml(msg.task_finish_time, out);
    out << "\n";
  }

  // member: start_point
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "start_point:\n";
    to_block_style_yaml(msg.start_point, out, indentation + 2);
  }

  // member: end_point
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "end_point:\n";
    to_block_style_yaml(msg.end_point, out, indentation + 2);
  }

  // member: end_point_station_name
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "end_point_station_name: ";
    rosidl_generator_traits::value_to_yaml(msg.end_point_station_name, out);
    out << "\n";
  }

  // member: way_points
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.way_points.size() == 0) {
      out << "way_points: []\n";
    } else {
      out << "way_points:\n";
      for (auto item : msg.way_points) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "-\n";
        to_block_style_yaml(item, out, indentation + 2);
      }
    }
  }

  // member: stop_point
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "stop_point:\n";
    to_block_style_yaml(msg.stop_point, out, indentation + 2);
  }

  // member: stop_point_heading
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "stop_point_heading: ";
    rosidl_generator_traits::value_to_yaml(msg.stop_point_heading, out);
    out << "\n";
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const HafNavigationResultV2 & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace msg

}  // namespace sa_msgs

namespace rosidl_generator_traits
{

[[deprecated("use sa_msgs::msg::to_block_style_yaml() instead")]]
inline void to_yaml(
  const sa_msgs::msg::HafNavigationResultV2 & msg,
  std::ostream & out, size_t indentation = 0)
{
  sa_msgs::msg::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use sa_msgs::msg::to_yaml() instead")]]
inline std::string to_yaml(const sa_msgs::msg::HafNavigationResultV2 & msg)
{
  return sa_msgs::msg::to_yaml(msg);
}

template<>
inline const char * data_type<sa_msgs::msg::HafNavigationResultV2>()
{
  return "sa_msgs::msg::HafNavigationResultV2";
}

template<>
inline const char * name<sa_msgs::msg::HafNavigationResultV2>()
{
  return "sa_msgs/msg/HafNavigationResultV2";
}

template<>
struct has_fixed_size<sa_msgs::msg::HafNavigationResultV2>
  : std::integral_constant<bool, false> {};

template<>
struct has_bounded_size<sa_msgs::msg::HafNavigationResultV2>
  : std::integral_constant<bool, false> {};

template<>
struct is_message<sa_msgs::msg::HafNavigationResultV2>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // SA_MSGS__MSG__DETAIL__HAF_NAVIGATION_RESULT_V2__TRAITS_HPP_
