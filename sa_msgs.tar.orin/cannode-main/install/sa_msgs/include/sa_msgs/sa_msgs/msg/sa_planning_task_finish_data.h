// generated from rosidl_generator_c/resource/idl.h.em
// with input from sa_msgs:msg/SaPlanningTaskFinishData.idl
// generated code does not contain a copyright notice

#ifndef SA_MSGS__MSG__SA_PLANNING_TASK_FINISH_DATA_H_
#define SA_MSGS__MSG__SA_PLANNING_TASK_FINISH_DATA_H_

#include "sa_msgs/msg/detail/sa_planning_task_finish_data__struct.h"
#include "sa_msgs/msg/detail/sa_planning_task_finish_data__functions.h"
#include "sa_msgs/msg/detail/sa_planning_task_finish_data__type_support.h"

#endif  // SA_MSGS__MSG__SA_PLANNING_TASK_FINISH_DATA_H_
