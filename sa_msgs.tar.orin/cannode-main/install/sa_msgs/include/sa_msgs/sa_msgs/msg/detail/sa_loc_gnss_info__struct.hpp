// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from sa_msgs:msg/SaLocGnssInfo.idl
// generated code does not contain a copyright notice

#ifndef SA_MSGS__MSG__DETAIL__SA_LOC_GNSS_INFO__STRUCT_HPP_
#define SA_MSGS__MSG__DETAIL__SA_LOC_GNSS_INFO__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__struct.hpp"
// Member 'gnss_position'
#include "geometry_msgs/msg/detail/vector3__struct.hpp"
// Member 'gnss_position_std'
// Member 'gnss_velocity'
#include "geometry_msgs/msg/detail/point32__struct.hpp"

#ifndef _WIN32
# define DEPRECATED__sa_msgs__msg__SaLocGnssInfo __attribute__((deprecated))
#else
# define DEPRECATED__sa_msgs__msg__SaLocGnssInfo __declspec(deprecated)
#endif

namespace sa_msgs
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct SaLocGnssInfo_
{
  using Type = SaLocGnssInfo_<ContainerAllocator>;

  explicit SaLocGnssInfo_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : header(_init),
    gnss_position(_init),
    gnss_position_std(_init),
    gnss_velocity(_init)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->gnss_status = 0;
      this->gps_time_status = "";
      this->gps_week_num = 0ul;
      this->gps_seconds = 0.0;
      this->year = 0;
      this->month = 0;
      this->day = 0;
      this->hour = 0;
      this->minute = 0;
      this->second = 0.0f;
      this->pos_solution_status = "";
      this->pos_type = "";
      this->pos_status = 0;
      this->gnss_utm_east = 0.0;
      this->gnss_utm_north = 0.0;
      this->undulation = 0.0f;
      this->datum_id = "";
      this->vel_solution_status = "";
      this->vel_type = "";
      this->vel_status = 0;
      this->latency = 0.0f;
      this->horizontal_speed = 0.0f;
      this->track_ground = 0.0f;
      this->yaw_solution_status = "";
      this->yaw_type = "";
      this->yaw_status = 0;
      this->baseline_length = 0.0f;
      this->sats_used = 0;
      this->sats_tracked = 0;
      this->sats_used_l1 = 0;
      this->sats_used_multi = 0;
      this->hdop = 0.0f;
      this->vdop = 0.0f;
      this->pdop = 0.0f;
      this->tdop = 0.0f;
      this->gdop = 0.0f;
      this->diff_age = 0.0f;
    }
  }

  explicit SaLocGnssInfo_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : header(_alloc, _init),
    gnss_position(_alloc, _init),
    gnss_position_std(_alloc, _init),
    gnss_velocity(_alloc, _init),
    gps_time_status(_alloc),
    pos_solution_status(_alloc),
    pos_type(_alloc),
    datum_id(_alloc),
    vel_solution_status(_alloc),
    vel_type(_alloc),
    yaw_solution_status(_alloc),
    yaw_type(_alloc)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->gnss_status = 0;
      this->gps_time_status = "";
      this->gps_week_num = 0ul;
      this->gps_seconds = 0.0;
      this->year = 0;
      this->month = 0;
      this->day = 0;
      this->hour = 0;
      this->minute = 0;
      this->second = 0.0f;
      this->pos_solution_status = "";
      this->pos_type = "";
      this->pos_status = 0;
      this->gnss_utm_east = 0.0;
      this->gnss_utm_north = 0.0;
      this->undulation = 0.0f;
      this->datum_id = "";
      this->vel_solution_status = "";
      this->vel_type = "";
      this->vel_status = 0;
      this->latency = 0.0f;
      this->horizontal_speed = 0.0f;
      this->track_ground = 0.0f;
      this->yaw_solution_status = "";
      this->yaw_type = "";
      this->yaw_status = 0;
      this->baseline_length = 0.0f;
      this->sats_used = 0;
      this->sats_tracked = 0;
      this->sats_used_l1 = 0;
      this->sats_used_multi = 0;
      this->hdop = 0.0f;
      this->vdop = 0.0f;
      this->pdop = 0.0f;
      this->tdop = 0.0f;
      this->gdop = 0.0f;
      this->diff_age = 0.0f;
    }
  }

  // field types and members
  using _header_type =
    std_msgs::msg::Header_<ContainerAllocator>;
  _header_type header;
  using _gnss_position_type =
    geometry_msgs::msg::Vector3_<ContainerAllocator>;
  _gnss_position_type gnss_position;
  using _gnss_position_std_type =
    geometry_msgs::msg::Point32_<ContainerAllocator>;
  _gnss_position_std_type gnss_position_std;
  using _gnss_velocity_type =
    geometry_msgs::msg::Point32_<ContainerAllocator>;
  _gnss_velocity_type gnss_velocity;
  using _gnss_status_type =
    uint8_t;
  _gnss_status_type gnss_status;
  using _gps_time_status_type =
    std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>;
  _gps_time_status_type gps_time_status;
  using _gps_week_num_type =
    uint32_t;
  _gps_week_num_type gps_week_num;
  using _gps_seconds_type =
    double;
  _gps_seconds_type gps_seconds;
  using _year_type =
    uint16_t;
  _year_type year;
  using _month_type =
    uint8_t;
  _month_type month;
  using _day_type =
    uint8_t;
  _day_type day;
  using _hour_type =
    uint8_t;
  _hour_type hour;
  using _minute_type =
    uint8_t;
  _minute_type minute;
  using _second_type =
    float;
  _second_type second;
  using _pos_solution_status_type =
    std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>;
  _pos_solution_status_type pos_solution_status;
  using _pos_type_type =
    std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>;
  _pos_type_type pos_type;
  using _pos_status_type =
    uint8_t;
  _pos_status_type pos_status;
  using _gnss_utm_east_type =
    double;
  _gnss_utm_east_type gnss_utm_east;
  using _gnss_utm_north_type =
    double;
  _gnss_utm_north_type gnss_utm_north;
  using _undulation_type =
    float;
  _undulation_type undulation;
  using _datum_id_type =
    std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>;
  _datum_id_type datum_id;
  using _vel_solution_status_type =
    std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>;
  _vel_solution_status_type vel_solution_status;
  using _vel_type_type =
    std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>;
  _vel_type_type vel_type;
  using _vel_status_type =
    uint8_t;
  _vel_status_type vel_status;
  using _latency_type =
    float;
  _latency_type latency;
  using _horizontal_speed_type =
    float;
  _horizontal_speed_type horizontal_speed;
  using _track_ground_type =
    float;
  _track_ground_type track_ground;
  using _yaw_solution_status_type =
    std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>;
  _yaw_solution_status_type yaw_solution_status;
  using _yaw_type_type =
    std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>;
  _yaw_type_type yaw_type;
  using _yaw_status_type =
    uint8_t;
  _yaw_status_type yaw_status;
  using _baseline_length_type =
    float;
  _baseline_length_type baseline_length;
  using _sats_used_type =
    uint8_t;
  _sats_used_type sats_used;
  using _sats_tracked_type =
    uint8_t;
  _sats_tracked_type sats_tracked;
  using _sats_used_l1_type =
    uint8_t;
  _sats_used_l1_type sats_used_l1;
  using _sats_used_multi_type =
    uint8_t;
  _sats_used_multi_type sats_used_multi;
  using _hdop_type =
    float;
  _hdop_type hdop;
  using _vdop_type =
    float;
  _vdop_type vdop;
  using _pdop_type =
    float;
  _pdop_type pdop;
  using _tdop_type =
    float;
  _tdop_type tdop;
  using _gdop_type =
    float;
  _gdop_type gdop;
  using _diff_age_type =
    float;
  _diff_age_type diff_age;

  // setters for named parameter idiom
  Type & set__header(
    const std_msgs::msg::Header_<ContainerAllocator> & _arg)
  {
    this->header = _arg;
    return *this;
  }
  Type & set__gnss_position(
    const geometry_msgs::msg::Vector3_<ContainerAllocator> & _arg)
  {
    this->gnss_position = _arg;
    return *this;
  }
  Type & set__gnss_position_std(
    const geometry_msgs::msg::Point32_<ContainerAllocator> & _arg)
  {
    this->gnss_position_std = _arg;
    return *this;
  }
  Type & set__gnss_velocity(
    const geometry_msgs::msg::Point32_<ContainerAllocator> & _arg)
  {
    this->gnss_velocity = _arg;
    return *this;
  }
  Type & set__gnss_status(
    const uint8_t & _arg)
  {
    this->gnss_status = _arg;
    return *this;
  }
  Type & set__gps_time_status(
    const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> & _arg)
  {
    this->gps_time_status = _arg;
    return *this;
  }
  Type & set__gps_week_num(
    const uint32_t & _arg)
  {
    this->gps_week_num = _arg;
    return *this;
  }
  Type & set__gps_seconds(
    const double & _arg)
  {
    this->gps_seconds = _arg;
    return *this;
  }
  Type & set__year(
    const uint16_t & _arg)
  {
    this->year = _arg;
    return *this;
  }
  Type & set__month(
    const uint8_t & _arg)
  {
    this->month = _arg;
    return *this;
  }
  Type & set__day(
    const uint8_t & _arg)
  {
    this->day = _arg;
    return *this;
  }
  Type & set__hour(
    const uint8_t & _arg)
  {
    this->hour = _arg;
    return *this;
  }
  Type & set__minute(
    const uint8_t & _arg)
  {
    this->minute = _arg;
    return *this;
  }
  Type & set__second(
    const float & _arg)
  {
    this->second = _arg;
    return *this;
  }
  Type & set__pos_solution_status(
    const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> & _arg)
  {
    this->pos_solution_status = _arg;
    return *this;
  }
  Type & set__pos_type(
    const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> & _arg)
  {
    this->pos_type = _arg;
    return *this;
  }
  Type & set__pos_status(
    const uint8_t & _arg)
  {
    this->pos_status = _arg;
    return *this;
  }
  Type & set__gnss_utm_east(
    const double & _arg)
  {
    this->gnss_utm_east = _arg;
    return *this;
  }
  Type & set__gnss_utm_north(
    const double & _arg)
  {
    this->gnss_utm_north = _arg;
    return *this;
  }
  Type & set__undulation(
    const float & _arg)
  {
    this->undulation = _arg;
    return *this;
  }
  Type & set__datum_id(
    const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> & _arg)
  {
    this->datum_id = _arg;
    return *this;
  }
  Type & set__vel_solution_status(
    const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> & _arg)
  {
    this->vel_solution_status = _arg;
    return *this;
  }
  Type & set__vel_type(
    const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> & _arg)
  {
    this->vel_type = _arg;
    return *this;
  }
  Type & set__vel_status(
    const uint8_t & _arg)
  {
    this->vel_status = _arg;
    return *this;
  }
  Type & set__latency(
    const float & _arg)
  {
    this->latency = _arg;
    return *this;
  }
  Type & set__horizontal_speed(
    const float & _arg)
  {
    this->horizontal_speed = _arg;
    return *this;
  }
  Type & set__track_ground(
    const float & _arg)
  {
    this->track_ground = _arg;
    return *this;
  }
  Type & set__yaw_solution_status(
    const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> & _arg)
  {
    this->yaw_solution_status = _arg;
    return *this;
  }
  Type & set__yaw_type(
    const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> & _arg)
  {
    this->yaw_type = _arg;
    return *this;
  }
  Type & set__yaw_status(
    const uint8_t & _arg)
  {
    this->yaw_status = _arg;
    return *this;
  }
  Type & set__baseline_length(
    const float & _arg)
  {
    this->baseline_length = _arg;
    return *this;
  }
  Type & set__sats_used(
    const uint8_t & _arg)
  {
    this->sats_used = _arg;
    return *this;
  }
  Type & set__sats_tracked(
    const uint8_t & _arg)
  {
    this->sats_tracked = _arg;
    return *this;
  }
  Type & set__sats_used_l1(
    const uint8_t & _arg)
  {
    this->sats_used_l1 = _arg;
    return *this;
  }
  Type & set__sats_used_multi(
    const uint8_t & _arg)
  {
    this->sats_used_multi = _arg;
    return *this;
  }
  Type & set__hdop(
    const float & _arg)
  {
    this->hdop = _arg;
    return *this;
  }
  Type & set__vdop(
    const float & _arg)
  {
    this->vdop = _arg;
    return *this;
  }
  Type & set__pdop(
    const float & _arg)
  {
    this->pdop = _arg;
    return *this;
  }
  Type & set__tdop(
    const float & _arg)
  {
    this->tdop = _arg;
    return *this;
  }
  Type & set__gdop(
    const float & _arg)
  {
    this->gdop = _arg;
    return *this;
  }
  Type & set__diff_age(
    const float & _arg)
  {
    this->diff_age = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    sa_msgs::msg::SaLocGnssInfo_<ContainerAllocator> *;
  using ConstRawPtr =
    const sa_msgs::msg::SaLocGnssInfo_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<sa_msgs::msg::SaLocGnssInfo_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<sa_msgs::msg::SaLocGnssInfo_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      sa_msgs::msg::SaLocGnssInfo_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<sa_msgs::msg::SaLocGnssInfo_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      sa_msgs::msg::SaLocGnssInfo_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<sa_msgs::msg::SaLocGnssInfo_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<sa_msgs::msg::SaLocGnssInfo_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<sa_msgs::msg::SaLocGnssInfo_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__sa_msgs__msg__SaLocGnssInfo
    std::shared_ptr<sa_msgs::msg::SaLocGnssInfo_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__sa_msgs__msg__SaLocGnssInfo
    std::shared_ptr<sa_msgs::msg::SaLocGnssInfo_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const SaLocGnssInfo_ & other) const
  {
    if (this->header != other.header) {
      return false;
    }
    if (this->gnss_position != other.gnss_position) {
      return false;
    }
    if (this->gnss_position_std != other.gnss_position_std) {
      return false;
    }
    if (this->gnss_velocity != other.gnss_velocity) {
      return false;
    }
    if (this->gnss_status != other.gnss_status) {
      return false;
    }
    if (this->gps_time_status != other.gps_time_status) {
      return false;
    }
    if (this->gps_week_num != other.gps_week_num) {
      return false;
    }
    if (this->gps_seconds != other.gps_seconds) {
      return false;
    }
    if (this->year != other.year) {
      return false;
    }
    if (this->month != other.month) {
      return false;
    }
    if (this->day != other.day) {
      return false;
    }
    if (this->hour != other.hour) {
      return false;
    }
    if (this->minute != other.minute) {
      return false;
    }
    if (this->second != other.second) {
      return false;
    }
    if (this->pos_solution_status != other.pos_solution_status) {
      return false;
    }
    if (this->pos_type != other.pos_type) {
      return false;
    }
    if (this->pos_status != other.pos_status) {
      return false;
    }
    if (this->gnss_utm_east != other.gnss_utm_east) {
      return false;
    }
    if (this->gnss_utm_north != other.gnss_utm_north) {
      return false;
    }
    if (this->undulation != other.undulation) {
      return false;
    }
    if (this->datum_id != other.datum_id) {
      return false;
    }
    if (this->vel_solution_status != other.vel_solution_status) {
      return false;
    }
    if (this->vel_type != other.vel_type) {
      return false;
    }
    if (this->vel_status != other.vel_status) {
      return false;
    }
    if (this->latency != other.latency) {
      return false;
    }
    if (this->horizontal_speed != other.horizontal_speed) {
      return false;
    }
    if (this->track_ground != other.track_ground) {
      return false;
    }
    if (this->yaw_solution_status != other.yaw_solution_status) {
      return false;
    }
    if (this->yaw_type != other.yaw_type) {
      return false;
    }
    if (this->yaw_status != other.yaw_status) {
      return false;
    }
    if (this->baseline_length != other.baseline_length) {
      return false;
    }
    if (this->sats_used != other.sats_used) {
      return false;
    }
    if (this->sats_tracked != other.sats_tracked) {
      return false;
    }
    if (this->sats_used_l1 != other.sats_used_l1) {
      return false;
    }
    if (this->sats_used_multi != other.sats_used_multi) {
      return false;
    }
    if (this->hdop != other.hdop) {
      return false;
    }
    if (this->vdop != other.vdop) {
      return false;
    }
    if (this->pdop != other.pdop) {
      return false;
    }
    if (this->tdop != other.tdop) {
      return false;
    }
    if (this->gdop != other.gdop) {
      return false;
    }
    if (this->diff_age != other.diff_age) {
      return false;
    }
    return true;
  }
  bool operator!=(const SaLocGnssInfo_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct SaLocGnssInfo_

// alias to use template instance with default allocator
using SaLocGnssInfo =
  sa_msgs::msg::SaLocGnssInfo_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace sa_msgs

#endif  // SA_MSGS__MSG__DETAIL__SA_LOC_GNSS_INFO__STRUCT_HPP_
