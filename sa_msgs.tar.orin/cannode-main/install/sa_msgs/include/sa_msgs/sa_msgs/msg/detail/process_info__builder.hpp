// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from sa_msgs:msg/ProcessInfo.idl
// generated code does not contain a copyright notice

#ifndef SA_MSGS__MSG__DETAIL__PROCESS_INFO__BUILDER_HPP_
#define SA_MSGS__MSG__DETAIL__PROCESS_INFO__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "sa_msgs/msg/detail/process_info__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace sa_msgs
{

namespace msg
{

namespace builder
{

class Init_ProcessInfo_cpu_usage
{
public:
  explicit Init_ProcessInfo_cpu_usage(::sa_msgs::msg::ProcessInfo & msg)
  : msg_(msg)
  {}
  ::sa_msgs::msg::ProcessInfo cpu_usage(::sa_msgs::msg::ProcessInfo::_cpu_usage_type arg)
  {
    msg_.cpu_usage = std::move(arg);
    return std::move(msg_);
  }

private:
  ::sa_msgs::msg::ProcessInfo msg_;
};

class Init_ProcessInfo_memory_usage
{
public:
  explicit Init_ProcessInfo_memory_usage(::sa_msgs::msg::ProcessInfo & msg)
  : msg_(msg)
  {}
  Init_ProcessInfo_cpu_usage memory_usage(::sa_msgs::msg::ProcessInfo::_memory_usage_type arg)
  {
    msg_.memory_usage = std::move(arg);
    return Init_ProcessInfo_cpu_usage(msg_);
  }

private:
  ::sa_msgs::msg::ProcessInfo msg_;
};

class Init_ProcessInfo_name
{
public:
  explicit Init_ProcessInfo_name(::sa_msgs::msg::ProcessInfo & msg)
  : msg_(msg)
  {}
  Init_ProcessInfo_memory_usage name(::sa_msgs::msg::ProcessInfo::_name_type arg)
  {
    msg_.name = std::move(arg);
    return Init_ProcessInfo_memory_usage(msg_);
  }

private:
  ::sa_msgs::msg::ProcessInfo msg_;
};

class Init_ProcessInfo_pid
{
public:
  Init_ProcessInfo_pid()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_ProcessInfo_name pid(::sa_msgs::msg::ProcessInfo::_pid_type arg)
  {
    msg_.pid = std::move(arg);
    return Init_ProcessInfo_name(msg_);
  }

private:
  ::sa_msgs::msg::ProcessInfo msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::sa_msgs::msg::ProcessInfo>()
{
  return sa_msgs::msg::builder::Init_ProcessInfo_pid();
}

}  // namespace sa_msgs

#endif  // SA_MSGS__MSG__DETAIL__PROCESS_INFO__BUILDER_HPP_
