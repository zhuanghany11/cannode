// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from sa_msgs:msg/SaRadarClusterMeta.idl
// generated code does not contain a copyright notice

#ifndef SA_MSGS__MSG__DETAIL__SA_RADAR_CLUSTER_META__BUILDER_HPP_
#define SA_MSGS__MSG__DETAIL__SA_RADAR_CLUSTER_META__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "sa_msgs/msg/detail/sa_radar_cluster_meta__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace sa_msgs
{

namespace msg
{

namespace builder
{

class Init_SaRadarClusterMeta_cluster_invalidstate
{
public:
  explicit Init_SaRadarClusterMeta_cluster_invalidstate(::sa_msgs::msg::SaRadarClusterMeta & msg)
  : msg_(msg)
  {}
  ::sa_msgs::msg::SaRadarClusterMeta cluster_invalidstate(::sa_msgs::msg::SaRadarClusterMeta::_cluster_invalidstate_type arg)
  {
    msg_.cluster_invalidstate = std::move(arg);
    return std::move(msg_);
  }

private:
  ::sa_msgs::msg::SaRadarClusterMeta msg_;
};

class Init_SaRadarClusterMeta_cluster_ambigstate
{
public:
  explicit Init_SaRadarClusterMeta_cluster_ambigstate(::sa_msgs::msg::SaRadarClusterMeta & msg)
  : msg_(msg)
  {}
  Init_SaRadarClusterMeta_cluster_invalidstate cluster_ambigstate(::sa_msgs::msg::SaRadarClusterMeta::_cluster_ambigstate_type arg)
  {
    msg_.cluster_ambigstate = std::move(arg);
    return Init_SaRadarClusterMeta_cluster_invalidstate(msg_);
  }

private:
  ::sa_msgs::msg::SaRadarClusterMeta msg_;
};

class Init_SaRadarClusterMeta_cluster_vrellat_rms
{
public:
  explicit Init_SaRadarClusterMeta_cluster_vrellat_rms(::sa_msgs::msg::SaRadarClusterMeta & msg)
  : msg_(msg)
  {}
  Init_SaRadarClusterMeta_cluster_ambigstate cluster_vrellat_rms(::sa_msgs::msg::SaRadarClusterMeta::_cluster_vrellat_rms_type arg)
  {
    msg_.cluster_vrellat_rms = std::move(arg);
    return Init_SaRadarClusterMeta_cluster_ambigstate(msg_);
  }

private:
  ::sa_msgs::msg::SaRadarClusterMeta msg_;
};

class Init_SaRadarClusterMeta_cluster_pdh0
{
public:
  explicit Init_SaRadarClusterMeta_cluster_pdh0(::sa_msgs::msg::SaRadarClusterMeta & msg)
  : msg_(msg)
  {}
  Init_SaRadarClusterMeta_cluster_vrellat_rms cluster_pdh0(::sa_msgs::msg::SaRadarClusterMeta::_cluster_pdh0_type arg)
  {
    msg_.cluster_pdh0 = std::move(arg);
    return Init_SaRadarClusterMeta_cluster_vrellat_rms(msg_);
  }

private:
  ::sa_msgs::msg::SaRadarClusterMeta msg_;
};

class Init_SaRadarClusterMeta_cluster_distlat_rms
{
public:
  explicit Init_SaRadarClusterMeta_cluster_distlat_rms(::sa_msgs::msg::SaRadarClusterMeta & msg)
  : msg_(msg)
  {}
  Init_SaRadarClusterMeta_cluster_pdh0 cluster_distlat_rms(::sa_msgs::msg::SaRadarClusterMeta::_cluster_distlat_rms_type arg)
  {
    msg_.cluster_distlat_rms = std::move(arg);
    return Init_SaRadarClusterMeta_cluster_pdh0(msg_);
  }

private:
  ::sa_msgs::msg::SaRadarClusterMeta msg_;
};

class Init_SaRadarClusterMeta_cluster_vrellong_rms
{
public:
  explicit Init_SaRadarClusterMeta_cluster_vrellong_rms(::sa_msgs::msg::SaRadarClusterMeta & msg)
  : msg_(msg)
  {}
  Init_SaRadarClusterMeta_cluster_distlat_rms cluster_vrellong_rms(::sa_msgs::msg::SaRadarClusterMeta::_cluster_vrellong_rms_type arg)
  {
    msg_.cluster_vrellong_rms = std::move(arg);
    return Init_SaRadarClusterMeta_cluster_distlat_rms(msg_);
  }

private:
  ::sa_msgs::msg::SaRadarClusterMeta msg_;
};

class Init_SaRadarClusterMeta_cluster_distlong_rms
{
public:
  explicit Init_SaRadarClusterMeta_cluster_distlong_rms(::sa_msgs::msg::SaRadarClusterMeta & msg)
  : msg_(msg)
  {}
  Init_SaRadarClusterMeta_cluster_vrellong_rms cluster_distlong_rms(::sa_msgs::msg::SaRadarClusterMeta::_cluster_distlong_rms_type arg)
  {
    msg_.cluster_distlong_rms = std::move(arg);
    return Init_SaRadarClusterMeta_cluster_vrellong_rms(msg_);
  }

private:
  ::sa_msgs::msg::SaRadarClusterMeta msg_;
};

class Init_SaRadarClusterMeta_cluster_rcs
{
public:
  explicit Init_SaRadarClusterMeta_cluster_rcs(::sa_msgs::msg::SaRadarClusterMeta & msg)
  : msg_(msg)
  {}
  Init_SaRadarClusterMeta_cluster_distlong_rms cluster_rcs(::sa_msgs::msg::SaRadarClusterMeta::_cluster_rcs_type arg)
  {
    msg_.cluster_rcs = std::move(arg);
    return Init_SaRadarClusterMeta_cluster_distlong_rms(msg_);
  }

private:
  ::sa_msgs::msg::SaRadarClusterMeta msg_;
};

class Init_SaRadarClusterMeta_cluster_vrellat
{
public:
  explicit Init_SaRadarClusterMeta_cluster_vrellat(::sa_msgs::msg::SaRadarClusterMeta & msg)
  : msg_(msg)
  {}
  Init_SaRadarClusterMeta_cluster_rcs cluster_vrellat(::sa_msgs::msg::SaRadarClusterMeta::_cluster_vrellat_type arg)
  {
    msg_.cluster_vrellat = std::move(arg);
    return Init_SaRadarClusterMeta_cluster_rcs(msg_);
  }

private:
  ::sa_msgs::msg::SaRadarClusterMeta msg_;
};

class Init_SaRadarClusterMeta_cluster_dynprop
{
public:
  explicit Init_SaRadarClusterMeta_cluster_dynprop(::sa_msgs::msg::SaRadarClusterMeta & msg)
  : msg_(msg)
  {}
  Init_SaRadarClusterMeta_cluster_vrellat cluster_dynprop(::sa_msgs::msg::SaRadarClusterMeta::_cluster_dynprop_type arg)
  {
    msg_.cluster_dynprop = std::move(arg);
    return Init_SaRadarClusterMeta_cluster_vrellat(msg_);
  }

private:
  ::sa_msgs::msg::SaRadarClusterMeta msg_;
};

class Init_SaRadarClusterMeta_cluster_vrellong
{
public:
  explicit Init_SaRadarClusterMeta_cluster_vrellong(::sa_msgs::msg::SaRadarClusterMeta & msg)
  : msg_(msg)
  {}
  Init_SaRadarClusterMeta_cluster_dynprop cluster_vrellong(::sa_msgs::msg::SaRadarClusterMeta::_cluster_vrellong_type arg)
  {
    msg_.cluster_vrellong = std::move(arg);
    return Init_SaRadarClusterMeta_cluster_dynprop(msg_);
  }

private:
  ::sa_msgs::msg::SaRadarClusterMeta msg_;
};

class Init_SaRadarClusterMeta_cluster_distlat
{
public:
  explicit Init_SaRadarClusterMeta_cluster_distlat(::sa_msgs::msg::SaRadarClusterMeta & msg)
  : msg_(msg)
  {}
  Init_SaRadarClusterMeta_cluster_vrellong cluster_distlat(::sa_msgs::msg::SaRadarClusterMeta::_cluster_distlat_type arg)
  {
    msg_.cluster_distlat = std::move(arg);
    return Init_SaRadarClusterMeta_cluster_vrellong(msg_);
  }

private:
  ::sa_msgs::msg::SaRadarClusterMeta msg_;
};

class Init_SaRadarClusterMeta_cluster_distlong
{
public:
  explicit Init_SaRadarClusterMeta_cluster_distlong(::sa_msgs::msg::SaRadarClusterMeta & msg)
  : msg_(msg)
  {}
  Init_SaRadarClusterMeta_cluster_distlat cluster_distlong(::sa_msgs::msg::SaRadarClusterMeta::_cluster_distlong_type arg)
  {
    msg_.cluster_distlong = std::move(arg);
    return Init_SaRadarClusterMeta_cluster_distlat(msg_);
  }

private:
  ::sa_msgs::msg::SaRadarClusterMeta msg_;
};

class Init_SaRadarClusterMeta_cluster_id
{
public:
  Init_SaRadarClusterMeta_cluster_id()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_SaRadarClusterMeta_cluster_distlong cluster_id(::sa_msgs::msg::SaRadarClusterMeta::_cluster_id_type arg)
  {
    msg_.cluster_id = std::move(arg);
    return Init_SaRadarClusterMeta_cluster_distlong(msg_);
  }

private:
  ::sa_msgs::msg::SaRadarClusterMeta msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::sa_msgs::msg::SaRadarClusterMeta>()
{
  return sa_msgs::msg::builder::Init_SaRadarClusterMeta_cluster_id();
}

}  // namespace sa_msgs

#endif  // SA_MSGS__MSG__DETAIL__SA_RADAR_CLUSTER_META__BUILDER_HPP_
