﻿// NOLINT: This file starts with a BOM since it contain non-ASCII characters
// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from sa_msgs:msg/SaPlanningRefPoint.idl
// generated code does not contain a copyright notice

#ifndef SA_MSGS__MSG__DETAIL__SA_PLANNING_REF_POINT__STRUCT_H_
#define SA_MSGS__MSG__DETAIL__SA_PLANNING_REF_POINT__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

/// Struct defined in msg/SaPlanningRefPoint in the package sa_msgs.
typedef struct sa_msgs__msg__SaPlanningRefPoint
{
  /// utm x坐标
  double x;
  /// utm y坐标
  double y;
  /// 朝向
  double theta;
  /// 曲率
  double kappa;
  /// 累计距离
  double s;
} sa_msgs__msg__SaPlanningRefPoint;

// Struct for a sequence of sa_msgs__msg__SaPlanningRefPoint.
typedef struct sa_msgs__msg__SaPlanningRefPoint__Sequence
{
  sa_msgs__msg__SaPlanningRefPoint * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} sa_msgs__msg__SaPlanningRefPoint__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // SA_MSGS__MSG__DETAIL__SA_PLANNING_REF_POINT__STRUCT_H_
