// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef SA_MSGS__MSG__SA_LOC_GINS_INFO_HPP_
#define SA_MSGS__MSG__SA_LOC_GINS_INFO_HPP_

#include "sa_msgs/msg/detail/sa_loc_gins_info__struct.hpp"
#include "sa_msgs/msg/detail/sa_loc_gins_info__builder.hpp"
#include "sa_msgs/msg/detail/sa_loc_gins_info__traits.hpp"
#include "sa_msgs/msg/detail/sa_loc_gins_info__type_support.hpp"

#endif  // SA_MSGS__MSG__SA_LOC_GINS_INFO_HPP_
