// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef SA_MSGS__MSG__DATA_SNAPSHOTS_HPP_
#define SA_MSGS__MSG__DATA_SNAPSHOTS_HPP_

#include "sa_msgs/msg/detail/data_snapshots__struct.hpp"
#include "sa_msgs/msg/detail/data_snapshots__builder.hpp"
#include "sa_msgs/msg/detail/data_snapshots__traits.hpp"
#include "sa_msgs/msg/detail/data_snapshots__type_support.hpp"

#endif  // SA_MSGS__MSG__DATA_SNAPSHOTS_HPP_
