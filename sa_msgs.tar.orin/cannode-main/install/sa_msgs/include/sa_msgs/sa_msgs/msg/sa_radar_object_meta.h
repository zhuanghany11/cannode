// generated from rosidl_generator_c/resource/idl.h.em
// with input from sa_msgs:msg/SaRadarObjectMeta.idl
// generated code does not contain a copyright notice

#ifndef SA_MSGS__MSG__SA_RADAR_OBJECT_META_H_
#define SA_MSGS__MSG__SA_RADAR_OBJECT_META_H_

#include "sa_msgs/msg/detail/sa_radar_object_meta__struct.h"
#include "sa_msgs/msg/detail/sa_radar_object_meta__functions.h"
#include "sa_msgs/msg/detail/sa_radar_object_meta__type_support.h"

#endif  // SA_MSGS__MSG__SA_RADAR_OBJECT_META_H_
