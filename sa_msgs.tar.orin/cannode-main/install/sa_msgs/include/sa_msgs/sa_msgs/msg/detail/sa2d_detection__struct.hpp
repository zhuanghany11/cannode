// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from sa_msgs:msg/Sa2dDetection.idl
// generated code does not contain a copyright notice

#ifndef SA_MSGS__MSG__DETAIL__SA2D_DETECTION__STRUCT_HPP_
#define SA_MSGS__MSG__DETAIL__SA2D_DETECTION__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


// Include directives for member types
// Member 'center'
// Member 'size'
#include "geometry_msgs/msg/detail/point__struct.hpp"

#ifndef _WIN32
# define DEPRECATED__sa_msgs__msg__Sa2dDetection __attribute__((deprecated))
#else
# define DEPRECATED__sa_msgs__msg__Sa2dDetection __declspec(deprecated)
#endif

namespace sa_msgs
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct Sa2dDetection_
{
  using Type = Sa2dDetection_<ContainerAllocator>;

  explicit Sa2dDetection_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : center(_init),
    size(_init)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->object_id = 0l;
      this->cls = 0l;
      this->direction = 0l;
      this->remainning_time = 0;
      this->confidence = 0.0f;
    }
  }

  explicit Sa2dDetection_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : center(_alloc, _init),
    size(_alloc, _init)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->object_id = 0l;
      this->cls = 0l;
      this->direction = 0l;
      this->remainning_time = 0;
      this->confidence = 0.0f;
    }
  }

  // field types and members
  using _object_id_type =
    int32_t;
  _object_id_type object_id;
  using _cls_type =
    int32_t;
  _cls_type cls;
  using _direction_type =
    int32_t;
  _direction_type direction;
  using _remainning_time_type =
    int8_t;
  _remainning_time_type remainning_time;
  using _center_type =
    geometry_msgs::msg::Point_<ContainerAllocator>;
  _center_type center;
  using _size_type =
    geometry_msgs::msg::Point_<ContainerAllocator>;
  _size_type size;
  using _confidence_type =
    float;
  _confidence_type confidence;

  // setters for named parameter idiom
  Type & set__object_id(
    const int32_t & _arg)
  {
    this->object_id = _arg;
    return *this;
  }
  Type & set__cls(
    const int32_t & _arg)
  {
    this->cls = _arg;
    return *this;
  }
  Type & set__direction(
    const int32_t & _arg)
  {
    this->direction = _arg;
    return *this;
  }
  Type & set__remainning_time(
    const int8_t & _arg)
  {
    this->remainning_time = _arg;
    return *this;
  }
  Type & set__center(
    const geometry_msgs::msg::Point_<ContainerAllocator> & _arg)
  {
    this->center = _arg;
    return *this;
  }
  Type & set__size(
    const geometry_msgs::msg::Point_<ContainerAllocator> & _arg)
  {
    this->size = _arg;
    return *this;
  }
  Type & set__confidence(
    const float & _arg)
  {
    this->confidence = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    sa_msgs::msg::Sa2dDetection_<ContainerAllocator> *;
  using ConstRawPtr =
    const sa_msgs::msg::Sa2dDetection_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<sa_msgs::msg::Sa2dDetection_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<sa_msgs::msg::Sa2dDetection_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      sa_msgs::msg::Sa2dDetection_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<sa_msgs::msg::Sa2dDetection_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      sa_msgs::msg::Sa2dDetection_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<sa_msgs::msg::Sa2dDetection_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<sa_msgs::msg::Sa2dDetection_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<sa_msgs::msg::Sa2dDetection_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__sa_msgs__msg__Sa2dDetection
    std::shared_ptr<sa_msgs::msg::Sa2dDetection_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__sa_msgs__msg__Sa2dDetection
    std::shared_ptr<sa_msgs::msg::Sa2dDetection_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const Sa2dDetection_ & other) const
  {
    if (this->object_id != other.object_id) {
      return false;
    }
    if (this->cls != other.cls) {
      return false;
    }
    if (this->direction != other.direction) {
      return false;
    }
    if (this->remainning_time != other.remainning_time) {
      return false;
    }
    if (this->center != other.center) {
      return false;
    }
    if (this->size != other.size) {
      return false;
    }
    if (this->confidence != other.confidence) {
      return false;
    }
    return true;
  }
  bool operator!=(const Sa2dDetection_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct Sa2dDetection_

// alias to use template instance with default allocator
using Sa2dDetection =
  sa_msgs::msg::Sa2dDetection_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace sa_msgs

#endif  // SA_MSGS__MSG__DETAIL__SA2D_DETECTION__STRUCT_HPP_
