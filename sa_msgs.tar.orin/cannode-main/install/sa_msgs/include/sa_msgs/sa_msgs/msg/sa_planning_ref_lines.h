// generated from rosidl_generator_c/resource/idl.h.em
// with input from sa_msgs:msg/SaPlanningRefLines.idl
// generated code does not contain a copyright notice

#ifndef SA_MSGS__MSG__SA_PLANNING_REF_LINES_H_
#define SA_MSGS__MSG__SA_PLANNING_REF_LINES_H_

#include "sa_msgs/msg/detail/sa_planning_ref_lines__struct.h"
#include "sa_msgs/msg/detail/sa_planning_ref_lines__functions.h"
#include "sa_msgs/msg/detail/sa_planning_ref_lines__type_support.h"

#endif  // SA_MSGS__MSG__SA_PLANNING_REF_LINES_H_
