// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from sa_msgs:msg/SaPlanningRefLine.idl
// generated code does not contain a copyright notice

#ifndef SA_MSGS__MSG__DETAIL__SA_PLANNING_REF_LINE__BUILDER_HPP_
#define SA_MSGS__MSG__DETAIL__SA_PLANNING_REF_LINE__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "sa_msgs/msg/detail/sa_planning_ref_line__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace sa_msgs
{

namespace msg
{

namespace builder
{

class Init_SaPlanningRefLine_ref_points
{
public:
  explicit Init_SaPlanningRefLine_ref_points(::sa_msgs::msg::SaPlanningRefLine & msg)
  : msg_(msg)
  {}
  ::sa_msgs::msg::SaPlanningRefLine ref_points(::sa_msgs::msg::SaPlanningRefLine::_ref_points_type arg)
  {
    msg_.ref_points = std::move(arg);
    return std::move(msg_);
  }

private:
  ::sa_msgs::msg::SaPlanningRefLine msg_;
};

class Init_SaPlanningRefLine_length
{
public:
  explicit Init_SaPlanningRefLine_length(::sa_msgs::msg::SaPlanningRefLine & msg)
  : msg_(msg)
  {}
  Init_SaPlanningRefLine_ref_points length(::sa_msgs::msg::SaPlanningRefLine::_length_type arg)
  {
    msg_.length = std::move(arg);
    return Init_SaPlanningRefLine_ref_points(msg_);
  }

private:
  ::sa_msgs::msg::SaPlanningRefLine msg_;
};

class Init_SaPlanningRefLine_id
{
public:
  Init_SaPlanningRefLine_id()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_SaPlanningRefLine_length id(::sa_msgs::msg::SaPlanningRefLine::_id_type arg)
  {
    msg_.id = std::move(arg);
    return Init_SaPlanningRefLine_length(msg_);
  }

private:
  ::sa_msgs::msg::SaPlanningRefLine msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::sa_msgs::msg::SaPlanningRefLine>()
{
  return sa_msgs::msg::builder::Init_SaPlanningRefLine_id();
}

}  // namespace sa_msgs

#endif  // SA_MSGS__MSG__DETAIL__SA_PLANNING_REF_LINE__BUILDER_HPP_
