// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef SA_MSGS__MSG__WHOLE_BODY_POSE_HPP_
#define SA_MSGS__MSG__WHOLE_BODY_POSE_HPP_

#include "sa_msgs/msg/detail/whole_body_pose__struct.hpp"
#include "sa_msgs/msg/detail/whole_body_pose__builder.hpp"
#include "sa_msgs/msg/detail/whole_body_pose__traits.hpp"
#include "sa_msgs/msg/detail/whole_body_pose__type_support.hpp"

#endif  // SA_MSGS__MSG__WHOLE_BODY_POSE_HPP_
