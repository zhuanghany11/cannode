// generated from rosidl_typesupport_fastrtps_c/resource/idl__rosidl_typesupport_fastrtps_c.h.em
// with input from sa_msgs:msg/HmiTaskPlanData.idl
// generated code does not contain a copyright notice
#ifndef SA_MSGS__MSG__DETAIL__HMI_TASK_PLAN_DATA__ROSIDL_TYPESUPPORT_FASTRTPS_C_H_
#define SA_MSGS__MSG__DETAIL__HMI_TASK_PLAN_DATA__ROSIDL_TYPESUPPORT_FASTRTPS_C_H_


#include <stddef.h>
#include "rosidl_runtime_c/message_type_support_struct.h"
#include "rosidl_typesupport_interface/macros.h"
#include "sa_msgs/msg/rosidl_typesupport_fastrtps_c__visibility_control.h"

#ifdef __cplusplus
extern "C"
{
#endif

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_sa_msgs
size_t get_serialized_size_sa_msgs__msg__HmiTaskPlanData(
  const void * untyped_ros_message,
  size_t current_alignment);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_sa_msgs
size_t max_serialized_size_sa_msgs__msg__HmiTaskPlanData(
  bool & full_bounded,
  bool & is_plain,
  size_t current_alignment);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_sa_msgs
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_fastrtps_c, sa_msgs, msg, HmiTaskPlanData)();

#ifdef __cplusplus
}
#endif

#endif  // SA_MSGS__MSG__DETAIL__HMI_TASK_PLAN_DATA__ROSIDL_TYPESUPPORT_FASTRTPS_C_H_
