// generated from rosidl_generator_c/resource/idl.h.em
// with input from sa_msgs:msg/DeceleAndStopReq.idl
// generated code does not contain a copyright notice

#ifndef SA_MSGS__MSG__DECELE_AND_STOP_REQ_H_
#define SA_MSGS__MSG__DECELE_AND_STOP_REQ_H_

#include "sa_msgs/msg/detail/decele_and_stop_req__struct.h"
#include "sa_msgs/msg/detail/decele_and_stop_req__functions.h"
#include "sa_msgs/msg/detail/decele_and_stop_req__type_support.h"

#endif  // SA_MSGS__MSG__DECELE_AND_STOP_REQ_H_
