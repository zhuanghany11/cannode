// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from sa_msgs:msg/HafPlanningOutV2.idl
// generated code does not contain a copyright notice

#ifndef SA_MSGS__MSG__DETAIL__HAF_PLANNING_OUT_V2__TRAITS_HPP_
#define SA_MSGS__MSG__DETAIL__HAF_PLANNING_OUT_V2__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "sa_msgs/msg/detail/haf_planning_out_v2__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__traits.hpp"
// Member 'plan_path'
// Member 'anchor_point'
#include "geometry_msgs/msg/detail/point__traits.hpp"

namespace sa_msgs
{

namespace msg
{

inline void to_flow_style_yaml(
  const HafPlanningOutV2 & msg,
  std::ostream & out)
{
  out << "{";
  // member: header
  {
    out << "header: ";
    to_flow_style_yaml(msg.header, out);
    out << ", ";
  }

  // member: is_odd
  {
    out << "is_odd: ";
    rosidl_generator_traits::value_to_yaml(msg.is_odd, out);
    out << ", ";
  }

  // member: mission_type
  {
    out << "mission_type: ";
    rosidl_generator_traits::value_to_yaml(msg.mission_type, out);
    out << ", ";
  }

  // member: velocity_limit
  {
    out << "velocity_limit: ";
    rosidl_generator_traits::value_to_yaml(msg.velocity_limit, out);
    out << ", ";
  }

  // member: plan_path
  {
    if (msg.plan_path.size() == 0) {
      out << "plan_path: []";
    } else {
      out << "plan_path: [";
      size_t pending_items = msg.plan_path.size();
      for (auto item : msg.plan_path) {
        to_flow_style_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
    out << ", ";
  }

  // member: plan_state
  {
    out << "plan_state: ";
    rosidl_generator_traits::value_to_yaml(msg.plan_state, out);
    out << ", ";
  }

  // member: next_station_name
  {
    out << "next_station_name: ";
    rosidl_generator_traits::value_to_yaml(msg.next_station_name, out);
    out << ", ";
  }

  // member: next_station_dist
  {
    out << "next_station_dist: ";
    rosidl_generator_traits::value_to_yaml(msg.next_station_dist, out);
    out << ", ";
  }

  // member: stop_task
  {
    out << "stop_task: ";
    rosidl_generator_traits::value_to_yaml(msg.stop_task, out);
    out << ", ";
  }

  // member: total_mileage
  {
    out << "total_mileage: ";
    rosidl_generator_traits::value_to_yaml(msg.total_mileage, out);
    out << ", ";
  }

  // member: is_exit_obstacle
  {
    out << "is_exit_obstacle: ";
    rosidl_generator_traits::value_to_yaml(msg.is_exit_obstacle, out);
    out << ", ";
  }

  // member: anchor_point
  {
    out << "anchor_point: ";
    to_flow_style_yaml(msg.anchor_point, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const HafPlanningOutV2 & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: header
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "header:\n";
    to_block_style_yaml(msg.header, out, indentation + 2);
  }

  // member: is_odd
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "is_odd: ";
    rosidl_generator_traits::value_to_yaml(msg.is_odd, out);
    out << "\n";
  }

  // member: mission_type
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "mission_type: ";
    rosidl_generator_traits::value_to_yaml(msg.mission_type, out);
    out << "\n";
  }

  // member: velocity_limit
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "velocity_limit: ";
    rosidl_generator_traits::value_to_yaml(msg.velocity_limit, out);
    out << "\n";
  }

  // member: plan_path
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.plan_path.size() == 0) {
      out << "plan_path: []\n";
    } else {
      out << "plan_path:\n";
      for (auto item : msg.plan_path) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "-\n";
        to_block_style_yaml(item, out, indentation + 2);
      }
    }
  }

  // member: plan_state
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "plan_state: ";
    rosidl_generator_traits::value_to_yaml(msg.plan_state, out);
    out << "\n";
  }

  // member: next_station_name
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "next_station_name: ";
    rosidl_generator_traits::value_to_yaml(msg.next_station_name, out);
    out << "\n";
  }

  // member: next_station_dist
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "next_station_dist: ";
    rosidl_generator_traits::value_to_yaml(msg.next_station_dist, out);
    out << "\n";
  }

  // member: stop_task
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "stop_task: ";
    rosidl_generator_traits::value_to_yaml(msg.stop_task, out);
    out << "\n";
  }

  // member: total_mileage
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "total_mileage: ";
    rosidl_generator_traits::value_to_yaml(msg.total_mileage, out);
    out << "\n";
  }

  // member: is_exit_obstacle
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "is_exit_obstacle: ";
    rosidl_generator_traits::value_to_yaml(msg.is_exit_obstacle, out);
    out << "\n";
  }

  // member: anchor_point
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "anchor_point:\n";
    to_block_style_yaml(msg.anchor_point, out, indentation + 2);
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const HafPlanningOutV2 & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace msg

}  // namespace sa_msgs

namespace rosidl_generator_traits
{

[[deprecated("use sa_msgs::msg::to_block_style_yaml() instead")]]
inline void to_yaml(
  const sa_msgs::msg::HafPlanningOutV2 & msg,
  std::ostream & out, size_t indentation = 0)
{
  sa_msgs::msg::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use sa_msgs::msg::to_yaml() instead")]]
inline std::string to_yaml(const sa_msgs::msg::HafPlanningOutV2 & msg)
{
  return sa_msgs::msg::to_yaml(msg);
}

template<>
inline const char * data_type<sa_msgs::msg::HafPlanningOutV2>()
{
  return "sa_msgs::msg::HafPlanningOutV2";
}

template<>
inline const char * name<sa_msgs::msg::HafPlanningOutV2>()
{
  return "sa_msgs/msg/HafPlanningOutV2";
}

template<>
struct has_fixed_size<sa_msgs::msg::HafPlanningOutV2>
  : std::integral_constant<bool, false> {};

template<>
struct has_bounded_size<sa_msgs::msg::HafPlanningOutV2>
  : std::integral_constant<bool, false> {};

template<>
struct is_message<sa_msgs::msg::HafPlanningOutV2>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // SA_MSGS__MSG__DETAIL__HAF_PLANNING_OUT_V2__TRAITS_HPP_
