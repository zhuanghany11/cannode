﻿// NOLINT: This file starts with a BOM since it contain non-ASCII characters
// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from sa_msgs:msg/TrajectoryPoint.idl
// generated code does not contain a copyright notice

#ifndef SA_MSGS__MSG__DETAIL__TRAJECTORY_POINT__STRUCT_H_
#define SA_MSGS__MSG__DETAIL__TRAJECTORY_POINT__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'path_point'
#include "sa_msgs/msg/detail/path_point__struct.h"

/// Struct defined in msg/TrajectoryPoint in the package sa_msgs.
typedef struct sa_msgs__msg__TrajectoryPoint
{
  /// path_point utm
  sa_msgs__msg__PathPoint path_point;
  /// linear velocity  in, not needed for prediction
  double v;
  /// linear acceleration, not needed for prediction
  double a;
  /// relative time from beginning of the trajectory, first point is 0
  double relative_time;
  /// longitudinal jerk
  double da;
  /// The angle between vehicle front wheel and vehicle longitudinal axis
  double steer;
  /// attribute 轨迹点的属性，保留位，后续可以用于道路特征描述
  uint32_t attr;
} sa_msgs__msg__TrajectoryPoint;

// Struct for a sequence of sa_msgs__msg__TrajectoryPoint.
typedef struct sa_msgs__msg__TrajectoryPoint__Sequence
{
  sa_msgs__msg__TrajectoryPoint * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} sa_msgs__msg__TrajectoryPoint__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // SA_MSGS__MSG__DETAIL__TRAJECTORY_POINT__STRUCT_H_
