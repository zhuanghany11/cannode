// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef SA_MSGS__MSG__COMPRESSED_VIDEO_HPP_
#define SA_MSGS__MSG__COMPRESSED_VIDEO_HPP_

#include "sa_msgs/msg/detail/compressed_video__struct.hpp"
#include "sa_msgs/msg/detail/compressed_video__builder.hpp"
#include "sa_msgs/msg/detail/compressed_video__traits.hpp"
#include "sa_msgs/msg/detail/compressed_video__type_support.hpp"

#endif  // SA_MSGS__MSG__COMPRESSED_VIDEO_HPP_
