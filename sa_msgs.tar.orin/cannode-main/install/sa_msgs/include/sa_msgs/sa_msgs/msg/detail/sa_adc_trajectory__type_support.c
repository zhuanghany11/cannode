// generated from rosidl_typesupport_introspection_c/resource/idl__type_support.c.em
// with input from sa_msgs:msg/SaADCTrajectory.idl
// generated code does not contain a copyright notice

#include <stddef.h>
#include "sa_msgs/msg/detail/sa_adc_trajectory__rosidl_typesupport_introspection_c.h"
#include "sa_msgs/msg/rosidl_typesupport_introspection_c__visibility_control.h"
#include "rosidl_typesupport_introspection_c/field_types.h"
#include "rosidl_typesupport_introspection_c/identifier.h"
#include "rosidl_typesupport_introspection_c/message_introspection.h"
#include "sa_msgs/msg/detail/sa_adc_trajectory__functions.h"
#include "sa_msgs/msg/detail/sa_adc_trajectory__struct.h"


// Include directives for member types
// Member `header`
#include "std_msgs/msg/header.h"
// Member `header`
#include "std_msgs/msg/detail/header__rosidl_typesupport_introspection_c.h"
// Member `trajectory_point`
#include "sa_msgs/msg/trajectory_point.h"
// Member `trajectory_point`
#include "sa_msgs/msg/detail/trajectory_point__rosidl_typesupport_introspection_c.h"
// Member `path_point`
#include "sa_msgs/msg/path_point.h"
// Member `path_point`
#include "sa_msgs/msg/detail/path_point__rosidl_typesupport_introspection_c.h"
// Member `target_point_type`
#include "sa_msgs/msg/target_point_type.h"
// Member `target_point_type`
#include "sa_msgs/msg/detail/target_point_type__rosidl_typesupport_introspection_c.h"
// Member `instruct`
#include "sa_msgs/msg/control_cmd.h"
// Member `instruct`
#include "sa_msgs/msg/detail/control_cmd__rosidl_typesupport_introspection_c.h"
// Member `gear`
#include "sa_msgs/msg/gear_position.h"
// Member `gear`
#include "sa_msgs/msg/detail/gear_position__rosidl_typesupport_introspection_c.h"
// Member `engage_advice`
#include "sa_msgs/msg/engage_advice.h"
// Member `engage_advice`
#include "sa_msgs/msg/detail/engage_advice__rosidl_typesupport_introspection_c.h"
// Member `vehicle_signal`
#include "sa_msgs/msg/vehicle_signal.h"
// Member `vehicle_signal`
#include "sa_msgs/msg/detail/vehicle_signal__rosidl_typesupport_introspection_c.h"

#ifdef __cplusplus
extern "C"
{
#endif

void sa_msgs__msg__SaADCTrajectory__rosidl_typesupport_introspection_c__SaADCTrajectory_init_function(
  void * message_memory, enum rosidl_runtime_c__message_initialization _init)
{
  // TODO(karsten1987): initializers are not yet implemented for typesupport c
  // see https://github.com/ros2/ros2/issues/397
  (void) _init;
  sa_msgs__msg__SaADCTrajectory__init(message_memory);
}

void sa_msgs__msg__SaADCTrajectory__rosidl_typesupport_introspection_c__SaADCTrajectory_fini_function(void * message_memory)
{
  sa_msgs__msg__SaADCTrajectory__fini(message_memory);
}

size_t sa_msgs__msg__SaADCTrajectory__rosidl_typesupport_introspection_c__size_function__SaADCTrajectory__trajectory_point(
  const void * untyped_member)
{
  const sa_msgs__msg__TrajectoryPoint__Sequence * member =
    (const sa_msgs__msg__TrajectoryPoint__Sequence *)(untyped_member);
  return member->size;
}

const void * sa_msgs__msg__SaADCTrajectory__rosidl_typesupport_introspection_c__get_const_function__SaADCTrajectory__trajectory_point(
  const void * untyped_member, size_t index)
{
  const sa_msgs__msg__TrajectoryPoint__Sequence * member =
    (const sa_msgs__msg__TrajectoryPoint__Sequence *)(untyped_member);
  return &member->data[index];
}

void * sa_msgs__msg__SaADCTrajectory__rosidl_typesupport_introspection_c__get_function__SaADCTrajectory__trajectory_point(
  void * untyped_member, size_t index)
{
  sa_msgs__msg__TrajectoryPoint__Sequence * member =
    (sa_msgs__msg__TrajectoryPoint__Sequence *)(untyped_member);
  return &member->data[index];
}

void sa_msgs__msg__SaADCTrajectory__rosidl_typesupport_introspection_c__fetch_function__SaADCTrajectory__trajectory_point(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const sa_msgs__msg__TrajectoryPoint * item =
    ((const sa_msgs__msg__TrajectoryPoint *)
    sa_msgs__msg__SaADCTrajectory__rosidl_typesupport_introspection_c__get_const_function__SaADCTrajectory__trajectory_point(untyped_member, index));
  sa_msgs__msg__TrajectoryPoint * value =
    (sa_msgs__msg__TrajectoryPoint *)(untyped_value);
  *value = *item;
}

void sa_msgs__msg__SaADCTrajectory__rosidl_typesupport_introspection_c__assign_function__SaADCTrajectory__trajectory_point(
  void * untyped_member, size_t index, const void * untyped_value)
{
  sa_msgs__msg__TrajectoryPoint * item =
    ((sa_msgs__msg__TrajectoryPoint *)
    sa_msgs__msg__SaADCTrajectory__rosidl_typesupport_introspection_c__get_function__SaADCTrajectory__trajectory_point(untyped_member, index));
  const sa_msgs__msg__TrajectoryPoint * value =
    (const sa_msgs__msg__TrajectoryPoint *)(untyped_value);
  *item = *value;
}

bool sa_msgs__msg__SaADCTrajectory__rosidl_typesupport_introspection_c__resize_function__SaADCTrajectory__trajectory_point(
  void * untyped_member, size_t size)
{
  sa_msgs__msg__TrajectoryPoint__Sequence * member =
    (sa_msgs__msg__TrajectoryPoint__Sequence *)(untyped_member);
  sa_msgs__msg__TrajectoryPoint__Sequence__fini(member);
  return sa_msgs__msg__TrajectoryPoint__Sequence__init(member, size);
}

size_t sa_msgs__msg__SaADCTrajectory__rosidl_typesupport_introspection_c__size_function__SaADCTrajectory__path_point(
  const void * untyped_member)
{
  const sa_msgs__msg__PathPoint__Sequence * member =
    (const sa_msgs__msg__PathPoint__Sequence *)(untyped_member);
  return member->size;
}

const void * sa_msgs__msg__SaADCTrajectory__rosidl_typesupport_introspection_c__get_const_function__SaADCTrajectory__path_point(
  const void * untyped_member, size_t index)
{
  const sa_msgs__msg__PathPoint__Sequence * member =
    (const sa_msgs__msg__PathPoint__Sequence *)(untyped_member);
  return &member->data[index];
}

void * sa_msgs__msg__SaADCTrajectory__rosidl_typesupport_introspection_c__get_function__SaADCTrajectory__path_point(
  void * untyped_member, size_t index)
{
  sa_msgs__msg__PathPoint__Sequence * member =
    (sa_msgs__msg__PathPoint__Sequence *)(untyped_member);
  return &member->data[index];
}

void sa_msgs__msg__SaADCTrajectory__rosidl_typesupport_introspection_c__fetch_function__SaADCTrajectory__path_point(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const sa_msgs__msg__PathPoint * item =
    ((const sa_msgs__msg__PathPoint *)
    sa_msgs__msg__SaADCTrajectory__rosidl_typesupport_introspection_c__get_const_function__SaADCTrajectory__path_point(untyped_member, index));
  sa_msgs__msg__PathPoint * value =
    (sa_msgs__msg__PathPoint *)(untyped_value);
  *value = *item;
}

void sa_msgs__msg__SaADCTrajectory__rosidl_typesupport_introspection_c__assign_function__SaADCTrajectory__path_point(
  void * untyped_member, size_t index, const void * untyped_value)
{
  sa_msgs__msg__PathPoint * item =
    ((sa_msgs__msg__PathPoint *)
    sa_msgs__msg__SaADCTrajectory__rosidl_typesupport_introspection_c__get_function__SaADCTrajectory__path_point(untyped_member, index));
  const sa_msgs__msg__PathPoint * value =
    (const sa_msgs__msg__PathPoint *)(untyped_value);
  *item = *value;
}

bool sa_msgs__msg__SaADCTrajectory__rosidl_typesupport_introspection_c__resize_function__SaADCTrajectory__path_point(
  void * untyped_member, size_t size)
{
  sa_msgs__msg__PathPoint__Sequence * member =
    (sa_msgs__msg__PathPoint__Sequence *)(untyped_member);
  sa_msgs__msg__PathPoint__Sequence__fini(member);
  return sa_msgs__msg__PathPoint__Sequence__init(member, size);
}

static rosidl_typesupport_introspection_c__MessageMember sa_msgs__msg__SaADCTrajectory__rosidl_typesupport_introspection_c__SaADCTrajectory_message_member_array[21] = {
  {
    "header",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message (initialized later)
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(sa_msgs__msg__SaADCTrajectory, header),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "total_path_length",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_DOUBLE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(sa_msgs__msg__SaADCTrajectory, total_path_length),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "total_path_time",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_DOUBLE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(sa_msgs__msg__SaADCTrajectory, total_path_time),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "trajectory_point",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message (initialized later)
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(sa_msgs__msg__SaADCTrajectory, trajectory_point),  // bytes offset in struct
    NULL,  // default value
    sa_msgs__msg__SaADCTrajectory__rosidl_typesupport_introspection_c__size_function__SaADCTrajectory__trajectory_point,  // size() function pointer
    sa_msgs__msg__SaADCTrajectory__rosidl_typesupport_introspection_c__get_const_function__SaADCTrajectory__trajectory_point,  // get_const(index) function pointer
    sa_msgs__msg__SaADCTrajectory__rosidl_typesupport_introspection_c__get_function__SaADCTrajectory__trajectory_point,  // get(index) function pointer
    sa_msgs__msg__SaADCTrajectory__rosidl_typesupport_introspection_c__fetch_function__SaADCTrajectory__trajectory_point,  // fetch(index, &value) function pointer
    sa_msgs__msg__SaADCTrajectory__rosidl_typesupport_introspection_c__assign_function__SaADCTrajectory__trajectory_point,  // assign(index, value) function pointer
    sa_msgs__msg__SaADCTrajectory__rosidl_typesupport_introspection_c__resize_function__SaADCTrajectory__trajectory_point  // resize(index) function pointer
  },
  {
    "path_point",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message (initialized later)
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(sa_msgs__msg__SaADCTrajectory, path_point),  // bytes offset in struct
    NULL,  // default value
    sa_msgs__msg__SaADCTrajectory__rosidl_typesupport_introspection_c__size_function__SaADCTrajectory__path_point,  // size() function pointer
    sa_msgs__msg__SaADCTrajectory__rosidl_typesupport_introspection_c__get_const_function__SaADCTrajectory__path_point,  // get_const(index) function pointer
    sa_msgs__msg__SaADCTrajectory__rosidl_typesupport_introspection_c__get_function__SaADCTrajectory__path_point,  // get(index) function pointer
    sa_msgs__msg__SaADCTrajectory__rosidl_typesupport_introspection_c__fetch_function__SaADCTrajectory__path_point,  // fetch(index, &value) function pointer
    sa_msgs__msg__SaADCTrajectory__rosidl_typesupport_introspection_c__assign_function__SaADCTrajectory__path_point,  // assign(index, value) function pointer
    sa_msgs__msg__SaADCTrajectory__rosidl_typesupport_introspection_c__resize_function__SaADCTrajectory__path_point  // resize(index) function pointer
  },
  {
    "target_point_type",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message (initialized later)
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(sa_msgs__msg__SaADCTrajectory, target_point_type),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "instruct",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message (initialized later)
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(sa_msgs__msg__SaADCTrajectory, instruct),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "gear",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message (initialized later)
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(sa_msgs__msg__SaADCTrajectory, gear),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "engage_advice",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message (initialized later)
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(sa_msgs__msg__SaADCTrajectory, engage_advice),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "plan_speed",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_DOUBLE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(sa_msgs__msg__SaADCTrajectory, plan_speed),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "limit_speed",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_DOUBLE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(sa_msgs__msg__SaADCTrajectory, limit_speed),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "limit_stop_dist",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_DOUBLE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(sa_msgs__msg__SaADCTrajectory, limit_stop_dist),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "accel",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_DOUBLE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(sa_msgs__msg__SaADCTrajectory, accel),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "lift_weight",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_INT32,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(sa_msgs__msg__SaADCTrajectory, lift_weight),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "align_guide_loc",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_DOUBLE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(sa_msgs__msg__SaADCTrajectory, align_guide_loc),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "oblique_status",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_INT32,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(sa_msgs__msg__SaADCTrajectory, oblique_status),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "vehicle_signal",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message (initialized later)
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(sa_msgs__msg__SaADCTrajectory, vehicle_signal),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "opendoor_status",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_INT32,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(sa_msgs__msg__SaADCTrajectory, opendoor_status),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "trajectory_type",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_INT32,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(sa_msgs__msg__SaADCTrajectory, trajectory_type),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "shovel_angle",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_DOUBLE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(sa_msgs__msg__SaADCTrajectory, shovel_angle),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "arm_angle",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_DOUBLE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(sa_msgs__msg__SaADCTrajectory, arm_angle),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  }
};

static const rosidl_typesupport_introspection_c__MessageMembers sa_msgs__msg__SaADCTrajectory__rosidl_typesupport_introspection_c__SaADCTrajectory_message_members = {
  "sa_msgs__msg",  // message namespace
  "SaADCTrajectory",  // message name
  21,  // number of fields
  sizeof(sa_msgs__msg__SaADCTrajectory),
  sa_msgs__msg__SaADCTrajectory__rosidl_typesupport_introspection_c__SaADCTrajectory_message_member_array,  // message members
  sa_msgs__msg__SaADCTrajectory__rosidl_typesupport_introspection_c__SaADCTrajectory_init_function,  // function to initialize message memory (memory has to be allocated)
  sa_msgs__msg__SaADCTrajectory__rosidl_typesupport_introspection_c__SaADCTrajectory_fini_function  // function to terminate message instance (will not free memory)
};

// this is not const since it must be initialized on first access
// since C does not allow non-integral compile-time constants
static rosidl_message_type_support_t sa_msgs__msg__SaADCTrajectory__rosidl_typesupport_introspection_c__SaADCTrajectory_message_type_support_handle = {
  0,
  &sa_msgs__msg__SaADCTrajectory__rosidl_typesupport_introspection_c__SaADCTrajectory_message_members,
  get_message_typesupport_handle_function,
};

ROSIDL_TYPESUPPORT_INTROSPECTION_C_EXPORT_sa_msgs
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, sa_msgs, msg, SaADCTrajectory)() {
  sa_msgs__msg__SaADCTrajectory__rosidl_typesupport_introspection_c__SaADCTrajectory_message_member_array[0].members_ =
    ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, std_msgs, msg, Header)();
  sa_msgs__msg__SaADCTrajectory__rosidl_typesupport_introspection_c__SaADCTrajectory_message_member_array[3].members_ =
    ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, sa_msgs, msg, TrajectoryPoint)();
  sa_msgs__msg__SaADCTrajectory__rosidl_typesupport_introspection_c__SaADCTrajectory_message_member_array[4].members_ =
    ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, sa_msgs, msg, PathPoint)();
  sa_msgs__msg__SaADCTrajectory__rosidl_typesupport_introspection_c__SaADCTrajectory_message_member_array[5].members_ =
    ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, sa_msgs, msg, TargetPointType)();
  sa_msgs__msg__SaADCTrajectory__rosidl_typesupport_introspection_c__SaADCTrajectory_message_member_array[6].members_ =
    ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, sa_msgs, msg, ControlCmd)();
  sa_msgs__msg__SaADCTrajectory__rosidl_typesupport_introspection_c__SaADCTrajectory_message_member_array[7].members_ =
    ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, sa_msgs, msg, GearPosition)();
  sa_msgs__msg__SaADCTrajectory__rosidl_typesupport_introspection_c__SaADCTrajectory_message_member_array[8].members_ =
    ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, sa_msgs, msg, EngageAdvice)();
  sa_msgs__msg__SaADCTrajectory__rosidl_typesupport_introspection_c__SaADCTrajectory_message_member_array[16].members_ =
    ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, sa_msgs, msg, VehicleSignal)();
  if (!sa_msgs__msg__SaADCTrajectory__rosidl_typesupport_introspection_c__SaADCTrajectory_message_type_support_handle.typesupport_identifier) {
    sa_msgs__msg__SaADCTrajectory__rosidl_typesupport_introspection_c__SaADCTrajectory_message_type_support_handle.typesupport_identifier =
      rosidl_typesupport_introspection_c__identifier;
  }
  return &sa_msgs__msg__SaADCTrajectory__rosidl_typesupport_introspection_c__SaADCTrajectory_message_type_support_handle;
}
#ifdef __cplusplus
}
#endif
