// generated from rosidl_generator_c/resource/idl.h.em
// with input from sa_msgs:msg/SaRadarDetect.idl
// generated code does not contain a copyright notice

#ifndef SA_MSGS__MSG__SA_RADAR_DETECT_H_
#define SA_MSGS__MSG__SA_RADAR_DETECT_H_

#include "sa_msgs/msg/detail/sa_radar_detect__struct.h"
#include "sa_msgs/msg/detail/sa_radar_detect__functions.h"
#include "sa_msgs/msg/detail/sa_radar_detect__type_support.h"

#endif  // SA_MSGS__MSG__SA_RADAR_DETECT_H_
