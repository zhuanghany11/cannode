// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from sa_msgs:msg/AutoDrivingRes.idl
// generated code does not contain a copyright notice

#ifndef SA_MSGS__MSG__DETAIL__AUTO_DRIVING_RES__BUILDER_HPP_
#define SA_MSGS__MSG__DETAIL__AUTO_DRIVING_RES__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "sa_msgs/msg/detail/auto_driving_res__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace sa_msgs
{

namespace msg
{

namespace builder
{

class Init_AutoDrivingRes_pb
{
public:
  explicit Init_AutoDrivingRes_pb(::sa_msgs::msg::AutoDrivingRes & msg)
  : msg_(msg)
  {}
  ::sa_msgs::msg::AutoDrivingRes pb(::sa_msgs::msg::AutoDrivingRes::_pb_type arg)
  {
    msg_.pb = std::move(arg);
    return std::move(msg_);
  }

private:
  ::sa_msgs::msg::AutoDrivingRes msg_;
};

class Init_AutoDrivingRes_err_code
{
public:
  explicit Init_AutoDrivingRes_err_code(::sa_msgs::msg::AutoDrivingRes & msg)
  : msg_(msg)
  {}
  Init_AutoDrivingRes_pb err_code(::sa_msgs::msg::AutoDrivingRes::_err_code_type arg)
  {
    msg_.err_code = std::move(arg);
    return Init_AutoDrivingRes_pb(msg_);
  }

private:
  ::sa_msgs::msg::AutoDrivingRes msg_;
};

class Init_AutoDrivingRes_result
{
public:
  explicit Init_AutoDrivingRes_result(::sa_msgs::msg::AutoDrivingRes & msg)
  : msg_(msg)
  {}
  Init_AutoDrivingRes_err_code result(::sa_msgs::msg::AutoDrivingRes::_result_type arg)
  {
    msg_.result = std::move(arg);
    return Init_AutoDrivingRes_err_code(msg_);
  }

private:
  ::sa_msgs::msg::AutoDrivingRes msg_;
};

class Init_AutoDrivingRes_distance
{
public:
  explicit Init_AutoDrivingRes_distance(::sa_msgs::msg::AutoDrivingRes & msg)
  : msg_(msg)
  {}
  Init_AutoDrivingRes_result distance(::sa_msgs::msg::AutoDrivingRes::_distance_type arg)
  {
    msg_.distance = std::move(arg);
    return Init_AutoDrivingRes_result(msg_);
  }

private:
  ::sa_msgs::msg::AutoDrivingRes msg_;
};

class Init_AutoDrivingRes_id
{
public:
  explicit Init_AutoDrivingRes_id(::sa_msgs::msg::AutoDrivingRes & msg)
  : msg_(msg)
  {}
  Init_AutoDrivingRes_distance id(::sa_msgs::msg::AutoDrivingRes::_id_type arg)
  {
    msg_.id = std::move(arg);
    return Init_AutoDrivingRes_distance(msg_);
  }

private:
  ::sa_msgs::msg::AutoDrivingRes msg_;
};

class Init_AutoDrivingRes_seq
{
public:
  explicit Init_AutoDrivingRes_seq(::sa_msgs::msg::AutoDrivingRes & msg)
  : msg_(msg)
  {}
  Init_AutoDrivingRes_id seq(::sa_msgs::msg::AutoDrivingRes::_seq_type arg)
  {
    msg_.seq = std::move(arg);
    return Init_AutoDrivingRes_id(msg_);
  }

private:
  ::sa_msgs::msg::AutoDrivingRes msg_;
};

class Init_AutoDrivingRes_header
{
public:
  Init_AutoDrivingRes_header()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_AutoDrivingRes_seq header(::sa_msgs::msg::AutoDrivingRes::_header_type arg)
  {
    msg_.header = std::move(arg);
    return Init_AutoDrivingRes_seq(msg_);
  }

private:
  ::sa_msgs::msg::AutoDrivingRes msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::sa_msgs::msg::AutoDrivingRes>()
{
  return sa_msgs::msg::builder::Init_AutoDrivingRes_header();
}

}  // namespace sa_msgs

#endif  // SA_MSGS__MSG__DETAIL__AUTO_DRIVING_RES__BUILDER_HPP_
