// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from sa_msgs:msg/DeceleAndStopRes.idl
// generated code does not contain a copyright notice

#ifndef SA_MSGS__MSG__DETAIL__DECELE_AND_STOP_RES__BUILDER_HPP_
#define SA_MSGS__MSG__DETAIL__DECELE_AND_STOP_RES__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "sa_msgs/msg/detail/decele_and_stop_res__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace sa_msgs
{

namespace msg
{

namespace builder
{

class Init_DeceleAndStopRes_pb
{
public:
  explicit Init_DeceleAndStopRes_pb(::sa_msgs::msg::DeceleAndStopRes & msg)
  : msg_(msg)
  {}
  ::sa_msgs::msg::DeceleAndStopRes pb(::sa_msgs::msg::DeceleAndStopRes::_pb_type arg)
  {
    msg_.pb = std::move(arg);
    return std::move(msg_);
  }

private:
  ::sa_msgs::msg::DeceleAndStopRes msg_;
};

class Init_DeceleAndStopRes_err_code
{
public:
  explicit Init_DeceleAndStopRes_err_code(::sa_msgs::msg::DeceleAndStopRes & msg)
  : msg_(msg)
  {}
  Init_DeceleAndStopRes_pb err_code(::sa_msgs::msg::DeceleAndStopRes::_err_code_type arg)
  {
    msg_.err_code = std::move(arg);
    return Init_DeceleAndStopRes_pb(msg_);
  }

private:
  ::sa_msgs::msg::DeceleAndStopRes msg_;
};

class Init_DeceleAndStopRes_result
{
public:
  explicit Init_DeceleAndStopRes_result(::sa_msgs::msg::DeceleAndStopRes & msg)
  : msg_(msg)
  {}
  Init_DeceleAndStopRes_err_code result(::sa_msgs::msg::DeceleAndStopRes::_result_type arg)
  {
    msg_.result = std::move(arg);
    return Init_DeceleAndStopRes_err_code(msg_);
  }

private:
  ::sa_msgs::msg::DeceleAndStopRes msg_;
};

class Init_DeceleAndStopRes_seq
{
public:
  explicit Init_DeceleAndStopRes_seq(::sa_msgs::msg::DeceleAndStopRes & msg)
  : msg_(msg)
  {}
  Init_DeceleAndStopRes_result seq(::sa_msgs::msg::DeceleAndStopRes::_seq_type arg)
  {
    msg_.seq = std::move(arg);
    return Init_DeceleAndStopRes_result(msg_);
  }

private:
  ::sa_msgs::msg::DeceleAndStopRes msg_;
};

class Init_DeceleAndStopRes_header
{
public:
  Init_DeceleAndStopRes_header()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_DeceleAndStopRes_seq header(::sa_msgs::msg::DeceleAndStopRes::_header_type arg)
  {
    msg_.header = std::move(arg);
    return Init_DeceleAndStopRes_seq(msg_);
  }

private:
  ::sa_msgs::msg::DeceleAndStopRes msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::sa_msgs::msg::DeceleAndStopRes>()
{
  return sa_msgs::msg::builder::Init_DeceleAndStopRes_header();
}

}  // namespace sa_msgs

#endif  // SA_MSGS__MSG__DETAIL__DECELE_AND_STOP_RES__BUILDER_HPP_
