// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef SA_MSGS__MSG__REGION_RESTRICTION_HPP_
#define SA_MSGS__MSG__REGION_RESTRICTION_HPP_

#include "sa_msgs/msg/detail/region_restriction__struct.hpp"
#include "sa_msgs/msg/detail/region_restriction__builder.hpp"
#include "sa_msgs/msg/detail/region_restriction__traits.hpp"
#include "sa_msgs/msg/detail/region_restriction__type_support.hpp"

#endif  // SA_MSGS__MSG__REGION_RESTRICTION_HPP_
