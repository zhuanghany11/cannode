// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from sa_msgs:msg/SaPlanningTaskPlanData.idl
// generated code does not contain a copyright notice

#ifndef SA_MSGS__MSG__DETAIL__SA_PLANNING_TASK_PLAN_DATA__BUILDER_HPP_
#define SA_MSGS__MSG__DETAIL__SA_PLANNING_TASK_PLAN_DATA__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "sa_msgs/msg/detail/sa_planning_task_plan_data__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace sa_msgs
{

namespace msg
{

namespace builder
{

class Init_SaPlanningTaskPlanData_timestamp
{
public:
  explicit Init_SaPlanningTaskPlanData_timestamp(::sa_msgs::msg::SaPlanningTaskPlanData & msg)
  : msg_(msg)
  {}
  ::sa_msgs::msg::SaPlanningTaskPlanData timestamp(::sa_msgs::msg::SaPlanningTaskPlanData::_timestamp_type arg)
  {
    msg_.timestamp = std::move(arg);
    return std::move(msg_);
  }

private:
  ::sa_msgs::msg::SaPlanningTaskPlanData msg_;
};

class Init_SaPlanningTaskPlanData_msg
{
public:
  explicit Init_SaPlanningTaskPlanData_msg(::sa_msgs::msg::SaPlanningTaskPlanData & msg)
  : msg_(msg)
  {}
  Init_SaPlanningTaskPlanData_timestamp msg(::sa_msgs::msg::SaPlanningTaskPlanData::_msg_type arg)
  {
    msg_.msg = std::move(arg);
    return Init_SaPlanningTaskPlanData_timestamp(msg_);
  }

private:
  ::sa_msgs::msg::SaPlanningTaskPlanData msg_;
};

class Init_SaPlanningTaskPlanData_status
{
public:
  explicit Init_SaPlanningTaskPlanData_status(::sa_msgs::msg::SaPlanningTaskPlanData & msg)
  : msg_(msg)
  {}
  Init_SaPlanningTaskPlanData_msg status(::sa_msgs::msg::SaPlanningTaskPlanData::_status_type arg)
  {
    msg_.status = std::move(arg);
    return Init_SaPlanningTaskPlanData_msg(msg_);
  }

private:
  ::sa_msgs::msg::SaPlanningTaskPlanData msg_;
};

class Init_SaPlanningTaskPlanData_plan_mileage
{
public:
  explicit Init_SaPlanningTaskPlanData_plan_mileage(::sa_msgs::msg::SaPlanningTaskPlanData & msg)
  : msg_(msg)
  {}
  Init_SaPlanningTaskPlanData_status plan_mileage(::sa_msgs::msg::SaPlanningTaskPlanData::_plan_mileage_type arg)
  {
    msg_.plan_mileage = std::move(arg);
    return Init_SaPlanningTaskPlanData_status(msg_);
  }

private:
  ::sa_msgs::msg::SaPlanningTaskPlanData msg_;
};

class Init_SaPlanningTaskPlanData_plan_path
{
public:
  explicit Init_SaPlanningTaskPlanData_plan_path(::sa_msgs::msg::SaPlanningTaskPlanData & msg)
  : msg_(msg)
  {}
  Init_SaPlanningTaskPlanData_plan_mileage plan_path(::sa_msgs::msg::SaPlanningTaskPlanData::_plan_path_type arg)
  {
    msg_.plan_path = std::move(arg);
    return Init_SaPlanningTaskPlanData_plan_mileage(msg_);
  }

private:
  ::sa_msgs::msg::SaPlanningTaskPlanData msg_;
};

class Init_SaPlanningTaskPlanData_task_id
{
public:
  Init_SaPlanningTaskPlanData_task_id()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_SaPlanningTaskPlanData_plan_path task_id(::sa_msgs::msg::SaPlanningTaskPlanData::_task_id_type arg)
  {
    msg_.task_id = std::move(arg);
    return Init_SaPlanningTaskPlanData_plan_path(msg_);
  }

private:
  ::sa_msgs::msg::SaPlanningTaskPlanData msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::sa_msgs::msg::SaPlanningTaskPlanData>()
{
  return sa_msgs::msg::builder::Init_SaPlanningTaskPlanData_task_id();
}

}  // namespace sa_msgs

#endif  // SA_MSGS__MSG__DETAIL__SA_PLANNING_TASK_PLAN_DATA__BUILDER_HPP_
