// generated from rosidl_generator_c/resource/idl.h.em
// with input from sa_msgs:msg/HafDisplayObstacle.idl
// generated code does not contain a copyright notice

#ifndef SA_MSGS__MSG__HAF_DISPLAY_OBSTACLE_H_
#define SA_MSGS__MSG__HAF_DISPLAY_OBSTACLE_H_

#include "sa_msgs/msg/detail/haf_display_obstacle__struct.h"
#include "sa_msgs/msg/detail/haf_display_obstacle__functions.h"
#include "sa_msgs/msg/detail/haf_display_obstacle__type_support.h"

#endif  // SA_MSGS__MSG__HAF_DISPLAY_OBSTACLE_H_
