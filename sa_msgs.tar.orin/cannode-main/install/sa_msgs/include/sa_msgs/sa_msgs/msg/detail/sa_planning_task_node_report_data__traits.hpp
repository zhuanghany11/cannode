// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from sa_msgs:msg/SaPlanningTaskNodeReportData.idl
// generated code does not contain a copyright notice

#ifndef SA_MSGS__MSG__DETAIL__SA_PLANNING_TASK_NODE_REPORT_DATA__TRAITS_HPP_
#define SA_MSGS__MSG__DETAIL__SA_PLANNING_TASK_NODE_REPORT_DATA__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "sa_msgs/msg/detail/sa_planning_task_node_report_data__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

namespace sa_msgs
{

namespace msg
{

inline void to_flow_style_yaml(
  const SaPlanningTaskNodeReportData & msg,
  std::ostream & out)
{
  out << "{";
  // member: task_id
  {
    out << "task_id: ";
    rosidl_generator_traits::value_to_yaml(msg.task_id, out);
    out << ", ";
  }

  // member: type
  {
    out << "type: ";
    rosidl_generator_traits::value_to_yaml(msg.type, out);
    out << ", ";
  }

  // member: station_name
  {
    out << "station_name: ";
    rosidl_generator_traits::value_to_yaml(msg.station_name, out);
    out << ", ";
  }

  // member: total_mileage
  {
    out << "total_mileage: ";
    rosidl_generator_traits::value_to_yaml(msg.total_mileage, out);
    out << ", ";
  }

  // member: timestamp
  {
    out << "timestamp: ";
    rosidl_generator_traits::value_to_yaml(msg.timestamp, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const SaPlanningTaskNodeReportData & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: task_id
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "task_id: ";
    rosidl_generator_traits::value_to_yaml(msg.task_id, out);
    out << "\n";
  }

  // member: type
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "type: ";
    rosidl_generator_traits::value_to_yaml(msg.type, out);
    out << "\n";
  }

  // member: station_name
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "station_name: ";
    rosidl_generator_traits::value_to_yaml(msg.station_name, out);
    out << "\n";
  }

  // member: total_mileage
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "total_mileage: ";
    rosidl_generator_traits::value_to_yaml(msg.total_mileage, out);
    out << "\n";
  }

  // member: timestamp
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "timestamp: ";
    rosidl_generator_traits::value_to_yaml(msg.timestamp, out);
    out << "\n";
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const SaPlanningTaskNodeReportData & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace msg

}  // namespace sa_msgs

namespace rosidl_generator_traits
{

[[deprecated("use sa_msgs::msg::to_block_style_yaml() instead")]]
inline void to_yaml(
  const sa_msgs::msg::SaPlanningTaskNodeReportData & msg,
  std::ostream & out, size_t indentation = 0)
{
  sa_msgs::msg::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use sa_msgs::msg::to_yaml() instead")]]
inline std::string to_yaml(const sa_msgs::msg::SaPlanningTaskNodeReportData & msg)
{
  return sa_msgs::msg::to_yaml(msg);
}

template<>
inline const char * data_type<sa_msgs::msg::SaPlanningTaskNodeReportData>()
{
  return "sa_msgs::msg::SaPlanningTaskNodeReportData";
}

template<>
inline const char * name<sa_msgs::msg::SaPlanningTaskNodeReportData>()
{
  return "sa_msgs/msg/SaPlanningTaskNodeReportData";
}

template<>
struct has_fixed_size<sa_msgs::msg::SaPlanningTaskNodeReportData>
  : std::integral_constant<bool, false> {};

template<>
struct has_bounded_size<sa_msgs::msg::SaPlanningTaskNodeReportData>
  : std::integral_constant<bool, false> {};

template<>
struct is_message<sa_msgs::msg::SaPlanningTaskNodeReportData>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // SA_MSGS__MSG__DETAIL__SA_PLANNING_TASK_NODE_REPORT_DATA__TRAITS_HPP_
