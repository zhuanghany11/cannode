// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from sa_msgs:msg/SaLocGinsInfo.idl
// generated code does not contain a copyright notice

#ifndef SA_MSGS__MSG__DETAIL__SA_LOC_GINS_INFO__TRAITS_HPP_
#define SA_MSGS__MSG__DETAIL__SA_LOC_GINS_INFO__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "sa_msgs/msg/detail/sa_loc_gins_info__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__traits.hpp"
// Member 'fusion_position'
#include "geometry_msgs/msg/detail/vector3__traits.hpp"
// Member 'fusion_position_std'
// Member 'fusion_velocity'
// Member 'fusion_velocity_std'
// Member 'fusion_rpy'
// Member 'fusion_rpy_std'
#include "geometry_msgs/msg/detail/point32__traits.hpp"

namespace sa_msgs
{

namespace msg
{

inline void to_flow_style_yaml(
  const SaLocGinsInfo & msg,
  std::ostream & out)
{
  out << "{";
  // member: header
  {
    out << "header: ";
    to_flow_style_yaml(msg.header, out);
    out << ", ";
  }

  // member: child_frame_id
  {
    out << "child_frame_id: ";
    rosidl_generator_traits::value_to_yaml(msg.child_frame_id, out);
    out << ", ";
  }

  // member: fusion_position
  {
    out << "fusion_position: ";
    to_flow_style_yaml(msg.fusion_position, out);
    out << ", ";
  }

  // member: fusion_position_std
  {
    out << "fusion_position_std: ";
    to_flow_style_yaml(msg.fusion_position_std, out);
    out << ", ";
  }

  // member: fusion_utm_east
  {
    out << "fusion_utm_east: ";
    rosidl_generator_traits::value_to_yaml(msg.fusion_utm_east, out);
    out << ", ";
  }

  // member: fusion_utm_north
  {
    out << "fusion_utm_north: ";
    rosidl_generator_traits::value_to_yaml(msg.fusion_utm_north, out);
    out << ", ";
  }

  // member: fusion_velocity
  {
    out << "fusion_velocity: ";
    to_flow_style_yaml(msg.fusion_velocity, out);
    out << ", ";
  }

  // member: fusion_velocity_std
  {
    out << "fusion_velocity_std: ";
    to_flow_style_yaml(msg.fusion_velocity_std, out);
    out << ", ";
  }

  // member: speed
  {
    out << "speed: ";
    rosidl_generator_traits::value_to_yaml(msg.speed, out);
    out << ", ";
  }

  // member: fusion_rpy
  {
    out << "fusion_rpy: ";
    to_flow_style_yaml(msg.fusion_rpy, out);
    out << ", ";
  }

  // member: fusion_rpy_std
  {
    out << "fusion_rpy_std: ";
    to_flow_style_yaml(msg.fusion_rpy_std, out);
    out << ", ";
  }

  // member: fusion_status
  {
    out << "fusion_status: ";
    rosidl_generator_traits::value_to_yaml(msg.fusion_status, out);
    out << ", ";
  }

  // member: gnss_status
  {
    out << "gnss_status: ";
    rosidl_generator_traits::value_to_yaml(msg.gnss_status, out);
    out << ", ";
  }

  // member: sats_used
  {
    out << "sats_used: ";
    rosidl_generator_traits::value_to_yaml(msg.sats_used, out);
    out << ", ";
  }

  // member: sats_tracked
  {
    out << "sats_tracked: ";
    rosidl_generator_traits::value_to_yaml(msg.sats_tracked, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const SaLocGinsInfo & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: header
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "header:\n";
    to_block_style_yaml(msg.header, out, indentation + 2);
  }

  // member: child_frame_id
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "child_frame_id: ";
    rosidl_generator_traits::value_to_yaml(msg.child_frame_id, out);
    out << "\n";
  }

  // member: fusion_position
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "fusion_position:\n";
    to_block_style_yaml(msg.fusion_position, out, indentation + 2);
  }

  // member: fusion_position_std
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "fusion_position_std:\n";
    to_block_style_yaml(msg.fusion_position_std, out, indentation + 2);
  }

  // member: fusion_utm_east
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "fusion_utm_east: ";
    rosidl_generator_traits::value_to_yaml(msg.fusion_utm_east, out);
    out << "\n";
  }

  // member: fusion_utm_north
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "fusion_utm_north: ";
    rosidl_generator_traits::value_to_yaml(msg.fusion_utm_north, out);
    out << "\n";
  }

  // member: fusion_velocity
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "fusion_velocity:\n";
    to_block_style_yaml(msg.fusion_velocity, out, indentation + 2);
  }

  // member: fusion_velocity_std
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "fusion_velocity_std:\n";
    to_block_style_yaml(msg.fusion_velocity_std, out, indentation + 2);
  }

  // member: speed
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "speed: ";
    rosidl_generator_traits::value_to_yaml(msg.speed, out);
    out << "\n";
  }

  // member: fusion_rpy
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "fusion_rpy:\n";
    to_block_style_yaml(msg.fusion_rpy, out, indentation + 2);
  }

  // member: fusion_rpy_std
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "fusion_rpy_std:\n";
    to_block_style_yaml(msg.fusion_rpy_std, out, indentation + 2);
  }

  // member: fusion_status
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "fusion_status: ";
    rosidl_generator_traits::value_to_yaml(msg.fusion_status, out);
    out << "\n";
  }

  // member: gnss_status
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "gnss_status: ";
    rosidl_generator_traits::value_to_yaml(msg.gnss_status, out);
    out << "\n";
  }

  // member: sats_used
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "sats_used: ";
    rosidl_generator_traits::value_to_yaml(msg.sats_used, out);
    out << "\n";
  }

  // member: sats_tracked
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "sats_tracked: ";
    rosidl_generator_traits::value_to_yaml(msg.sats_tracked, out);
    out << "\n";
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const SaLocGinsInfo & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace msg

}  // namespace sa_msgs

namespace rosidl_generator_traits
{

[[deprecated("use sa_msgs::msg::to_block_style_yaml() instead")]]
inline void to_yaml(
  const sa_msgs::msg::SaLocGinsInfo & msg,
  std::ostream & out, size_t indentation = 0)
{
  sa_msgs::msg::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use sa_msgs::msg::to_yaml() instead")]]
inline std::string to_yaml(const sa_msgs::msg::SaLocGinsInfo & msg)
{
  return sa_msgs::msg::to_yaml(msg);
}

template<>
inline const char * data_type<sa_msgs::msg::SaLocGinsInfo>()
{
  return "sa_msgs::msg::SaLocGinsInfo";
}

template<>
inline const char * name<sa_msgs::msg::SaLocGinsInfo>()
{
  return "sa_msgs/msg/SaLocGinsInfo";
}

template<>
struct has_fixed_size<sa_msgs::msg::SaLocGinsInfo>
  : std::integral_constant<bool, false> {};

template<>
struct has_bounded_size<sa_msgs::msg::SaLocGinsInfo>
  : std::integral_constant<bool, false> {};

template<>
struct is_message<sa_msgs::msg::SaLocGinsInfo>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // SA_MSGS__MSG__DETAIL__SA_LOC_GINS_INFO__TRAITS_HPP_
