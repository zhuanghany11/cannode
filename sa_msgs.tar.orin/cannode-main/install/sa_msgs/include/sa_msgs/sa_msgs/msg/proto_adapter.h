// generated from rosidl_generator_c/resource/idl.h.em
// with input from sa_msgs:msg/ProtoAdapter.idl
// generated code does not contain a copyright notice

#ifndef SA_MSGS__MSG__PROTO_ADAPTER_H_
#define SA_MSGS__MSG__PROTO_ADAPTER_H_

#include "sa_msgs/msg/detail/proto_adapter__struct.h"
#include "sa_msgs/msg/detail/proto_adapter__functions.h"
#include "sa_msgs/msg/detail/proto_adapter__type_support.h"

#endif  // SA_MSGS__MSG__PROTO_ADAPTER_H_
