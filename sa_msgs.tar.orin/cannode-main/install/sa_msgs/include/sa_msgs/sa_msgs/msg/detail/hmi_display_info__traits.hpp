// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from sa_msgs:msg/HmiDisplayInfo.idl
// generated code does not contain a copyright notice

#ifndef SA_MSGS__MSG__DETAIL__HMI_DISPLAY_INFO__TRAITS_HPP_
#define SA_MSGS__MSG__DETAIL__HMI_DISPLAY_INFO__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "sa_msgs/msg/detail/hmi_display_info__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

namespace sa_msgs
{

namespace msg
{

inline void to_flow_style_yaml(
  const HmiDisplayInfo & msg,
  std::ostream & out)
{
  out << "{";
  // member: work_type
  {
    out << "work_type: ";
    rosidl_generator_traits::value_to_yaml(msg.work_type, out);
    out << ", ";
  }

  // member: box_position
  {
    out << "box_position: ";
    rosidl_generator_traits::value_to_yaml(msg.box_position, out);
    out << ", ";
  }

  // member: start_type
  {
    out << "start_type: ";
    rosidl_generator_traits::value_to_yaml(msg.start_type, out);
    out << ", ";
  }

  // member: start_position
  {
    out << "start_position: ";
    rosidl_generator_traits::value_to_yaml(msg.start_position, out);
    out << ", ";
  }

  // member: start_sec_position
  {
    out << "start_sec_position: ";
    rosidl_generator_traits::value_to_yaml(msg.start_sec_position, out);
    out << ", ";
  }

  // member: end_type
  {
    out << "end_type: ";
    rosidl_generator_traits::value_to_yaml(msg.end_type, out);
    out << ", ";
  }

  // member: end_position
  {
    out << "end_position: ";
    rosidl_generator_traits::value_to_yaml(msg.end_position, out);
    out << ", ";
  }

  // member: end_sec_position
  {
    out << "end_sec_position: ";
    rosidl_generator_traits::value_to_yaml(msg.end_sec_position, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const HmiDisplayInfo & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: work_type
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "work_type: ";
    rosidl_generator_traits::value_to_yaml(msg.work_type, out);
    out << "\n";
  }

  // member: box_position
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "box_position: ";
    rosidl_generator_traits::value_to_yaml(msg.box_position, out);
    out << "\n";
  }

  // member: start_type
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "start_type: ";
    rosidl_generator_traits::value_to_yaml(msg.start_type, out);
    out << "\n";
  }

  // member: start_position
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "start_position: ";
    rosidl_generator_traits::value_to_yaml(msg.start_position, out);
    out << "\n";
  }

  // member: start_sec_position
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "start_sec_position: ";
    rosidl_generator_traits::value_to_yaml(msg.start_sec_position, out);
    out << "\n";
  }

  // member: end_type
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "end_type: ";
    rosidl_generator_traits::value_to_yaml(msg.end_type, out);
    out << "\n";
  }

  // member: end_position
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "end_position: ";
    rosidl_generator_traits::value_to_yaml(msg.end_position, out);
    out << "\n";
  }

  // member: end_sec_position
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "end_sec_position: ";
    rosidl_generator_traits::value_to_yaml(msg.end_sec_position, out);
    out << "\n";
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const HmiDisplayInfo & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace msg

}  // namespace sa_msgs

namespace rosidl_generator_traits
{

[[deprecated("use sa_msgs::msg::to_block_style_yaml() instead")]]
inline void to_yaml(
  const sa_msgs::msg::HmiDisplayInfo & msg,
  std::ostream & out, size_t indentation = 0)
{
  sa_msgs::msg::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use sa_msgs::msg::to_yaml() instead")]]
inline std::string to_yaml(const sa_msgs::msg::HmiDisplayInfo & msg)
{
  return sa_msgs::msg::to_yaml(msg);
}

template<>
inline const char * data_type<sa_msgs::msg::HmiDisplayInfo>()
{
  return "sa_msgs::msg::HmiDisplayInfo";
}

template<>
inline const char * name<sa_msgs::msg::HmiDisplayInfo>()
{
  return "sa_msgs/msg/HmiDisplayInfo";
}

template<>
struct has_fixed_size<sa_msgs::msg::HmiDisplayInfo>
  : std::integral_constant<bool, true> {};

template<>
struct has_bounded_size<sa_msgs::msg::HmiDisplayInfo>
  : std::integral_constant<bool, true> {};

template<>
struct is_message<sa_msgs::msg::HmiDisplayInfo>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // SA_MSGS__MSG__DETAIL__HMI_DISPLAY_INFO__TRAITS_HPP_
