// generated from rosidl_generator_c/resource/idl.h.em
// with input from sa_msgs:msg/EngageAdvice.idl
// generated code does not contain a copyright notice

#ifndef SA_MSGS__MSG__ENGAGE_ADVICE_H_
#define SA_MSGS__MSG__ENGAGE_ADVICE_H_

#include "sa_msgs/msg/detail/engage_advice__struct.h"
#include "sa_msgs/msg/detail/engage_advice__functions.h"
#include "sa_msgs/msg/detail/engage_advice__type_support.h"

#endif  // SA_MSGS__MSG__ENGAGE_ADVICE_H_
