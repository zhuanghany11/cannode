// generated from rosidl_generator_c/resource/idl.h.em
// with input from sa_msgs:msg/HmiDisplayInfo.idl
// generated code does not contain a copyright notice

#ifndef SA_MSGS__MSG__HMI_DISPLAY_INFO_H_
#define SA_MSGS__MSG__HMI_DISPLAY_INFO_H_

#include "sa_msgs/msg/detail/hmi_display_info__struct.h"
#include "sa_msgs/msg/detail/hmi_display_info__functions.h"
#include "sa_msgs/msg/detail/hmi_display_info__type_support.h"

#endif  // SA_MSGS__MSG__HMI_DISPLAY_INFO_H_
