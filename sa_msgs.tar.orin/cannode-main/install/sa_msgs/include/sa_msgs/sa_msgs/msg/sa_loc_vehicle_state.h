// generated from rosidl_generator_c/resource/idl.h.em
// with input from sa_msgs:msg/SaLocVehicleState.idl
// generated code does not contain a copyright notice

#ifndef SA_MSGS__MSG__SA_LOC_VEHICLE_STATE_H_
#define SA_MSGS__MSG__SA_LOC_VEHICLE_STATE_H_

#include "sa_msgs/msg/detail/sa_loc_vehicle_state__struct.h"
#include "sa_msgs/msg/detail/sa_loc_vehicle_state__functions.h"
#include "sa_msgs/msg/detail/sa_loc_vehicle_state__type_support.h"

#endif  // SA_MSGS__MSG__SA_LOC_VEHICLE_STATE_H_
