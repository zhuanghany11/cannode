// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from sa_msgs:msg/SaLidarDet.idl
// generated code does not contain a copyright notice

#ifndef SA_MSGS__MSG__DETAIL__SA_LIDAR_DET__BUILDER_HPP_
#define SA_MSGS__MSG__DETAIL__SA_LIDAR_DET__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "sa_msgs/msg/detail/sa_lidar_det__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace sa_msgs
{

namespace msg
{

namespace builder
{

class Init_SaLidarDet_grid_map
{
public:
  explicit Init_SaLidarDet_grid_map(::sa_msgs::msg::SaLidarDet & msg)
  : msg_(msg)
  {}
  ::sa_msgs::msg::SaLidarDet grid_map(::sa_msgs::msg::SaLidarDet::_grid_map_type arg)
  {
    msg_.grid_map = std::move(arg);
    return std::move(msg_);
  }

private:
  ::sa_msgs::msg::SaLidarDet msg_;
};

class Init_SaLidarDet_width
{
public:
  explicit Init_SaLidarDet_width(::sa_msgs::msg::SaLidarDet & msg)
  : msg_(msg)
  {}
  Init_SaLidarDet_grid_map width(::sa_msgs::msg::SaLidarDet::_width_type arg)
  {
    msg_.width = std::move(arg);
    return Init_SaLidarDet_grid_map(msg_);
  }

private:
  ::sa_msgs::msg::SaLidarDet msg_;
};

class Init_SaLidarDet_height
{
public:
  explicit Init_SaLidarDet_height(::sa_msgs::msg::SaLidarDet & msg)
  : msg_(msg)
  {}
  Init_SaLidarDet_width height(::sa_msgs::msg::SaLidarDet::_height_type arg)
  {
    msg_.height = std::move(arg);
    return Init_SaLidarDet_width(msg_);
  }

private:
  ::sa_msgs::msg::SaLidarDet msg_;
};

class Init_SaLidarDet_location
{
public:
  explicit Init_SaLidarDet_location(::sa_msgs::msg::SaLidarDet & msg)
  : msg_(msg)
  {}
  Init_SaLidarDet_height location(::sa_msgs::msg::SaLidarDet::_location_type arg)
  {
    msg_.location = std::move(arg);
    return Init_SaLidarDet_height(msg_);
  }

private:
  ::sa_msgs::msg::SaLidarDet msg_;
};

class Init_SaLidarDet_detection_out
{
public:
  explicit Init_SaLidarDet_detection_out(::sa_msgs::msg::SaLidarDet & msg)
  : msg_(msg)
  {}
  Init_SaLidarDet_location detection_out(::sa_msgs::msg::SaLidarDet::_detection_out_type arg)
  {
    msg_.detection_out = std::move(arg);
    return Init_SaLidarDet_location(msg_);
  }

private:
  ::sa_msgs::msg::SaLidarDet msg_;
};

class Init_SaLidarDet_header
{
public:
  Init_SaLidarDet_header()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_SaLidarDet_detection_out header(::sa_msgs::msg::SaLidarDet::_header_type arg)
  {
    msg_.header = std::move(arg);
    return Init_SaLidarDet_detection_out(msg_);
  }

private:
  ::sa_msgs::msg::SaLidarDet msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::sa_msgs::msg::SaLidarDet>()
{
  return sa_msgs::msg::builder::Init_SaLidarDet_header();
}

}  // namespace sa_msgs

#endif  // SA_MSGS__MSG__DETAIL__SA_LIDAR_DET__BUILDER_HPP_
