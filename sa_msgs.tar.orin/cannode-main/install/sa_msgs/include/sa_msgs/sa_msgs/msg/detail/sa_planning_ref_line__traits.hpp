// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from sa_msgs:msg/SaPlanningRefLine.idl
// generated code does not contain a copyright notice

#ifndef SA_MSGS__MSG__DETAIL__SA_PLANNING_REF_LINE__TRAITS_HPP_
#define SA_MSGS__MSG__DETAIL__SA_PLANNING_REF_LINE__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "sa_msgs/msg/detail/sa_planning_ref_line__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

// Include directives for member types
// Member 'ref_points'
#include "sa_msgs/msg/detail/sa_planning_ref_point__traits.hpp"

namespace sa_msgs
{

namespace msg
{

inline void to_flow_style_yaml(
  const SaPlanningRefLine & msg,
  std::ostream & out)
{
  out << "{";
  // member: id
  {
    out << "id: ";
    rosidl_generator_traits::value_to_yaml(msg.id, out);
    out << ", ";
  }

  // member: length
  {
    out << "length: ";
    rosidl_generator_traits::value_to_yaml(msg.length, out);
    out << ", ";
  }

  // member: ref_points
  {
    if (msg.ref_points.size() == 0) {
      out << "ref_points: []";
    } else {
      out << "ref_points: [";
      size_t pending_items = msg.ref_points.size();
      for (auto item : msg.ref_points) {
        to_flow_style_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const SaPlanningRefLine & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: id
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "id: ";
    rosidl_generator_traits::value_to_yaml(msg.id, out);
    out << "\n";
  }

  // member: length
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "length: ";
    rosidl_generator_traits::value_to_yaml(msg.length, out);
    out << "\n";
  }

  // member: ref_points
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.ref_points.size() == 0) {
      out << "ref_points: []\n";
    } else {
      out << "ref_points:\n";
      for (auto item : msg.ref_points) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "-\n";
        to_block_style_yaml(item, out, indentation + 2);
      }
    }
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const SaPlanningRefLine & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace msg

}  // namespace sa_msgs

namespace rosidl_generator_traits
{

[[deprecated("use sa_msgs::msg::to_block_style_yaml() instead")]]
inline void to_yaml(
  const sa_msgs::msg::SaPlanningRefLine & msg,
  std::ostream & out, size_t indentation = 0)
{
  sa_msgs::msg::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use sa_msgs::msg::to_yaml() instead")]]
inline std::string to_yaml(const sa_msgs::msg::SaPlanningRefLine & msg)
{
  return sa_msgs::msg::to_yaml(msg);
}

template<>
inline const char * data_type<sa_msgs::msg::SaPlanningRefLine>()
{
  return "sa_msgs::msg::SaPlanningRefLine";
}

template<>
inline const char * name<sa_msgs::msg::SaPlanningRefLine>()
{
  return "sa_msgs/msg/SaPlanningRefLine";
}

template<>
struct has_fixed_size<sa_msgs::msg::SaPlanningRefLine>
  : std::integral_constant<bool, false> {};

template<>
struct has_bounded_size<sa_msgs::msg::SaPlanningRefLine>
  : std::integral_constant<bool, false> {};

template<>
struct is_message<sa_msgs::msg::SaPlanningRefLine>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // SA_MSGS__MSG__DETAIL__SA_PLANNING_REF_LINE__TRAITS_HPP_
