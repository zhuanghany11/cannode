// generated from rosidl_generator_c/resource/idl.h.em
// with input from sa_msgs:msg/HmiSecondAlignmentTaskBase.idl
// generated code does not contain a copyright notice

#ifndef SA_MSGS__MSG__HMI_SECOND_ALIGNMENT_TASK_BASE_H_
#define SA_MSGS__MSG__HMI_SECOND_ALIGNMENT_TASK_BASE_H_

#include "sa_msgs/msg/detail/hmi_second_alignment_task_base__struct.h"
#include "sa_msgs/msg/detail/hmi_second_alignment_task_base__functions.h"
#include "sa_msgs/msg/detail/hmi_second_alignment_task_base__type_support.h"

#endif  // SA_MSGS__MSG__HMI_SECOND_ALIGNMENT_TASK_BASE_H_
