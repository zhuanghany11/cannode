// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from sa_msgs:msg/HmiUploadData.idl
// generated code does not contain a copyright notice

#ifndef SA_MSGS__MSG__DETAIL__HMI_UPLOAD_DATA__STRUCT_HPP_
#define SA_MSGS__MSG__DETAIL__HMI_UPLOAD_DATA__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__struct.hpp"

#ifndef _WIN32
# define DEPRECATED__sa_msgs__msg__HmiUploadData __attribute__((deprecated))
#else
# define DEPRECATED__sa_msgs__msg__HmiUploadData __declspec(deprecated)
#endif

namespace sa_msgs
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct HmiUploadData_
{
  using Type = HmiUploadData_<ContainerAllocator>;

  explicit HmiUploadData_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : header(_init)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->command = "";
      this->flow_id = "";
      this->reply_flow_id = "";
      this->event_id = "";
      this->event_time = 0ull;
      this->status = 0l;
      this->msg = "";
    }
  }

  explicit HmiUploadData_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : header(_alloc, _init),
    command(_alloc),
    flow_id(_alloc),
    reply_flow_id(_alloc),
    event_id(_alloc),
    msg(_alloc)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->command = "";
      this->flow_id = "";
      this->reply_flow_id = "";
      this->event_id = "";
      this->event_time = 0ull;
      this->status = 0l;
      this->msg = "";
    }
  }

  // field types and members
  using _header_type =
    std_msgs::msg::Header_<ContainerAllocator>;
  _header_type header;
  using _command_type =
    std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>;
  _command_type command;
  using _flow_id_type =
    std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>;
  _flow_id_type flow_id;
  using _reply_flow_id_type =
    std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>;
  _reply_flow_id_type reply_flow_id;
  using _event_id_type =
    std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>;
  _event_id_type event_id;
  using _event_time_type =
    uint64_t;
  _event_time_type event_time;
  using _status_type =
    int32_t;
  _status_type status;
  using _msg_type =
    std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>;
  _msg_type msg;

  // setters for named parameter idiom
  Type & set__header(
    const std_msgs::msg::Header_<ContainerAllocator> & _arg)
  {
    this->header = _arg;
    return *this;
  }
  Type & set__command(
    const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> & _arg)
  {
    this->command = _arg;
    return *this;
  }
  Type & set__flow_id(
    const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> & _arg)
  {
    this->flow_id = _arg;
    return *this;
  }
  Type & set__reply_flow_id(
    const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> & _arg)
  {
    this->reply_flow_id = _arg;
    return *this;
  }
  Type & set__event_id(
    const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> & _arg)
  {
    this->event_id = _arg;
    return *this;
  }
  Type & set__event_time(
    const uint64_t & _arg)
  {
    this->event_time = _arg;
    return *this;
  }
  Type & set__status(
    const int32_t & _arg)
  {
    this->status = _arg;
    return *this;
  }
  Type & set__msg(
    const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> & _arg)
  {
    this->msg = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    sa_msgs::msg::HmiUploadData_<ContainerAllocator> *;
  using ConstRawPtr =
    const sa_msgs::msg::HmiUploadData_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<sa_msgs::msg::HmiUploadData_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<sa_msgs::msg::HmiUploadData_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      sa_msgs::msg::HmiUploadData_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<sa_msgs::msg::HmiUploadData_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      sa_msgs::msg::HmiUploadData_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<sa_msgs::msg::HmiUploadData_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<sa_msgs::msg::HmiUploadData_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<sa_msgs::msg::HmiUploadData_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__sa_msgs__msg__HmiUploadData
    std::shared_ptr<sa_msgs::msg::HmiUploadData_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__sa_msgs__msg__HmiUploadData
    std::shared_ptr<sa_msgs::msg::HmiUploadData_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const HmiUploadData_ & other) const
  {
    if (this->header != other.header) {
      return false;
    }
    if (this->command != other.command) {
      return false;
    }
    if (this->flow_id != other.flow_id) {
      return false;
    }
    if (this->reply_flow_id != other.reply_flow_id) {
      return false;
    }
    if (this->event_id != other.event_id) {
      return false;
    }
    if (this->event_time != other.event_time) {
      return false;
    }
    if (this->status != other.status) {
      return false;
    }
    if (this->msg != other.msg) {
      return false;
    }
    return true;
  }
  bool operator!=(const HmiUploadData_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct HmiUploadData_

// alias to use template instance with default allocator
using HmiUploadData =
  sa_msgs::msg::HmiUploadData_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace sa_msgs

#endif  // SA_MSGS__MSG__DETAIL__HMI_UPLOAD_DATA__STRUCT_HPP_
