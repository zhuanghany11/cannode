// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from sa_msgs:msg/SaPredictionObstacles.idl
// generated code does not contain a copyright notice

#ifndef SA_MSGS__MSG__DETAIL__SA_PREDICTION_OBSTACLES__BUILDER_HPP_
#define SA_MSGS__MSG__DETAIL__SA_PREDICTION_OBSTACLES__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "sa_msgs/msg/detail/sa_prediction_obstacles__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace sa_msgs
{

namespace msg
{

namespace builder
{

class Init_SaPredictionObstacles_end_timestamp
{
public:
  explicit Init_SaPredictionObstacles_end_timestamp(::sa_msgs::msg::SaPredictionObstacles & msg)
  : msg_(msg)
  {}
  ::sa_msgs::msg::SaPredictionObstacles end_timestamp(::sa_msgs::msg::SaPredictionObstacles::_end_timestamp_type arg)
  {
    msg_.end_timestamp = std::move(arg);
    return std::move(msg_);
  }

private:
  ::sa_msgs::msg::SaPredictionObstacles msg_;
};

class Init_SaPredictionObstacles_start_timestamp
{
public:
  explicit Init_SaPredictionObstacles_start_timestamp(::sa_msgs::msg::SaPredictionObstacles & msg)
  : msg_(msg)
  {}
  Init_SaPredictionObstacles_end_timestamp start_timestamp(::sa_msgs::msg::SaPredictionObstacles::_start_timestamp_type arg)
  {
    msg_.start_timestamp = std::move(arg);
    return Init_SaPredictionObstacles_end_timestamp(msg_);
  }

private:
  ::sa_msgs::msg::SaPredictionObstacles msg_;
};

class Init_SaPredictionObstacles_prediction_obstacle
{
public:
  explicit Init_SaPredictionObstacles_prediction_obstacle(::sa_msgs::msg::SaPredictionObstacles & msg)
  : msg_(msg)
  {}
  Init_SaPredictionObstacles_start_timestamp prediction_obstacle(::sa_msgs::msg::SaPredictionObstacles::_prediction_obstacle_type arg)
  {
    msg_.prediction_obstacle = std::move(arg);
    return Init_SaPredictionObstacles_start_timestamp(msg_);
  }

private:
  ::sa_msgs::msg::SaPredictionObstacles msg_;
};

class Init_SaPredictionObstacles_header
{
public:
  Init_SaPredictionObstacles_header()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_SaPredictionObstacles_prediction_obstacle header(::sa_msgs::msg::SaPredictionObstacles::_header_type arg)
  {
    msg_.header = std::move(arg);
    return Init_SaPredictionObstacles_prediction_obstacle(msg_);
  }

private:
  ::sa_msgs::msg::SaPredictionObstacles msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::sa_msgs::msg::SaPredictionObstacles>()
{
  return sa_msgs::msg::builder::Init_SaPredictionObstacles_header();
}

}  // namespace sa_msgs

#endif  // SA_MSGS__MSG__DETAIL__SA_PREDICTION_OBSTACLES__BUILDER_HPP_
