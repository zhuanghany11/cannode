// generated from rosidl_generator_c/resource/idl__functions.c.em
// with input from sa_msgs:msg/HafNavigationResultV2.idl
// generated code does not contain a copyright notice
#include "sa_msgs/msg/detail/haf_navigation_result_v2__functions.h"

#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

#include "rcutils/allocator.h"


// Include directives for member types
// Member `header`
#include "std_msgs/msg/detail/header__functions.h"
// Member `start_point`
// Member `end_point`
// Member `stop_point`
#include "geometry_msgs/msg/detail/point__functions.h"
// Member `end_point_station_name`
#include "rosidl_runtime_c/string_functions.h"
// Member `way_points`
#include "sa_msgs/msg/detail/haf_way_point_v2__functions.h"

bool
sa_msgs__msg__HafNavigationResultV2__init(sa_msgs__msg__HafNavigationResultV2 * msg)
{
  if (!msg) {
    return false;
  }
  // header
  if (!std_msgs__msg__Header__init(&msg->header)) {
    sa_msgs__msg__HafNavigationResultV2__fini(msg);
    return false;
  }
  // task_finish_time
  // start_point
  if (!geometry_msgs__msg__Point__init(&msg->start_point)) {
    sa_msgs__msg__HafNavigationResultV2__fini(msg);
    return false;
  }
  // end_point
  if (!geometry_msgs__msg__Point__init(&msg->end_point)) {
    sa_msgs__msg__HafNavigationResultV2__fini(msg);
    return false;
  }
  // end_point_station_name
  if (!rosidl_runtime_c__String__init(&msg->end_point_station_name)) {
    sa_msgs__msg__HafNavigationResultV2__fini(msg);
    return false;
  }
  // way_points
  if (!sa_msgs__msg__HafWayPointV2__Sequence__init(&msg->way_points, 0)) {
    sa_msgs__msg__HafNavigationResultV2__fini(msg);
    return false;
  }
  // stop_point
  if (!geometry_msgs__msg__Point__init(&msg->stop_point)) {
    sa_msgs__msg__HafNavigationResultV2__fini(msg);
    return false;
  }
  // stop_point_heading
  return true;
}

void
sa_msgs__msg__HafNavigationResultV2__fini(sa_msgs__msg__HafNavigationResultV2 * msg)
{
  if (!msg) {
    return;
  }
  // header
  std_msgs__msg__Header__fini(&msg->header);
  // task_finish_time
  // start_point
  geometry_msgs__msg__Point__fini(&msg->start_point);
  // end_point
  geometry_msgs__msg__Point__fini(&msg->end_point);
  // end_point_station_name
  rosidl_runtime_c__String__fini(&msg->end_point_station_name);
  // way_points
  sa_msgs__msg__HafWayPointV2__Sequence__fini(&msg->way_points);
  // stop_point
  geometry_msgs__msg__Point__fini(&msg->stop_point);
  // stop_point_heading
}

bool
sa_msgs__msg__HafNavigationResultV2__are_equal(const sa_msgs__msg__HafNavigationResultV2 * lhs, const sa_msgs__msg__HafNavigationResultV2 * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // header
  if (!std_msgs__msg__Header__are_equal(
      &(lhs->header), &(rhs->header)))
  {
    return false;
  }
  // task_finish_time
  if (lhs->task_finish_time != rhs->task_finish_time) {
    return false;
  }
  // start_point
  if (!geometry_msgs__msg__Point__are_equal(
      &(lhs->start_point), &(rhs->start_point)))
  {
    return false;
  }
  // end_point
  if (!geometry_msgs__msg__Point__are_equal(
      &(lhs->end_point), &(rhs->end_point)))
  {
    return false;
  }
  // end_point_station_name
  if (!rosidl_runtime_c__String__are_equal(
      &(lhs->end_point_station_name), &(rhs->end_point_station_name)))
  {
    return false;
  }
  // way_points
  if (!sa_msgs__msg__HafWayPointV2__Sequence__are_equal(
      &(lhs->way_points), &(rhs->way_points)))
  {
    return false;
  }
  // stop_point
  if (!geometry_msgs__msg__Point__are_equal(
      &(lhs->stop_point), &(rhs->stop_point)))
  {
    return false;
  }
  // stop_point_heading
  if (lhs->stop_point_heading != rhs->stop_point_heading) {
    return false;
  }
  return true;
}

bool
sa_msgs__msg__HafNavigationResultV2__copy(
  const sa_msgs__msg__HafNavigationResultV2 * input,
  sa_msgs__msg__HafNavigationResultV2 * output)
{
  if (!input || !output) {
    return false;
  }
  // header
  if (!std_msgs__msg__Header__copy(
      &(input->header), &(output->header)))
  {
    return false;
  }
  // task_finish_time
  output->task_finish_time = input->task_finish_time;
  // start_point
  if (!geometry_msgs__msg__Point__copy(
      &(input->start_point), &(output->start_point)))
  {
    return false;
  }
  // end_point
  if (!geometry_msgs__msg__Point__copy(
      &(input->end_point), &(output->end_point)))
  {
    return false;
  }
  // end_point_station_name
  if (!rosidl_runtime_c__String__copy(
      &(input->end_point_station_name), &(output->end_point_station_name)))
  {
    return false;
  }
  // way_points
  if (!sa_msgs__msg__HafWayPointV2__Sequence__copy(
      &(input->way_points), &(output->way_points)))
  {
    return false;
  }
  // stop_point
  if (!geometry_msgs__msg__Point__copy(
      &(input->stop_point), &(output->stop_point)))
  {
    return false;
  }
  // stop_point_heading
  output->stop_point_heading = input->stop_point_heading;
  return true;
}

sa_msgs__msg__HafNavigationResultV2 *
sa_msgs__msg__HafNavigationResultV2__create()
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  sa_msgs__msg__HafNavigationResultV2 * msg = (sa_msgs__msg__HafNavigationResultV2 *)allocator.allocate(sizeof(sa_msgs__msg__HafNavigationResultV2), allocator.state);
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(sa_msgs__msg__HafNavigationResultV2));
  bool success = sa_msgs__msg__HafNavigationResultV2__init(msg);
  if (!success) {
    allocator.deallocate(msg, allocator.state);
    return NULL;
  }
  return msg;
}

void
sa_msgs__msg__HafNavigationResultV2__destroy(sa_msgs__msg__HafNavigationResultV2 * msg)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (msg) {
    sa_msgs__msg__HafNavigationResultV2__fini(msg);
  }
  allocator.deallocate(msg, allocator.state);
}


bool
sa_msgs__msg__HafNavigationResultV2__Sequence__init(sa_msgs__msg__HafNavigationResultV2__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  sa_msgs__msg__HafNavigationResultV2 * data = NULL;

  if (size) {
    data = (sa_msgs__msg__HafNavigationResultV2 *)allocator.zero_allocate(size, sizeof(sa_msgs__msg__HafNavigationResultV2), allocator.state);
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = sa_msgs__msg__HafNavigationResultV2__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        sa_msgs__msg__HafNavigationResultV2__fini(&data[i - 1]);
      }
      allocator.deallocate(data, allocator.state);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
sa_msgs__msg__HafNavigationResultV2__Sequence__fini(sa_msgs__msg__HafNavigationResultV2__Sequence * array)
{
  if (!array) {
    return;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();

  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      sa_msgs__msg__HafNavigationResultV2__fini(&array->data[i]);
    }
    allocator.deallocate(array->data, allocator.state);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

sa_msgs__msg__HafNavigationResultV2__Sequence *
sa_msgs__msg__HafNavigationResultV2__Sequence__create(size_t size)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  sa_msgs__msg__HafNavigationResultV2__Sequence * array = (sa_msgs__msg__HafNavigationResultV2__Sequence *)allocator.allocate(sizeof(sa_msgs__msg__HafNavigationResultV2__Sequence), allocator.state);
  if (!array) {
    return NULL;
  }
  bool success = sa_msgs__msg__HafNavigationResultV2__Sequence__init(array, size);
  if (!success) {
    allocator.deallocate(array, allocator.state);
    return NULL;
  }
  return array;
}

void
sa_msgs__msg__HafNavigationResultV2__Sequence__destroy(sa_msgs__msg__HafNavigationResultV2__Sequence * array)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (array) {
    sa_msgs__msg__HafNavigationResultV2__Sequence__fini(array);
  }
  allocator.deallocate(array, allocator.state);
}

bool
sa_msgs__msg__HafNavigationResultV2__Sequence__are_equal(const sa_msgs__msg__HafNavigationResultV2__Sequence * lhs, const sa_msgs__msg__HafNavigationResultV2__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!sa_msgs__msg__HafNavigationResultV2__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
sa_msgs__msg__HafNavigationResultV2__Sequence__copy(
  const sa_msgs__msg__HafNavigationResultV2__Sequence * input,
  sa_msgs__msg__HafNavigationResultV2__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    const size_t allocation_size =
      input->size * sizeof(sa_msgs__msg__HafNavigationResultV2);
    rcutils_allocator_t allocator = rcutils_get_default_allocator();
    sa_msgs__msg__HafNavigationResultV2 * data =
      (sa_msgs__msg__HafNavigationResultV2 *)allocator.reallocate(
      output->data, allocation_size, allocator.state);
    if (!data) {
      return false;
    }
    // If reallocation succeeded, memory may or may not have been moved
    // to fulfill the allocation request, invalidating output->data.
    output->data = data;
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!sa_msgs__msg__HafNavigationResultV2__init(&output->data[i])) {
        // If initialization of any new item fails, roll back
        // all previously initialized items. Existing items
        // in output are to be left unmodified.
        for (; i-- > output->capacity; ) {
          sa_msgs__msg__HafNavigationResultV2__fini(&output->data[i]);
        }
        return false;
      }
    }
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!sa_msgs__msg__HafNavigationResultV2__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}
