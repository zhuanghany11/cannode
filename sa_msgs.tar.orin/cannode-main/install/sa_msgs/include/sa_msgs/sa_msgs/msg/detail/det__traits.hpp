// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from sa_msgs:msg/Det.idl
// generated code does not contain a copyright notice

#ifndef SA_MSGS__MSG__DETAIL__DET__TRAITS_HPP_
#define SA_MSGS__MSG__DETAIL__DET__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "sa_msgs/msg/detail/det__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

// Include directives for member types
// Member 'rect'
#include "sa_msgs/msg/detail/box_rect__traits.hpp"
// Member 'position'
#include "sa_msgs/msg/detail/box_position__traits.hpp"
// Member 'size'
#include "sa_msgs/msg/detail/box_size__traits.hpp"

namespace sa_msgs
{

namespace msg
{

inline void to_flow_style_yaml(
  const Det & msg,
  std::ostream & out)
{
  out << "{";
  // member: score
  {
    out << "score: ";
    rosidl_generator_traits::value_to_yaml(msg.score, out);
    out << ", ";
  }

  // member: label
  {
    out << "label: ";
    rosidl_generator_traits::value_to_yaml(msg.label, out);
    out << ", ";
  }

  // member: rect
  {
    out << "rect: ";
    to_flow_style_yaml(msg.rect, out);
    out << ", ";
  }

  // member: position
  {
    out << "position: ";
    to_flow_style_yaml(msg.position, out);
    out << ", ";
  }

  // member: size
  {
    out << "size: ";
    to_flow_style_yaml(msg.size, out);
    out << ", ";
  }

  // member: yaw
  {
    out << "yaw: ";
    rosidl_generator_traits::value_to_yaml(msg.yaw, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const Det & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: score
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "score: ";
    rosidl_generator_traits::value_to_yaml(msg.score, out);
    out << "\n";
  }

  // member: label
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "label: ";
    rosidl_generator_traits::value_to_yaml(msg.label, out);
    out << "\n";
  }

  // member: rect
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "rect:\n";
    to_block_style_yaml(msg.rect, out, indentation + 2);
  }

  // member: position
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "position:\n";
    to_block_style_yaml(msg.position, out, indentation + 2);
  }

  // member: size
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "size:\n";
    to_block_style_yaml(msg.size, out, indentation + 2);
  }

  // member: yaw
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "yaw: ";
    rosidl_generator_traits::value_to_yaml(msg.yaw, out);
    out << "\n";
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const Det & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace msg

}  // namespace sa_msgs

namespace rosidl_generator_traits
{

[[deprecated("use sa_msgs::msg::to_block_style_yaml() instead")]]
inline void to_yaml(
  const sa_msgs::msg::Det & msg,
  std::ostream & out, size_t indentation = 0)
{
  sa_msgs::msg::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use sa_msgs::msg::to_yaml() instead")]]
inline std::string to_yaml(const sa_msgs::msg::Det & msg)
{
  return sa_msgs::msg::to_yaml(msg);
}

template<>
inline const char * data_type<sa_msgs::msg::Det>()
{
  return "sa_msgs::msg::Det";
}

template<>
inline const char * name<sa_msgs::msg::Det>()
{
  return "sa_msgs/msg/Det";
}

template<>
struct has_fixed_size<sa_msgs::msg::Det>
  : std::integral_constant<bool, has_fixed_size<sa_msgs::msg::BoxPosition>::value && has_fixed_size<sa_msgs::msg::BoxRect>::value && has_fixed_size<sa_msgs::msg::BoxSize>::value> {};

template<>
struct has_bounded_size<sa_msgs::msg::Det>
  : std::integral_constant<bool, has_bounded_size<sa_msgs::msg::BoxPosition>::value && has_bounded_size<sa_msgs::msg::BoxRect>::value && has_bounded_size<sa_msgs::msg::BoxSize>::value> {};

template<>
struct is_message<sa_msgs::msg::Det>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // SA_MSGS__MSG__DETAIL__DET__TRAITS_HPP_
