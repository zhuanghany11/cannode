// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef SA_MSGS__MSG__HAF_TRAFFIC_LIGHT_SIGNAL_HPP_
#define SA_MSGS__MSG__HAF_TRAFFIC_LIGHT_SIGNAL_HPP_

#include "sa_msgs/msg/detail/haf_traffic_light_signal__struct.hpp"
#include "sa_msgs/msg/detail/haf_traffic_light_signal__builder.hpp"
#include "sa_msgs/msg/detail/haf_traffic_light_signal__traits.hpp"
#include "sa_msgs/msg/detail/haf_traffic_light_signal__type_support.hpp"

#endif  // SA_MSGS__MSG__HAF_TRAFFIC_LIGHT_SIGNAL_HPP_
