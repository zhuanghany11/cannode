// generated from rosidl_generator_c/resource/idl.h.em
// with input from sa_msgs:msg/HmiTaskPlanEndPoint.idl
// generated code does not contain a copyright notice

#ifndef SA_MSGS__MSG__HMI_TASK_PLAN_END_POINT_H_
#define SA_MSGS__MSG__HMI_TASK_PLAN_END_POINT_H_

#include "sa_msgs/msg/detail/hmi_task_plan_end_point__struct.h"
#include "sa_msgs/msg/detail/hmi_task_plan_end_point__functions.h"
#include "sa_msgs/msg/detail/hmi_task_plan_end_point__type_support.h"

#endif  // SA_MSGS__MSG__HMI_TASK_PLAN_END_POINT_H_
