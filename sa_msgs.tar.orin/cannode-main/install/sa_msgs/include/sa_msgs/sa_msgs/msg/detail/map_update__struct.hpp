// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from sa_msgs:msg/MapUpdate.idl
// generated code does not contain a copyright notice

#ifndef SA_MSGS__MSG__DETAIL__MAP_UPDATE__STRUCT_HPP_
#define SA_MSGS__MSG__DETAIL__MAP_UPDATE__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__struct.hpp"

#ifndef _WIN32
# define DEPRECATED__sa_msgs__msg__MapUpdate __attribute__((deprecated))
#else
# define DEPRECATED__sa_msgs__msg__MapUpdate __declspec(deprecated)
#endif

namespace sa_msgs
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct MapUpdate_
{
  using Type = MapUpdate_<ContainerAllocator>;

  explicit MapUpdate_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : header(_init)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->time = 0ull;
      this->is_base_data_update = false;
      this->is_dynamic_data_update = false;
      this->base_data_path = "";
      this->dynamic_data_path = "";
    }
  }

  explicit MapUpdate_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : header(_alloc, _init),
    base_data_path(_alloc),
    dynamic_data_path(_alloc)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->time = 0ull;
      this->is_base_data_update = false;
      this->is_dynamic_data_update = false;
      this->base_data_path = "";
      this->dynamic_data_path = "";
    }
  }

  // field types and members
  using _header_type =
    std_msgs::msg::Header_<ContainerAllocator>;
  _header_type header;
  using _time_type =
    uint64_t;
  _time_type time;
  using _is_base_data_update_type =
    bool;
  _is_base_data_update_type is_base_data_update;
  using _is_dynamic_data_update_type =
    bool;
  _is_dynamic_data_update_type is_dynamic_data_update;
  using _base_data_path_type =
    std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>;
  _base_data_path_type base_data_path;
  using _dynamic_data_path_type =
    std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>;
  _dynamic_data_path_type dynamic_data_path;

  // setters for named parameter idiom
  Type & set__header(
    const std_msgs::msg::Header_<ContainerAllocator> & _arg)
  {
    this->header = _arg;
    return *this;
  }
  Type & set__time(
    const uint64_t & _arg)
  {
    this->time = _arg;
    return *this;
  }
  Type & set__is_base_data_update(
    const bool & _arg)
  {
    this->is_base_data_update = _arg;
    return *this;
  }
  Type & set__is_dynamic_data_update(
    const bool & _arg)
  {
    this->is_dynamic_data_update = _arg;
    return *this;
  }
  Type & set__base_data_path(
    const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> & _arg)
  {
    this->base_data_path = _arg;
    return *this;
  }
  Type & set__dynamic_data_path(
    const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> & _arg)
  {
    this->dynamic_data_path = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    sa_msgs::msg::MapUpdate_<ContainerAllocator> *;
  using ConstRawPtr =
    const sa_msgs::msg::MapUpdate_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<sa_msgs::msg::MapUpdate_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<sa_msgs::msg::MapUpdate_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      sa_msgs::msg::MapUpdate_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<sa_msgs::msg::MapUpdate_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      sa_msgs::msg::MapUpdate_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<sa_msgs::msg::MapUpdate_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<sa_msgs::msg::MapUpdate_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<sa_msgs::msg::MapUpdate_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__sa_msgs__msg__MapUpdate
    std::shared_ptr<sa_msgs::msg::MapUpdate_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__sa_msgs__msg__MapUpdate
    std::shared_ptr<sa_msgs::msg::MapUpdate_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const MapUpdate_ & other) const
  {
    if (this->header != other.header) {
      return false;
    }
    if (this->time != other.time) {
      return false;
    }
    if (this->is_base_data_update != other.is_base_data_update) {
      return false;
    }
    if (this->is_dynamic_data_update != other.is_dynamic_data_update) {
      return false;
    }
    if (this->base_data_path != other.base_data_path) {
      return false;
    }
    if (this->dynamic_data_path != other.dynamic_data_path) {
      return false;
    }
    return true;
  }
  bool operator!=(const MapUpdate_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct MapUpdate_

// alias to use template instance with default allocator
using MapUpdate =
  sa_msgs::msg::MapUpdate_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace sa_msgs

#endif  // SA_MSGS__MSG__DETAIL__MAP_UPDATE__STRUCT_HPP_
