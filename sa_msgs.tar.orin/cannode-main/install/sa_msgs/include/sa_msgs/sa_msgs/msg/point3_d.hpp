// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef SA_MSGS__MSG__POINT3_D_HPP_
#define SA_MSGS__MSG__POINT3_D_HPP_

#include "sa_msgs/msg/detail/point3_d__struct.hpp"
#include "sa_msgs/msg/detail/point3_d__builder.hpp"
#include "sa_msgs/msg/detail/point3_d__traits.hpp"
#include "sa_msgs/msg/detail/point3_d__type_support.hpp"

#endif  // SA_MSGS__MSG__POINT3_D_HPP_
