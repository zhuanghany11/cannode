// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef SA_MSGS__MSG__HAF_DISPLAY_PATH_POINT_HPP_
#define SA_MSGS__MSG__HAF_DISPLAY_PATH_POINT_HPP_

#include "sa_msgs/msg/detail/haf_display_path_point__struct.hpp"
#include "sa_msgs/msg/detail/haf_display_path_point__builder.hpp"
#include "sa_msgs/msg/detail/haf_display_path_point__traits.hpp"
#include "sa_msgs/msg/detail/haf_display_path_point__type_support.hpp"

#endif  // SA_MSGS__MSG__HAF_DISPLAY_PATH_POINT_HPP_
