// generated from rosidl_generator_c/resource/idl.h.em
// with input from sa_msgs:msg/PreciseDockingRes.idl
// generated code does not contain a copyright notice

#ifndef SA_MSGS__MSG__PRECISE_DOCKING_RES_H_
#define SA_MSGS__MSG__PRECISE_DOCKING_RES_H_

#include "sa_msgs/msg/detail/precise_docking_res__struct.h"
#include "sa_msgs/msg/detail/precise_docking_res__functions.h"
#include "sa_msgs/msg/detail/precise_docking_res__type_support.h"

#endif  // SA_MSGS__MSG__PRECISE_DOCKING_RES_H_
