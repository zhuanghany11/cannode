// generated from rosidl_generator_c/resource/idl.h.em
// with input from sa_msgs:msg/Oem7Header.idl
// generated code does not contain a copyright notice

#ifndef SA_MSGS__MSG__OEM7_HEADER_H_
#define SA_MSGS__MSG__OEM7_HEADER_H_

#include "sa_msgs/msg/detail/oem7_header__struct.h"
#include "sa_msgs/msg/detail/oem7_header__functions.h"
#include "sa_msgs/msg/detail/oem7_header__type_support.h"

#endif  // SA_MSGS__MSG__OEM7_HEADER_H_
