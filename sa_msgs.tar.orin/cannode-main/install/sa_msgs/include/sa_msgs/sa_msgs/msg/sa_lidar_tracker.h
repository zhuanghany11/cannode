// generated from rosidl_generator_c/resource/idl.h.em
// with input from sa_msgs:msg/SaLidarTracker.idl
// generated code does not contain a copyright notice

#ifndef SA_MSGS__MSG__SA_LIDAR_TRACKER_H_
#define SA_MSGS__MSG__SA_LIDAR_TRACKER_H_

#include "sa_msgs/msg/detail/sa_lidar_tracker__struct.h"
#include "sa_msgs/msg/detail/sa_lidar_tracker__functions.h"
#include "sa_msgs/msg/detail/sa_lidar_tracker__type_support.h"

#endif  // SA_MSGS__MSG__SA_LIDAR_TRACKER_H_
